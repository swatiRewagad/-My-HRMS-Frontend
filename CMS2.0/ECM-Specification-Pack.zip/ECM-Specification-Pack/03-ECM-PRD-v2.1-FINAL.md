# Enterprise Content Management (ECM)
## Product Requirements Document — v2.1 (Baselined)

| Field | Value |
|---|---|
| Product | ECM — Enterprise Content Management |
| Programme | RBI Enterprise Platform |
| Build owner | ReBIT |
| Status | **v2.1 — Baselined. Supersedes v1.0 and v2.0.** |
| Date | 13 August 2026 |
| v2.1 delta | Adds Part II-B: twelve extended capabilities (E1–E12) identified as necessary for a regulator-grade content platform |
| Root package | `org.rebit.ecm` |
| Identity provider | Kavach (JWT-based UAM) |
| Stack | Java 21 · Spring Boot · Angular 21 · Oracle 19c (prod, partitioned) · SQLite (dev) |

> **How to read this document.** §3–§12 and **Part II-B (E1–E12)** are the *functional* specification. §13–§16 are the *technical* specification. §17–§19 are the *integration* specification. §20–§24 cover non-functional, security, UX, test and delivery. §25 is the decision log — read it first if you are joining the project.

---

# PART I — CONTEXT

## 1. Problem Statement

Every application on the RBI Enterprise Platform solves document storage independently. Invoices sit in one application's filesystem, grievance attachments in another's BLOB column, HR records on a shared drive. There is no common retention policy, no unified record of who read what, no shared search, and no way for one application to display a document another application owns.

The cost is threefold. **Compliance exposure:** the institution cannot answer "who accessed this document, and when" across all systems. **Storage cost:** with no archival tier, every application keeps every byte hot forever, and the production databases grow without a governed ceiling. **Duplicated engineering:** each new module rebuilds upload, preview, versioning and permissions, usually with weaker controls than the last one.

ECM becomes the single content substrate of the platform: one repository, one Kavach-driven permission model, one tamper-evident audit trail, one policy-driven storage tiering engine, and a set of embeddable viewer widgets so any application can display any document it is entitled to without owning storage.

## 2. Goals, Non-Goals and Personas

### 2.1 Goals

| # | Goal | Success measure |
|---|---|---|
| G1 | Single content store for platform applications | ≥ 4 entities onboarded within 2 quarters of GA; no new application-local file store approved after GA |
| G2 | Governed storage cost through automated tiering | ≥ 60% of stored bytes on archive tier by GA+6 months; hot-tier growth < 40% of gross ingest |
| G3 | Complete, tamper-evident auditability | 100% of read/write/share/export/permission events captured; hash chain verifies daily with zero breaks |
| G4 | Remove document-viewing effort from consuming applications | Host application integrates the viewer in ≤ 1 engineering day; ≥ 3 host applications live by GA+1 quarter |
| G5 | Content is findable | Aggregate zero-result search rate < 10%; median time-to-open from search < 30 s (measured in aggregate, non-identifying) |
| G6 | Platform-grade reliability | 99.5% monthly availability of read paths; RPO ≤ 15 min, RTO ≤ 4 h |

### 2.2 Non-Goals (v1)

| Non-goal | Rationale |
|---|---|
| Authentication, MFA, SSO, credential management | Owned entirely by Kavach. ECM consumes identity; it never issues, stores or resets it. |
| Real-time co-authoring | Check-out/check-in resolves the conflict problem at a fraction of the cost. |
| Records-management certification (DoD 5015.2 / VERS) | v1 builds the retention primitives; certification is a separate programme. |
| Generative answer synthesis over the corpus | v1 ships OCR, extraction and semantic retrieval only. Generation requires separate governance sign-off. |
| Content deduplication | Collides with expunge, redaction and legal hold. Deferred — but the schema carries `ref_count` and a content-hash index so it can be enabled without migration. |
| Citizen / public-internet access | Internal platform service. External reach is via expiring, policy-capped share links only. |
| Desktop sync client, mobile offline vault | Different product with different threat model. |
| Email journaling / mailbox ingestion | Separate compliance capability. |
| E-signature, DRM/IRM on downloaded copies | Downstream of v1; watermarking is the v1 control. |
| Physical-records (file-room) tracking | Not a digital content problem. |
| Per-source legacy migration adapters | Bulk import API is in scope; each source migration is its own project. |

### 2.3 Personas

| Persona | Indicative Kavach role | Core need |
|---|---|---|
| Platform Admin | `ECM_ADMIN` | Entities, quotas, mount points, archival policies, health |
| Admin Maker | `ADMIN_MAKER` | Author configuration, submit for approval |
| Admin Checker | `ADMIN_CHECKER` | Approve/reject; cannot author |
| Business User | `ECM_USER` | Upload, organise, find, preview, share, version within Public and their Private area |
| Reviewer / Approver | `ECM_APPROVER` | Act on approval tasks; apply and confirm redactions |
| Auditor | `ECM_AUDITOR` | Read-only across realm + full audit query and export |
| Host Application | service principal | Embed viewer; call REST API |
| Custodian | `ECM_CUSTODIAN` | Inherits orphaned private content on user deprovisioning |

---

# PART II — FUNCTIONAL SPECIFICATION

## 3. Core Domain Model *(resolves F-01, F-02)*

The tenancy and containment chain is fixed and must not be reinterpreted:

```
Kavach Realm  (identity & isolation boundary)
   └── ECM Entity  (storage, quota, mount point, policy boundary — e.g. IPS, DMS, CRM)
         └── Parent Folder
               └── Sub-parent Folder
                     └── Child Folder
                           └── Document  ──N:M──  Child Folder (secondary links)
                                 └── Version
                                       └── Chunk
```

- **Realm** owns identity, ACL principals and row-level isolation. A user's realm entitlement determines which entities are visible at all.
- **Entity** owns the mount point (`/ECM/...`), the storage quota, the extension allowlist, the document-size cap, the ingest threshold and the archival policy. It is the unit that goes through maker–checker.
- A **Document** has exactly one primary child-folder link and zero or more secondary links.
- A **Version** is immutable once committed. Restore creates a new version; nothing is ever overwritten.

### 3.1 Folder classes *(F-02)*

| Class | Visibility | Created by | Notes |
|---|---|---|---|
| `PUBLIC` | All entitled users of the realm/entity, read by default | Admin | Write requires explicit grant |
| `PRIVATE` | Owner only, plus explicit grants, plus admin break-glass (audited) | Auto-provisioned, one per user per entity | Non-deletable while user is active |
| `RESTRICTED` | ACL-gated only | Admin | Not listed to users without at least read |

**Deprovisioning:** when Kavach reports a user as disabled, their PRIVATE root transfers to the entity's Custodian, retaining full history, and emits `PRIVATE_ROOT_TRANSFERRED`.

**FR-ORG acceptance:**
- Given a Business User with realm entitlement R1 only, when they request the folder tree, then only R1 entities appear and any direct request for an R2 folder identifier returns `404` (not `403` — no existence disclosure).
- Given a document linked to folders A (primary) and B (secondary), when the B link is removed, then the document is still retrievable via A and `LINK_REMOVED` is audited.

## 4. File Manager (User Workspace) — P0

Windows-Explorer-style workspace over the hierarchy.

| ID | Requirement | Pri |
|---|---|---|
| FR-FM-01 | Breadcrumb navigation, tree sidebar, grid/list/detail toggle, sortable columns (name, size, modified, owner, type) | P0 |
| FR-FM-02 | Right-click context menu: new folder, rename, move, copy, delete, share, download, properties | P0 |
| FR-FM-03 | Multi-select with cut/copy/paste and bulk actions | P0 |
| FR-FM-04 | Drag-and-drop upload into the focused folder, including whole folder structures | P0 |
| FR-FM-05 | Realm switcher; each realm is an isolated root tree; **no cross-realm move or copy in v1** | P0 |
| FR-FM-06 | Business Users see exactly two roots per entity: **Public** and **My Private**. Admins see all roots including Restricted | P0 |
| FR-FM-07 | Recent / Favourites / Shared-with-me virtual views | P1 |
| FR-FM-08 | Inline rename with optimistic UI and rollback on server rejection | P1 |

**Acceptance:** Given 10,000 items in a folder, when the user opens it, then the first page renders in < 300 ms p95 and scrolling is virtualised with no full-list fetch.

## 5. Document Management — P0

| ID | Requirement | Pri |
|---|---|---|
| FR-DOC-01 | Upload single or multiple files via a **resumable upload session** (§11.3) | P0 |
| FR-DOC-02 | Format registry validates extension **and** magic bytes **and** declared MIME; entity allowlist and size cap enforced server-side | P0 |
| FR-DOC-03 | Check-out / check-in with locking; locks auto-expire (default 8 h) and are force-releasable by admin with audit | P0 |
| FR-DOC-04 | Full version history: list, compare metadata, restore prior version **as a new version** | P0 |
| FR-DOC-05 | Withdraw/reinstate and **expunge** with mandatory reason; expunge blocked under legal hold | P0 |
| FR-DOC-06 | Recycle bin with configurable retention before purge | P0 |
| FR-DOC-07 | In-browser preview without download | P0 |
| FR-DOC-08 | Watermarking/stamping (Draft, Confidential, viewer identity, timestamp) on preview and download | P1 |
| FR-DOC-09 | Bulk upload with metadata mapping from CSV/spreadsheet | P1 |
| FR-DOC-10 | Custom metadata schemas per entity with typed fields and controlled vocabularies | P1 |

**Acceptance (versioning):** Given a document at v3, when a user restores v1, then a new v4 exists whose bytes equal v1's, v1–v3 remain retrievable, and the audit shows `VERSION_RESTORED{from:1,to:4}`.

**Acceptance (locking):** Given user A holds a check-out, when user B attempts check-in, then B receives `409 Conflict` with a problem detail naming the lock holder and expiry.

## 6. Storage, Tiering & Archival — P0 *(core differentiator; resolves F-04…F-08)*

### 6.1 Ingest policy

| ID | Requirement | Pri |
|---|---|---|
| FR-STO-01 | Content is split into fixed logical chunks (default **4 MiB**, per-entity configurable, aligned to the LOB chunk size) and written to the database. Each chunk carries its own SHA-256; the version carries the whole-file SHA-256, byte length and chunk count | P0 |
| FR-STO-02 | **Ingest threshold:** content larger than `db_first_max_bytes` (default 100 MiB, per entity) bypasses the DB tier and streams directly to the archive tier with a DB-resident manifest. The read path is identical either way | P0 |
| FR-STO-03 | A version becomes visible only after all chunks are committed and the whole-file hash verifies. Partial uploads are never readable | P0 |
| FR-STO-04 | The chunk size and ingest decision are **frozen per version** at write time; later config changes never invalidate existing content | P0 |

### 6.2 Mount points

| ID | Requirement | Pri |
|---|---|---|
| FR-STO-05 | Every entity binds to a mount point under the mandatory `/ECM/` prefix (e.g. `/ECM/IPS/Consolidated_Invoice`) | P0 |
| FR-STO-06 | Paths are canonicalised and rejected on: traversal segments, absolute escape, symlink escape, disallowed characters, depth > 8, or collision with an existing registered mount | P0 |
| FR-STO-07 | Mount-point creation and change go through maker–checker | P0 |

### 6.3 Tier state machine *(F-05)*

```
        archival policy fires              read + promotion policy
 HOT ───────────────► ARCHIVING ──► ARCHIVED ───────────────► REHYDRATING ──► HOT
  ▲                       │             │                          │
  │                       │ fail        │ stream-through           │ checksum fail
  └───────────────────────┘             ▼ (always available)       ▼
                                    served from archive        REHYDRATE_FAILED
                                                               (still serves; alerts)
```

| ID | Requirement | Pri |
|---|---|---|
| FR-STO-08 | Archival policy per entity: age since creation, idle days since last access, minimum size, target tier, schedule. **Legal hold blocks archival unconditionally** | P0 |
| FR-STO-09 | Archival seals the version into a single archive object, verifies checksum against the manifest, records the pointer, then releases DB chunks — in that order, never before verification | P0 |
| FR-STO-10 | On read of an `ARCHIVED` version, bytes are **streamed through from the archive immediately**; the reader never waits for rehydration | P0 |
| FR-STO-11 | Rehydration is guarded by a distributed lock keyed by version — concurrent readers trigger at most one rehydration job | P0 |
| FR-STO-12 | **Promotion policy:** rehydration is triggered only after N reads within M days (default 2 reads / 7 days), so one-off audit reads do not repopulate the hot tier | P0 |
| FR-STO-13 | Rehydration commits atomically on checksum success; on failure the version stays `ARCHIVED`, continues serving from archive, and raises an operational alert | P0 |
| FR-STO-14 | Every tier transition is audited: what moved, when, under which policy, triggered by which principal or job | P0 |
| FR-STO-15 | Quota enforced at upload — warn at 80%, hard stop at 100%. Archived bytes count at a configurable weight (default 0.25) so archival remains an incentive | P0 |
| FR-STO-16 | Nightly **quota reconciliation** compares logical accounting to physical reality and reports variance per entity | P0 |
| FR-STO-17 | Abandoned upload sessions and orphaned chunks are reaped on a schedule (session TTL default 24 h) | P0 |
| FR-STO-18 | Database archival: superseded versions, closed workflow tasks and aged audit rows move to archive partitions to keep the live schema lean | P1 |

**Acceptance (round-trip integrity):** Given a 250 MB file, when it is uploaded, archived, DB chunks released, and then downloaded, then the downloaded bytes are identical to the original and the whole-file SHA-256 matches. *(This is an automated property test, not a manual check.)*

**Acceptance (thundering herd):** Given 50 concurrent reads of one `ARCHIVED` version, when the reads arrive, then exactly one rehydration job executes and all 50 readers receive correct bytes with TTFB < 3 s p95.

## 7. Search — P0

| ID | Requirement | Pri |
|---|---|---|
| FR-SRCH-01 | Full-text search over content (including OCR text) and metadata | P0 |
| FR-SRCH-02 | Results are **permission-trimmed at query time** — a user never sees a hit they cannot open, and result counts do not leak inaccessible documents | P0 |
| FR-SRCH-03 | Faceted filters: entity, folder, type, owner, date range, tag, size, status | P0 |
| FR-SRCH-04 | Index updates are driven by a transactional outbox; a reconciliation job detects and repairs index drift | P0 |
| FR-SRCH-05 | Semantic/vector search and natural-language queries alongside keyword search | P1 |
| FR-SRCH-06 | Search analytics (top queries, zero-result queries) as **aggregate, non-identifying** counters | P1 |
| FR-SRCH-07 | Indic-language analyzers and tokenisation for Hindi content | P1 |

## 8. Sharing — P0

| ID | Requirement | Pri |
|---|---|---|
| FR-SHR-01 | Secure shareable links to a document or child folder, internal or external | P0 |
| FR-SHR-02 | Options: expiry date/time, password, download limit, view-only vs download, watermark | P0 |
| FR-SHR-03 | Immediate revocation by owner or admin; revocation writes through the cache synchronously | P0 |
| FR-SHR-04 | Realm-level policy ceilings (max expiry, password mandatory, watermark mandatory) that users cannot exceed | P0 |
| FR-SHR-05 | Link tokens are stored hashed, never in plaintext; creation, access, expiry and revocation are audited | P0 |

## 9. AI Capabilities, Redaction and Workflow

### 9.1 AI — P0/P1

| ID | Requirement | Pri |
|---|---|---|
| FR-AI-01 | OCR on scanned images and non-searchable PDFs at ingest; extracted text stored alongside the original and indexed | P0 |
| FR-AI-02 | All AI features individually toggleable per realm/entity by an administrator | P0 |
| FR-AI-03 | Extraction of structured metadata (type, dates, invoice/reference numbers, names, addresses, key clauses) with **confidence scores**; low-confidence fields flagged for manual review | P1 |
| FR-AI-04 | Semantic/vector search, auto-tagging, topic classification, AI summaries in results | P1 |
| FR-AI-05 | AI-assisted redaction candidate detection for reviewer confirmation | P1 |
| FR-AI-06 | Mixed-language and Indic-script OCR support | P1 |

### 9.2 Redaction — P1 *(F-13)*

| ID | Requirement |
|---|---|
| FR-RED-01 | Manual region/text redaction on the preview; AI-suggested candidates require human confirmation |
| FR-RED-02 | Redaction is **true content removal**: produce redacted derivative → strip source text layer → re-OCR the derivative → **purge and re-index the search entries for that version** → verify by automated extraction that the redacted strings are absent → only then publish |
| FR-RED-03 | The original is retained in secured storage; the redacted version is served to the applicable audience and all share links; both are linked in version history and audit |

### 9.3 Workflow — P0/P1

| ID | Requirement | Pri |
|---|---|---|
| FR-WF-01 | Entity configuration and policy changes follow maker–checker; status *Draft → Sent for Approval → Approved/Rejected* with remarks | P0 |
| FR-WF-02 | A maker cannot approve their own submission (enforced server-side, not only in UI) | P0 |
| FR-WF-03 | Document approval workflow (submit → review → approve/reject) with a task inbox | P1 |

## 10. Embedded Viewer Widgets — P0 *(new capability; security model per F-09)*

### 10.1 Embed contract

The host application's **backend** requests a viewer token; the browser never mints or holds a general-purpose credential for ECM.

```
Host UI ──(1) needs to show fileId──► Host Backend
Host Backend ──(2) POST /v1/viewer/tokens {documentId, versionId?, subject, purpose}──► ECM
ECM ──(3) verify caller's service identity + subject's ACL──► mint capability token
Host Backend ──(4) token──► Host UI ──(5) <ecm-viewer [token]>──► ECM stream endpoint
ECM ──(6) re-verify ACL on EVERY stream request, then serve──►
```

| ID | Requirement | Pri |
|---|---|---|
| FR-VW-01 | Viewer tokens are bound to: one document (optionally one version), one subject, one host-application audience, one permission set (view / download / print), expiry ≤ 10 minutes, single-use refresh | P0 |
| FR-VW-02 | A token is a **capability, never a substitute for authorisation** — ECM re-evaluates the underlying ACL on every stream request | P0 |
| FR-VW-03 | Identifiers are unguessable ULIDs; enumeration attempts are rate-limited per host application and alerted | P0 |
| FR-VW-04 | The widget renders regardless of tier (`HOT` or `ARCHIVED`) with no functional difference visible to the user; only latency differs | P0 |
| FR-VW-05 | Formats at GA: PDF, images (JPEG/PNG/TIFF/WebP/sanitised SVG), text/CSV/Markdown/JSON/XML, audio, video, Office (server-side conversion to PDF) | P0 |
| FR-VW-06 | Controls: page navigation, zoom, rotate, fit-width/fit-page, thumbnail rail, in-document search, download/print toggles governed by the token's permission set | P0 |
| FR-VW-07 | Media supports HTTP byte-range streaming and seeking without full download | P0 |
| FR-VW-08 | Watermark overlay applied when policy requires it, including viewer identity and timestamp | P0 |
| FR-VW-09 | Three embed modes: Angular component, Web Component (custom element) for non-Angular hosts, and sandboxed iframe with `postMessage` for strict isolation | P0 |
| FR-VW-10 | Themeable via CSS custom properties; defaults to the Enterprise Platform theme | P0 |
| FR-VW-11 | Annotations (comments, highlights) persisted against the document version | P1 |
| FR-VW-12 | CAD and archive-listing viewers | P2 |

**Acceptance:** Given a viewer token scoped to `view` only, when the widget requests the download endpoint, then the request is rejected with `403` and a `TOKEN_SCOPE_EXCEEDED` audit event is written.

## 11. Administration & Configuration — P0

### 11.1 Entity Configuration *(decisions per F-21)*

| Field | Control | Rule |
|---|---|---|
| Entity | Select from registered platform applications | One config per entity per realm |
| Total Allocated Storage | Governed tier list: **Standard 100 GB / Enhanced 500 GB / Custom** | Custom requires checker approval with justification |
| Document Extension | **Multi-select** from the format registry | At least one required |
| Document Size | Bounded numeric entry | Must be ≤ entity tier ceiling |
| Mountpoint Path | Prefixed input, `/ECM/` fixed and non-editable | Validated per FR-STO-06 |
| Chunk size / ingest threshold | Advanced section, defaulted | Change requires approval |
| Archival policy | Select or create | Legal-hold exceptions listed |
| Status | System-managed | Draft → Sent for Approval → Approved / Rejected |

### 11.2 Other administration

| ID | Requirement | Pri |
|---|---|---|
| FR-ADM-01 | Admin console for folders, workflows, metadata schemas, controlled vocabularies, format registry | P0 |
| FR-ADM-02 | System health dashboard: storage by tier, indexing status, OCR/AI queue depth and backlog, archival job status, error rates, quota variance | P0 |
| FR-ADM-03 | Break-glass access to PRIVATE content — requires reason, is time-boxed, and is audited with elevated severity | P0 |
| FR-ADM-04 | Legal hold: apply/release at document, folder or entity scope; blocks archival, expunge and purge | P0 |
| FR-ADM-05 | Chargeback report: storage consumed by entity by tier, monthly | P1 |

## 12. Statistics, Reporting, Import/Export

| ID | Requirement | Pri |
|---|---|---|
| FR-RPT-01 | Usage statistics per document and folder over configurable ranges | P1 |
| FR-RPT-02 | Admin dashboards: storage usage, growth trend, most active folders, top contributors, most-shared documents | P1 |
| FR-RPT-03 | Exportable CSV/PDF reports for compliance, audit and management review | P1 |
| FR-API-01 | REST API covering folder/document CRUD, search, workflow actions, sharing, viewer tokens | P0 |
| FR-API-02 | OpenAPI 3.1 published per service; contract tests enforce it | P0 |
| FR-API-03 | Bulk import of files + metadata; bulk export of folders + metadata | P1 |

---

# PART II-B — EXTENDED CAPABILITIES (v2.1)

> These twelve capabilities were added on review. Each is either (a) something a regulator's content platform is expected to have and whose absence would be raised in an audit, or (b) cheap to build now and expensive to retrofit. Each carries a rationale so it can be cut with open eyes rather than by accident.

## E1. Sensitivity Classification & DLP Controls — P0/P1

*Rationale: without a classification label, every downstream control — watermarking, share restriction, encryption, export blocking — has to be configured per document. With one, policy becomes declarative.*

| ID | Requirement | Pri |
|---|---|---|
| E1-01 | Every document carries a sensitivity label: `PUBLIC`, `INTERNAL`, `CONFIDENTIAL`, `RESTRICTED`. Default is set per entity; the uploader may raise but never lower it | P0 |
| E1-02 | Labels drive policy declaratively: whether external share links are permitted, whether watermarking is mandatory, whether download is allowed at all, minimum encryption, and maximum share expiry | P0 |
| E1-03 | Only an explicitly entitled role may downgrade a label, with mandatory reason and an elevated-severity audit event | P0 |
| E1-04 | AI-suggested classification at ingest (from extracted content) presented to the uploader as a recommendation — never applied silently | P1 |
| E1-05 | **Egress anomaly detection:** download volume per user per rolling window is monitored; a deviation beyond a configured threshold raises a security alert and can trigger soft throttling | P1 |
| E1-06 | Bulk-download and bulk-export of `RESTRICTED` content requires a second approver | P1 |

**Acceptance:** Given a `RESTRICTED` document, when a user attempts to create an external share link, then the request is rejected with `LABEL_POLICY_VIOLATION` regardless of the user's role, and the attempt is audited.

## E2. Retention, Disposition & eDiscovery — P1

*Rationale: legal hold alone is not records management. A regulator needs to prove that records were kept for exactly as long as required and then defensibly destroyed.*

| ID | Requirement | Pri |
|---|---|---|
| E2-01 | **Retention schedules** defined per document class: trigger event (creation, closure, last action), retention period, and disposition action (review / archive permanently / destroy) | P1 |
| E2-02 | Retention is applied by rule, not by hand — a document inherits its schedule from its class, folder or metadata | P1 |
| E2-03 | **Disposition review queue:** eligible records are presented to a records officer for approval before destruction. Nothing is destroyed automatically | P1 |
| E2-04 | Destruction produces a **certificate of destruction** — what, when, under which schedule, approved by whom — retained permanently even though the content is gone | P1 |
| E2-05 | **eDiscovery case:** create a case, run a search across realms (with elevated entitlement), place the result set under hold, and export a production set with a manifest, hash list and chain-of-custody record | P1 |
| E2-06 | A hold placed by an eDiscovery case overrides every retention and archival rule until released | P0 |

## E3. Fixity & Digital Preservation — P0/P1

*Rationale: content that sits on cold storage for fifteen years will suffer bit rot, and nobody will notice unless something checks. This is the single cheapest insurance policy in the system.*

| ID | Requirement | Pri |
|---|---|---|
| E3-01 | **Fixity sweep:** a scheduled background job re-verifies stored checksums across both tiers on a rolling cycle (target: every object verified at least every 90 days) | P0 |
| E3-02 | A fixity failure raises a P1 alert, marks the version, and triggers automatic restore from the replica or backup where available | P0 |
| E3-03 | Fixity results are recorded and reportable — an auditor can be shown when each object was last verified | P0 |
| E3-04 | **PDF/A rendition** generated for documents flagged for long-term preservation, stored alongside the original as a preservation copy | P1 |
| E3-05 | **RFC 3161 trusted timestamping** of the whole-file hash at commit, producing a verifiable integrity certificate that survives independently of ECM | P1 |
| E3-06 | An "integrity certificate" is downloadable for any version: hash, timestamp token, audit extract, chain position | P1 |

**Acceptance:** Given a deliberately corrupted archive object, when the fixity sweep next covers it, then the version is flagged, a P1 alert fires, and a restore is attempted — within one sweep cycle.

## E4. Document Relationships — P1

*Rationale: a central bank's content is inherently a graph. A circular supersedes an earlier circular; an annexure belongs to a master document; a response references a query. Folders cannot express this.*

| ID | Requirement | Pri |
|---|---|---|
| E4-01 | Typed relationships between documents: `SUPERSEDES` / `SUPERSEDED_BY`, `AMENDS` / `AMENDED_BY`, `REFERENCES`, `ANNEXURE_OF`, `RESPONSE_TO`, `DUPLICATE_OF` | P1 |
| E4-02 | Inverse relationships are maintained automatically and cannot drift | P1 |
| E4-03 | Opening a superseded document shows a prominent banner naming the superseding document, with a link | P1 |
| E4-04 | The viewer and search results surface relationship context | P1 |
| E4-05 | A relationship graph view for a document (depth-limited, permission-trimmed) | P2 |

## E5. Bulk Intake & Scanning — P1

*Rationale: paper does not stop arriving because a digital platform exists. Without a governed intake path, scanned documents will be uploaded one at a time through the browser and indexed badly.*

| ID | Requirement | Pri |
|---|---|---|
| E5-01 | **Watched hot-folder ingest:** files dropped into a configured mount are ingested automatically into a target folder with a defined metadata template | P1 |
| E5-02 | **Barcode / QR separator sheet** recognition splits a multi-document scan batch into individual documents and populates the reference number from the code | P1 |
| E5-03 | **Batch indexing queue:** an operator sees scanned documents side by side with an extracted-metadata form and confirms or corrects before release | P1 |
| E5-04 | Failed intake items go to an exception queue with the reason — never silently dropped, never silently released | P1 |
| E5-05 | Intake sources are registered, authenticated and rate-limited like any other client; every ingested item records its source | P1 |

## E6. Notifications, Subscriptions & Saved Searches — P1

*Rationale: a repository nobody is notified about becomes a repository nobody visits.*

| ID | Requirement | Pri |
|---|---|---|
| E6-01 | Watch a document or folder; receive notification on new version, new child, share, permission change or deletion | P1 |
| E6-02 | Digest mode (immediate / daily / weekly) per subscription, honouring the user's notification preferences | P1 |
| E6-03 | Saved searches, re-runnable and optionally subscribable ("notify me when a document matching this query appears") | P1 |
| E6-04 | Notification content is **permission-checked at send time** — a notification must never disclose a title the recipient can no longer see | P0 |
| E6-05 | Admin alerts for quota thresholds, failed jobs, fixity failures, and egress anomalies | P0 |

## E7. Duplicate Detection at Upload — P1

*Rationale: the same circular uploaded forty times is forty times the storage, forty conflicting versions, and a search result page that helps nobody. Detection is nearly free once every file is already hashed.*

| ID | Requirement | Pri |
|---|---|---|
| E7-01 | On commit, if the whole-file hash already exists within the entity, the uploader is shown the existing document and offered: link to it, create a new version of it, or store as a genuinely separate document with a reason | P1 |
| E7-02 | Near-duplicate detection (same name and size, or high text similarity) surfaced as a softer warning | P2 |
| E7-03 | An admin report lists exact duplicates per entity with reclaimable bytes | P1 |

## E8. Access Review & Permission Explorer — P0/P1

*Rationale: "who can see this document?" is the question an auditor asks, and in an inherited-ACL model with Kavach group expansion it is genuinely hard to answer by inspection.*

| ID | Requirement | Pri |
|---|---|---|
| E8-01 | **Effective-permissions view** for any folder or document: every principal who can reach it, which permission they hold, and *why* (direct grant / inherited from which ancestor / via which Kavach group / via which role) | P0 |
| E8-02 | Reverse view: for any user, every folder and document they can reach in a realm | P0 |
| E8-03 | **Access review campaigns:** a scheduled recertification in which owners confirm or revoke access to sensitive folders; unconfirmed grants expire | P1 |
| E8-04 | Permission-change history per resource, exportable for audit | P0 |
| E8-05 | A "what would change" preview before applying an ACL change to a subtree | P1 |

## E9. Webhooks, Host SDK & Sandbox Realm — P1

*Rationale: the platform goal is for other applications to stop building their own storage. That only happens if integrating is genuinely easy and safe to trial.*

| ID | Requirement | Pri |
|---|---|---|
| E9-01 | **Outbound webhooks** to registered host applications on document lifecycle events (committed, new version, moved, deleted, classification changed, workflow completed), signed with HMAC, with retry and dead-letter | P1 |
| E9-02 | Webhook payloads carry identifiers and metadata only, **never content**, and are permission-scoped to what the host application may see | P0 |
| E9-03 | Published client SDKs — Java and TypeScript — wrapping auth, resumable upload, download with range, and viewer-token minting | P1 |
| E9-04 | A **sandbox realm** with synthetic data where a host application can complete a full integration before touching production content | P1 |
| E9-05 | Per-host-application dashboard: call volume, error rate, quota, webhook delivery health | P1 |

## E10. Asynchronous Operations Framework — P0

*Rationale: bulk move, bulk export, archival, rehydration, redaction and reindex are all long-running. Without one consistent pattern each will invent its own and none will be observable.*

| ID | Requirement | Pri |
|---|---|---|
| E10-01 | Every long-running action returns `202 Accepted` with an **operation resource**: id, type, status, progress, item counts, started/finished, errors | P0 |
| E10-02 | Operations are cancellable where the underlying work permits, and always resumable or safely restartable | P0 |
| E10-03 | Partial failure is first-class: an operation reports per-item outcomes and never silently succeeds on a subset | P0 |
| E10-04 | Users see their own operations in an activity panel; admins see all operations across the realm | P0 |
| E10-05 | Operations are idempotent by `Idempotency-Key` — a retried submission joins the existing operation rather than starting a second one | P0 |

## E11. Per-User Quota & Storage Governance — P1

*Rationale: entity-level quota alone means one user can consume an entire entity's allocation.*

| ID | Requirement | Pri |
|---|---|---|
| E11-01 | Per-user quota within the PRIVATE root, defaulted per entity and overridable per user | P1 |
| E11-02 | Users see their own consumption with a breakdown by tier and file type | P1 |
| E11-03 | Storage forecast on the admin dashboard: projected date of quota exhaustion per entity based on trailing growth | P1 |
| E11-04 | "Largest files", "oldest untouched files" and "duplicate files" reports to make reclamation actionable rather than abstract | P1 |

## E12. Encryption Key Management (Per-Realm BYOK) — P1

*Rationale: realm isolation is not complete while every realm's content is protected by one key. Cryptographic separation is what makes isolation defensible to an auditor.*

| ID | Requirement | Pri |
|---|---|---|
| E12-01 | Content encryption keys are per realm, wrapped by a master key held in the platform HSM/KMS | P1 |
| E12-02 | Key rotation without content rewrite — envelope encryption, so rotation re-wraps data keys rather than re-encrypting bytes | P1 |
| E12-03 | Crypto-shredding: destroying a realm's key renders its content unrecoverable, recorded as a disposition event | P1 |
| E12-04 | Key usage is audited; key material never appears in logs, backups of the application schema, or diagnostic exports | P0 |

---

# PART III — TECHNICAL SPECIFICATION

## 13. Service Decomposition *(F-15)*

**Decision:** five deployable services in v1, not nine. Distribution is paid for only where the workload genuinely differs. Module boundaries inside each service are hard, and the split path to more services is designed but not executed.

| Service | Owns (write authority) | Scaling driver |
|---|---|---|
| `ecm-gateway` | nothing | request rate |
| `ecm-core-service` | realms, entities, folders, documents, versions, ACL, locks, metadata, workflow, sharing, audit sink | metadata QPS |
| `ecm-content-service` | chunks, upload sessions, archive objects, tier state | byte throughput, I/O |
| `ecm-archival-service` | tier transitions, retention jobs, reconciliation | batch windows |
| `ecm-ai-search-service` | search index, embeddings, OCR/extraction artefacts | CPU/GPU, queue depth |

**Ownership rule:** exactly one service holds write authority over any table group. Cross-boundary reads go through APIs, not shared SQL. This rule is enforced by an architecture test in CI (package-dependency assertions).

## 14. Package Structure — `org.rebit.ecm`

```
org.rebit.ecm
├── common/            shared kernel: ids, errors, problem-details, pagination, tenancy context
├── security/          Kavach adapter SPI, JWT validation, permission evaluator, mock provider
├── gateway/
├── core/
│   ├── realm/  entity/  folder/  document/  version/  acl/  lock/  metadata/
│   ├── workflow/  sharing/  audit/
├── content/
│   ├── chunk/  session/  stream/  integrity/  tier/
├── archival/
│   ├── policy/  job/  rehydrate/  retention/  reconcile/
└── aisearch/
    ├── index/  query/  ocr/  extract/  embed/  redact/
```

Each module follows ports-and-adapters: `api` (controllers, DTOs) → `application` (use cases, transactions) → `domain` (entities, value objects, rules, **no framework imports**) → `infrastructure` (JPA, JDBC, filesystem, HTTP clients).

## 15. Persistence *(F-16)*

- **Production:** Oracle 19c. SecureFiles LOBs for chunk data on a dedicated LOB tablespace. Hash partitioning (64) on `ECM_CONTENT_CHUNK` by version id. Monthly interval-range partitioning on `ECM_AUDIT_EVENT`. VPD policy enforcing realm predicate.
- **Development:** SQLite, schema-compatible. **SQLite is a developer convenience and never a correctness authority.**
- **CI rule:** the full integration suite runs against a real Oracle container on every merge to `main`. A green SQLite build is not a merge criterion by itself.
- No vendor SQL outside `infrastructure`. Flyway with `db/migration/common`, `db/migration/oracle`, `db/migration/sqlite`.
- Identifiers: **ULID stored as `CHAR(26)`** — sortable, portable, no sequence dependency, no cross-dialect UUID handling.
- Realm isolation is implemented **twice**: in the repository layer (portable) and by Oracle VPD (defence in depth).

## 16. API Standards *(F-17)*

| Concern | Standard |
|---|---|
| Versioning | URI path: `/api/v1/...` |
| Errors | RFC 9457 Problem Details with a stable `type` URN per error code |
| Pagination | Cursor-based (`cursor`, `limit`), never offset, on all collections |
| Mutations | `Idempotency-Key` header required on POST/PUT/PATCH/DELETE |
| Long-running work | `202 Accepted` + operation resource with poll URL |
| Correlation | `X-Correlation-Id` accepted and propagated; generated if absent |
| Streaming | `Range` supported on all content endpoints; strong `ETag` = content hash; `Cache-Control: private` |
| Events | Transactional outbox → relay → bus; consumers idempotent by event id |

---

# PART IV — INTEGRATION SPECIFICATION

## 17. Kavach (Identity & Access Management)

ECM performs **zero** authentication. It validates and consumes.

| ID | Requirement | Pri |
|---|---|---|
| INT-KV-01 | ECM validates the Kavach JWT: signature (JWKS with cached rotation), issuer, audience, expiry, not-before, and realm claim | P0 |
| INT-KV-02 | Subject, realm, roles and group memberships are extracted from the token and/or resolved via Kavach API | P0 |
| INT-KV-03 | Authorisation policies (role assignment, group membership, resource-level checks) are driven by Kavach; **ECM enforces but never independently defines identity** | P0 |
| INT-KV-04 | Document/folder ACLs map onto Kavach roles and groups | P0 |
| INT-KV-05 | Authorisation-decision cache TTL ≤ 60 s; invalidated synchronously on ACL change, share revocation, group-membership change event and user deprovisioning *(F-10)* | P0 |
| INT-KV-06 | **Mock Kavach provider** behind the same SPI for dev and test: local key pair, seeded realms/users/roles/groups, deterministic token minting, switchable by profile. No production code path differs | P0 |
| INT-KV-07 | Token exchange for reduced-scope viewer tokens where Kavach supports it; otherwise ECM mints its own capability tokens signed with an ECM key and bound as per FR-VW-01 | P0 |

## 18. Host Applications

| ID | Requirement | Pri |
|---|---|---|
| INT-HA-01 | Host backends authenticate as service principals with their own client credentials and are rate-limited per principal | P0 |
| INT-HA-02 | Viewer token minting is a backend-to-backend call only; the endpoint rejects browser-origin requests | P0 |
| INT-HA-03 | The Angular viewer library is published to the internal npm registry as `@rebit/ecm-viewer`, semver'd, with a Web Component build for non-Angular hosts | P0 |
| INT-HA-04 | An integration guide with a runnable sample host application ships with the library | P0 |

## 19. Platform Services

| ID | Dependency | Requirement | Degradation posture |
|---|---|---|---|
| INT-PS-01 | Event bus | Async indexing, OCR dispatch, audit fan-out | Outbox retains; catch-up on recovery |
| INT-PS-02 | Antivirus | Scan before content becomes visible; `QUARANTINED` state on positive *(F-12)* | **Fail closed** — no scan, no visibility |
| INT-PS-03 | Notification service | Share, approval, quota and job alerts | Degrade to in-app only |
| INT-PS-04 | Archive storage (NFS / object) | Cold tier under `/ECM/` | Read paths for HOT content unaffected; archived reads fail with a clear error, uploads continue |
| INT-PS-05 | Search engine | Index and query | File manager, upload, download and viewer remain fully functional; search UI shows a degraded banner |
| INT-PS-06 | AI/OCR workers | OCR, extraction, embeddings | Documents ingest normally and are queued for later processing |
| INT-PS-07 | Logging / monitoring / tracing | Structured logs, metrics, traces | — |

---

# PART V — NON-FUNCTIONAL, SECURITY, UX, TEST, DELIVERY

## 20. Non-Functional Requirements *(F-23)*

### 20.1 Capacity model

| Dimension | GA target | 3-year projection |
|---|---|---|
| Concurrent active users | 5,000 | 15,000 |
| Documents | 50 million | 250 million |
| Logical bytes | 40 TB | 200 TB |
| Daily ingest | 250 GB | 1 TB |
| Peak upload concurrency | 200 streams | 600 streams |

### 20.2 Performance

| Operation | Target |
|---|---|
| Folder listing (100 items) p95 | < 300 ms |
| Metadata read p95 | < 150 ms |
| TTFB, HOT tier | < 500 ms |
| TTFB, ARCHIVED tier (stream-through) | < 3 s |
| Upload 100 MB p95 | < 20 s |
| Search query p95 | < 800 ms |
| Viewer first page render (PDF, hot) | < 1.5 s |

### 20.3 Availability, DR, backup

| Concern | Commitment |
|---|---|
| Availability (read paths) | 99.5% monthly |
| RPO | ≤ 15 minutes |
| RTO | ≤ 4 hours |
| Backup — DB tier | Oracle RMAN incremental + archive-log shipping |
| Backup — archive tier | Replicated mount / object versioning; independent restore test quarterly |
| **Restore drill** | Quarterly, including a full round-trip integrity verification of a sampled 1,000 documents |

### 20.4 Caching

| Layer | Contents | Invalidation |
|---|---|---|
| L1 in-process (Caffeine) | Folder metadata, format registry, entity config, authz decisions | TTL ≤ 60 s + event-driven eviction |
| L2 distributed (Redis/Valkey) | Chunk bytes (small files), rendered previews, thumbnails, OCR text | Keyed by content hash — immutable, so no invalidation needed |
| HTTP | Content responses | Strong `ETag` = content hash; `private`; versioned URLs are immutable |

Because L2 keys are content hashes and versions are immutable, cache entries never go stale — only evicted by capacity.

### 20.5 Observability

Structured JSON logs with trace/correlation ids · RED metrics per endpoint · tier-distribution and queue-depth gauges · distributed tracing across all hops · alert thresholds defined per §20.2 target with a documented runbook per alert.

## 21. Security Requirements

| ID | Requirement |
|---|---|
| SEC-01 | TLS 1.3 in transit; TDE or column-level encryption at rest for chunk data; archive objects encrypted at rest with keys held in the platform HSM/KMS |
| SEC-02 | Realm isolation enforced at the data layer (VPD) **and** the repository layer |
| SEC-03 | Audit tamper-evidence: append-only via a dedicated schema owner, per-row hash chain `event_hash = H(prev_hash ‖ canonical_event)`, daily sealed digest, scheduled chain verification with alert on break *(F-11)* |
| SEC-04 | Every uploaded file scanned before visibility; `QUARANTINED` content is invisible to search, preview, download and the viewer widget, retained under hold for forensics *(F-12)* |
| SEC-05 | Preview conversion and rasterisation run in a sandboxed, network-isolated, resource-capped, ephemeral worker with a hard timeout *(F-14)* |
| SEC-06 | Active content disabled in previewed documents (PDF JavaScript, embedded objects, SVG scripts sanitised) |
| SEC-07 | Strict CSP on both Angular applications and the widget; the iframe embed mode uses `sandbox` with an explicit allowlist |
| SEC-08 | No sensitive data in URLs, logs or error messages; share and viewer tokens stored hashed |
| SEC-09 | Rate limiting per principal and per host application; enumeration detection on identifier-bearing endpoints |
| SEC-10 | Break-glass admin access to PRIVATE content requires reason, is time-boxed and raises an elevated audit event |
| SEC-11 | Dependency and container scanning in CI; no build ships with a known critical CVE |

## 22. UX & Design System

### 22.1 Platform shell (per the reference screens)

Persistent shell across both applications: RBI lockup and application identity at left · dark-mode toggle · **A- / A / A+ text scaling** · language selector (Eng/हिं) · notifications · user identity with role and last-signed-in · application switcher grid · collapsible dark navigation rail with About and Collapse pinned to the bottom.

### 22.2 Design tokens (derived from the reference screens)

| Token | Value | Use |
|---|---|---|
| `--ecm-nav-bg` | `#0B1836` → `#152449` gradient | Navigation rail |
| `--ecm-nav-active` | `#1A56DB` | Active rail item |
| `--ecm-primary` | `#1A56DB` | Primary buttons, links |
| `--ecm-primary-hover` | `#1544AE` | Hover |
| `--ecm-accent` | `#2B7FBF` | Section headings |
| `--ecm-surface` | `#FFFFFF` | Cards, tables |
| `--ecm-canvas` | `#F7F8FA` | Page background |
| `--ecm-border` | `#E3E8EF` | Dividers, table rules |
| `--ecm-text` | `#1F2937` | Primary text |
| `--ecm-text-muted` | `#6B7280` | Secondary text, hints |
| `--ecm-info-bg` / `--ecm-info-fg` | `#EAF1FE` / `#1A56DB` | Rule banners (e.g. mount-point rule) |
| `--ecm-status-pending-bg` / `-fg` | `#FDF0E3` / `#C2700B` | *Sent for Approval* pill |
| `--ecm-status-approved-bg` / `-fg` | `#E7F6EC` / `#1E7B3C` | *Approved* pill |
| `--ecm-status-rejected-bg` / `-fg` | `#FDECEC` / `#C0392B` | *Rejected* pill |
| `--ecm-radius` | `8px` | Cards, inputs, buttons |
| Type | Humanist sans; display 600, body 400; scale 12/14/16/20/24/32 | Rem-based so A-/A/A+ scales the whole UI |

Every token is a CSS custom property so the widget re-themes inside a host application without a rebuild.

### 22.3 Accessibility *(F-25)*

WCAG 2.1 AA overall, plus component-specific obligations: the folder tree implements full ARIA `tree`/`treeitem` semantics with type-ahead and keyboard traversal; the PDF viewer exposes the text layer to screen readers with page-boundary announcements; media players require caption-track support and keyboard-accessible transport; all zoom, rotate and search controls are keyboard-reachable; contrast ≥ 4.5:1 including status pills; `prefers-reduced-motion` respected; focus is visible and never trapped.

### 22.4 Localisation *(F-24)*

English and Hindi at GA. Consequences by layer: OCR requires Devanagari language packs; the search index requires an Indic analyzer and correct tokenisation; the database requires `AL32UTF8` and a defined linguistic collation for sorting; the viewer requires fonts with full Devanagari coverage; date, number and file-size formatting are locale-aware.

## 23. Test Strategy & Definition of Done *(F-27)*

| Layer | Approach | Gate |
|---|---|---|
| Domain | Pure unit tests, no Spring context, no DB | ≥ 85% line coverage on `domain` |
| Application | Use-case tests with mocked ports | ≥ 80% |
| Adapters | Slice tests (`@DataJpaTest`, `@WebMvcTest`) | all public adapters |
| API contract | Spring Cloud Contract or equivalent against the published OpenAPI | every endpoint |
| Integration | Testcontainers: **real Oracle 19c**, real archive mount, real search engine | on every merge to `main` |
| Storage integrity | Property test: random content → chunk → commit → archive → release → rehydrate → byte-identical, across sizes 0 B, 1 B, chunk-1, chunk, chunk+1, 100 MB, 1 GB | must pass |
| Concurrency | Parallel check-out/check-in, parallel rehydration of one version, parallel quota consumption at the boundary | must pass |
| Authorisation | Generated matrix: every role × every resource type × every operation × (own realm / other realm) | 100% of cells asserted |
| Performance | k6 profiles against §20.2 targets | nightly; regression blocks release |
| Security | SAST, dependency scan, container scan, ZAP baseline on both UIs | no critical findings |
| Accessibility | axe-core in CI on all primary screens plus manual screen-reader pass per release | no serious violations |

**Definition of Done** for any story: code + tests at the coverage gate, OpenAPI updated, migration written for both dialects and applied cleanly forward, audit events emitted for every state change, metrics and one alert defined where relevant, error paths returning problem details, accessibility check passed, documentation updated, and a demonstrable end-to-end path through the UI.

## 24. Delivery Plan *(F-26, F-28)*

| Phase | Outcome — each phase ends in something demonstrable | Duration |
|---|---|---|
| **Phase 0 — Walking skeleton** | One user logs in with a mock Kavach token, uploads one PDF into a Public folder, it is chunked into the DB, listed in the file manager, downloaded byte-identical, and every step appears in the audit trail. Both Angular shells exist. Oracle + SQLite migrations run. | 4 weeks |
| **Phase 1 — Repository** | Full folder tree, multi-link documents, versions, check-out/check-in, recycle bin, ACL enforcement, entity config with maker–checker, quota enforcement, **sensitivity labels (E1-01…03)**, **effective-permissions view (E8-01…02, E8-04)**, **async operations framework (E10)**. | 7 weeks |
| **Phase 2 — Storage lifecycle** | Archival policies, tier state machine, stream-through, rehydration with locking and promotion, reconciliation, legal hold, resumable uploads, **fixity sweeps (E3-01…03)**, **duplicate detection (E7)**, **per-user quota (E11)**. | 7 weeks |
| **Phase 3 — Access & discovery** | Search with permission trimming, share links with policy ceilings, OCR ingest, viewer token service, **viewer widget library v1** (PDF, image, media, text), **webhooks + host SDK + sandbox realm (E9)**, **notifications and saved searches (E6)**. | 9 weeks |
| **Phase 4 — Intelligence & records** | Extraction, semantic search, redaction pipeline, annotations, dashboards, bulk import/export, **retention schedules, disposition review and eDiscovery (E2)**, **document relationships (E4)**, **bulk intake and scanning (E5)**, **DLP egress detection (E1-05…06)**. | 10 weeks |
| **Phase 5 — Scale & hardening** | Performance tuning, DR drill, DB archival, chargeback, multi-realm rollout, **PDF/A and RFC 3161 timestamping (E3-04…06)**, **per-realm BYOK (E12)**, **access review campaigns (E8-03)**. | 8 weeks |

**Rollout:** expand/contract schema migrations only (never a breaking change in one step) · feature flag per capability · canary by realm, starting with a single low-risk entity · documented backout per phase · a "shadow read" period where a legacy store and ECM are both readable before cut-over.

## 25. Decision Log

| # | Decision | Rationale |
|---|---|---|
| D1 | Realm (identity) and Entity (storage/policy) are distinct, nested concepts | Removes the single biggest ambiguity in the source spec |
| D2 | DB-first ingest, with a per-entity size threshold above which content goes straight to archive | Keeps the DB as system of record for the common case without blowing up redo/backup on the tail |
| D3 | Archived content is served stream-through; rehydration is asynchronous, locked and gated by a promotion policy | Removes the latency cliff and the thundering herd |
| D4 | Viewer widgets use backend-minted, short-lived, single-purpose capability tokens; ACL is re-checked on every stream | The naïve "pass a file id" contract is an IDOR |
| D5 | Five services in v1, one write-owner per table group, enforced by an architecture test | Avoids a distributed monolith while keeping the split path open |
| D6 | Oracle is the correctness authority in CI; SQLite is a developer convenience | Prevents "works locally, fails in prod" |
| D7 | ULID `CHAR(26)` identifiers | Portable across both dialects, sortable, unguessable |
| D8 | Deduplication deferred but designed for (`ref_count` + content-hash index from day one) | Avoids a painful migration later without paying the complexity now |
| D9 | Audit tamper-evidence by hash chain + daily sealed digest | Makes "immutable" a mechanism rather than a claim |
| D10 | Storage tiers are chosen from a governed list; custom values require checker approval | Reconciles the two conflicting reference screens and keeps capacity governable |
| D11 | Sensitivity labels are the policy carrier; watermarking, sharing, download and encryption rules derive from them | Turns per-document configuration into declarative policy, and makes DLP enforceable |
| D12 | Fixity sweeps from Phase 2, not "later" | Bit rot on a fifteen-year archive is silent; this is the cheapest insurance in the system |
| D13 | One asynchronous operations framework, used by every long-running action | Prevents six bespoke progress mechanisms and makes bulk work observable |
| D14 | Per-realm envelope encryption with HSM-held master key | Makes realm isolation cryptographic rather than merely logical; enables crypto-shredding |
| D15 | Nothing is ever destroyed automatically — disposition requires human approval and yields a certificate | Defensible destruction is a records-management requirement, not a nicety |

## 26. Open Questions

| # | Question | Owner | Blocking |
|---|---|---|---|
| Q1 | Does Kavach support OAuth2 token exchange (RFC 8693) for reduced-scope viewer tokens, or does ECM mint its own capability tokens? | Kavach team | **Yes** |
| Q2 | Approved search engine — Elasticsearch, OpenSearch, or Oracle Text? | Platform architecture | **Yes** |
| Q3 | Archive tier medium: NFS, S3-compatible object storage, or both? Durability and latency guarantees? | Infrastructure | **Yes** |
| Q4 | Confirmed RPO/RTO and DR topology (active-passive, active-active)? | Infrastructure | **Yes** |
| Q5 | Optimus UI version compatible with Angular 21, and its theming API | Frontend platform | **Yes** |
| Q6 | Licensed on-premise OCR engine, and Devanagari pack availability | Procurement | No |
| Q7 | Is aggregate search telemetry permitted under platform privacy policy? | Compliance | No |
| Q8 | Retention schedule per document class under RBI record policy | Compliance | No |
| Q9 | Approved vector store for embeddings, or must they live in Oracle? | Architecture | No |
| Q10 | Antivirus service interface and SLA for scan latency | Security | No |
| Q11 | Does the institution have an approved sensitivity-classification taxonomy ECM must adopt rather than define? | Compliance / Security | No |
| Q12 | Is an RFC 3161 timestamping authority available on-premise, and is PDF/A mandated for any document class? | Compliance / Infrastructure | No |
| Q13 | Who is the designated records officer role for disposition approval, and does it exist in Kavach? | Records / Kavach | No |
| Q14 | Does the platform HSM/KMS support per-realm data-key wrapping and rotation via API? | Security / Infrastructure | No |
| Q15 | Are scanning stations and hot-folder mounts in scope for the ECM network zone, or a separate intake zone? | Infrastructure | No |

---

*End of PRD v2.1. Baselined for architecture and build.*
