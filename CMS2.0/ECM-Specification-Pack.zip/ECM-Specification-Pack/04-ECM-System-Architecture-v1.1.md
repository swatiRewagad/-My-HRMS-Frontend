# ECM — System Architecture Document
## v1.1 · Baselined against PRD v2.1

| Field | Value |
|---|---|
| System | Enterprise Content Management (ECM) |
| Programme | RBI Enterprise Platform · ReBIT |
| Root package | `org.rebit.ecm` |
| Runtime | Java 21 (virtual threads) · Spring Boot 3.4+ · Angular 21 |
| Data | Oracle 19c partitioned (prod) · SQLite (dev) · Redis/Valkey (cache) · OpenSearch/Elasticsearch (index) |
| Deployment | OpenShift — ECM as a namespace/cluster within the Enterprise Platform |
| Diagram source | Mermaid (renders in GitLab, Confluence, VS Code) |

---

## 1. Architectural Principles

1. **Kavach is the only source of identity.** ECM validates and enforces; it never authenticates, stores credentials, or invents a principal.
2. **The database is the system of record for metadata always, and for bytes by policy.** Filesystem is a cost tier, never a truth tier.
3. **Immutability where it buys safety.** Versions and chunks are immutable; caches keyed by content hash therefore never go stale.
4. **Domain code is framework-free.** `domain` packages import nothing from Spring, JPA or Jackson.
5. **One write-owner per table group.** Enforced by an ArchUnit test, not by convention.
6. **Portable by construction.** No vendor SQL outside `infrastructure`; Oracle is the CI correctness authority.
7. **Fail closed on security, fail open on convenience.** No AV scan → no visibility. Search down → everything else still works.

---

## 2. Context — C4 Level 1

```mermaid
graph TB
    subgraph Users
        BU["Business User<br/>(Angular Workspace)"]
        AD["Platform Admin / Maker / Checker<br/>(Angular Admin Console)"]
        AU["Auditor"]
    end

    subgraph Hosts["Host Applications on the Enterprise Platform"]
        IPS["Invoice Processing System"]
        CMS["CMS 2.0 / Other Modules"]
        HOST["...embedding @rebit/ecm-viewer"]
    end

    ECM["<b>ECM</b><br/>Enterprise Content Management<br/>org.rebit.ecm"]

    KV["Kavach<br/>IAM — JWT / OIDC"]
    ORA[("Oracle 19c<br/>partitioned")]
    ARC[("Archive Tier<br/>/ECM/ mount — NFS / Object")]
    IDX[("Search Index")]
    CACHE[("Redis / Valkey")]
    AV["Antivirus Service"]
    BUS["Platform Event Bus"]
    OBS["Logging · Metrics · Tracing"]

    BU --> ECM
    AD --> ECM
    AU --> ECM
    IPS --> ECM
    CMS --> ECM
    HOST --> ECM

    ECM -->|validate JWT, resolve roles/groups| KV
    ECM --> ORA
    ECM --> ARC
    ECM --> IDX
    ECM --> CACHE
    ECM -->|scan before visibility| AV
    ECM --> BUS
    ECM --> OBS
```

---

## 3. Containers — C4 Level 2

```mermaid
graph TB
    subgraph FE["Frontend — Angular 21 · Optimus UI"]
        ADMIN["ecm-admin-console<br/>entity config · policies · health"]
        WORK["ecm-user-workspace<br/>file manager · search · viewer"]
        LIB["@rebit/ecm-viewer<br/>library + Web Component"]
    end

    GW["<b>ecm-gateway</b><br/>routing · JWT validation<br/>rate limit · correlation"]

    subgraph SVC["ECM Service Cluster"]
        CORE["<b>ecm-core-service</b><br/>realm · entity · folder · document<br/>version · acl · lock · metadata<br/>workflow · sharing · audit"]
        CONT["<b>ecm-content-service</b><br/>chunk · upload session · stream<br/>integrity · tier read/write"]
        ARCH["<b>ecm-archival-service</b><br/>policy · archive job · rehydrate<br/>retention · reconcile"]
        AIS["<b>ecm-ai-search-service</b><br/>index · query · ocr · extract<br/>embed · redact · render"]
    end

    ORA[("Oracle 19c<br/>ECM schema")]
    ARCF[("/ECM/ archive mount")]
    RED[("Redis / Valkey")]
    OS[("Search Index")]
    BUS[["Event Bus"]]
    KV["Kavach"]

    ADMIN --> GW
    WORK --> GW
    LIB --> GW

    GW --> CORE
    GW --> CONT
    GW --> AIS
    GW --> KV

    CORE -->|owns metadata tables| ORA
    CONT -->|owns chunk + session tables| ORA
    ARCH -->|owns tier + job tables| ORA
    CONT --> ARCF
    ARCH --> ARCF
    AIS --> OS
    CORE --> RED
    CONT --> RED
    AIS --> RED

    CORE -.outbox.-> BUS
    CONT -.outbox.-> BUS
    BUS -.-> AIS
    BUS -.-> ARCH

    CONT -->|read manifest / ACL| CORE
    ARCH -->|tier state updates| CONT
```

**Write authority (non-negotiable):**

| Table group | Owner |
|---|---|
| `ECM_REALM`, `ECM_ENTITY_CONFIG`, `ECM_FOLDER*`, `ECM_DOCUMENT*`, `ECM_VERSION`, `ECM_ACL`, `ECM_LOCK`, `ECM_METADATA*`, `ECM_WORKFLOW*`, `ECM_SHARE*`, `ECM_AUDIT_EVENT` | `ecm-core-service` |
| `ECM_CONTENT_CHUNK`, `ECM_UPLOAD_SESSION`, `ECM_ARCHIVE_OBJECT`, `ECM_VERSION_TIER` | `ecm-content-service` |
| `ECM_ARCHIVAL_POLICY`, `ECM_JOB_RUN`, `ECM_TIER_TRANSITION`, `ECM_QUOTA_RECON` | `ecm-archival-service` |
| Search index, embeddings, OCR artefacts | `ecm-ai-search-service` |

---

## 4. Package Architecture — `org.rebit.ecm`

```
org.rebit.ecm
├─ common
│   ├─ id            UlidId, DocumentId, VersionId, FolderId, RealmId, EntityId
│   ├─ error         EcmException hierarchy, ProblemDetailFactory, ErrorCode
│   ├─ page          Cursor, Page<T>, CursorCodec
│   ├─ tenancy       TenancyContext, RealmScope, TenancyContextHolder
│   └─ time          Clock provider (never Instant.now() in domain)
├─ security
│   ├─ spi           IdentityProvider, PrincipalResolver, TokenValidator   ← interfaces
│   ├─ kavach        KavachIdentityProvider, JwksCache, KavachClient       ← prod adapter
│   ├─ mock          MockIdentityProvider, MockTokenMinter, seed data      ← dev/test adapter
│   ├─ authz         PermissionEvaluator, AclResolver, DecisionCache
│   └─ capability    ViewerTokenMinter, ViewerTokenVerifier
├─ gateway
├─ core
│   ├─ realm      · api · application · domain · infrastructure
│   ├─ entity     · (entity config, quota, mount point, maker-checker)
│   ├─ folder     · (tree, closure, materialised path, folder class)
│   ├─ document   · (document, links, state machine, recycle bin)
│   ├─ version    · (immutable versions, restore, manifest)
│   ├─ acl        · lock · metadata
│   ├─ workflow   · (maker-checker engine)
│   ├─ sharing    · (share links, policy ceilings)
│   ├─ audit      · (hash-chained append-only sink, digest sealer)
│   ├─ label      · (sensitivity classification, label-driven policy resolver)   [E1]
│   ├─ relation   · (typed document relationships, inverse maintenance)          [E4]
│   ├─ subscribe  · (watches, saved searches, digest scheduler)                  [E6]
│   ├─ operation  · (async operation resource, progress, cancellation)           [E10]
│   ├─ review     · (effective permissions, reverse view, access campaigns)      [E8]
│   └─ webhook    · (registration, HMAC signing, retry, dead-letter)             [E9]
├─ content
│   ├─ session    · (resumable upload sessions, idempotency, reaper)
│   ├─ chunk      · (chunker, chunk repository, ref counting)
│   ├─ stream     · (range reads, stream-through, ETag)
│   ├─ integrity  · (SHA-256 per chunk + whole file, verifier)
│   ├─ tier       · (tier state machine, DB↔archive movers, locks)
│   ├─ crypto     · (envelope encryption, per-realm data keys, KMS client)       [E12]
│   └─ intake     · (hot folder watcher, barcode split, batch queue)             [E5]
├─ archival
│   ├─ policy · job · rehydrate · retention · legalhold · reconcile
│   ├─ fixity     · (rolling checksum sweep, corruption detection, restore)      [E3]
│   ├─ disposition· (retention schedules, review queue, destruction certificate) [E2]
│   └─ ediscovery · (case, collection, production set, chain of custody)         [E2]
└─ aisearch
    ├─ index · query · ocr · extract · embed · redact · render
    └─ preserve   · (PDF/A rendition, RFC 3161 timestamping)                     [E3]
```

Every module: `api` → `application` → `domain` ← `infrastructure`. Dependencies point inward only; ArchUnit asserts it.

---

## 5. Data Architecture

### 5.1 Entity–relationship (core)

```mermaid
erDiagram
    ECM_REALM ||--o{ ECM_ENTITY_CONFIG : contains
    ECM_ENTITY_CONFIG ||--o{ ECM_FOLDER : roots
    ECM_ENTITY_CONFIG ||--|| ECM_ARCHIVAL_POLICY : governed_by
    ECM_FOLDER ||--o{ ECM_FOLDER : parent_of
    ECM_FOLDER ||--o{ ECM_FOLDER_CLOSURE : ancestor
    ECM_FOLDER ||--o{ ECM_DOCUMENT_FOLDER_LINK : holds
    ECM_DOCUMENT ||--o{ ECM_DOCUMENT_FOLDER_LINK : linked_via
    ECM_DOCUMENT ||--o{ ECM_VERSION : has
    ECM_VERSION ||--o{ ECM_CONTENT_CHUNK : split_into
    ECM_VERSION ||--o| ECM_ARCHIVE_OBJECT : sealed_as
    ECM_VERSION ||--|| ECM_VERSION_TIER : tier_state
    ECM_DOCUMENT ||--o{ ECM_ACL : secured_by
    ECM_FOLDER ||--o{ ECM_ACL : secured_by
    ECM_DOCUMENT ||--o| ECM_LOCK : locked_by
    ECM_DOCUMENT ||--o{ ECM_DOCUMENT_METADATA : described_by
    ECM_DOCUMENT ||--o{ ECM_SHARE_LINK : shared_via
    ECM_DOCUMENT ||--o{ ECM_LEGAL_HOLD : held_by
    ECM_ENTITY_CONFIG ||--o{ ECM_UPLOAD_SESSION : receives
    ECM_VERSION ||--o{ ECM_TIER_TRANSITION : moved_by
```

### 5.2 Key tables

| Table | Purpose | Oracle partitioning |
|---|---|---|
| `ECM_REALM` | Kavach realm registration | none |
| `ECM_ENTITY_CONFIG` | Entity, quota tier, mount point, extension allowlist, doc size cap, chunk size, `db_first_max_bytes`, maker/checker status | none |
| `ECM_FOLDER` | Tree node, `folder_class` (PUBLIC/PRIVATE/RESTRICTED), materialised path, owner | list by `realm_id` |
| `ECM_FOLDER_CLOSURE` | (ancestor, descendant, depth) for subtree and ACL rollup | list by `realm_id` |
| `ECM_DOCUMENT` | Logical document, current version, state (ACTIVE / CHECKED_OUT / QUARANTINED / SOFT_DELETED / EXPUNGED), `last_accessed_at`, `read_count_window` | list by `realm_id` |
| `ECM_DOCUMENT_FOLDER_LINK` | N:M links, `link_type` PRIMARY/SECONDARY | — |
| `ECM_VERSION` | Immutable version: size, whole-file SHA-256, chunk size, chunk count, `ingest_mode` (DB_FIRST / DIRECT_ARCHIVE) | — |
| `ECM_VERSION_TIER` | Tier state machine row: state, archive pointer, rehydration lock, attempt count | list by `tier_state` |
| `ECM_CONTENT_CHUNK` | `version_id, seq_no, byte_offset, byte_length, chunk_sha256, ref_count, data BLOB` | **hash(version_id) × 64**, SecureFiles on a dedicated LOB tablespace |
| `ECM_ARCHIVE_OBJECT` | mount point, relative path, size, checksum, sealed_at, policy_id | — |
| `ECM_UPLOAD_SESSION` | session, entity, expected size/hash, received chunk bitmap, expiry | range by `created_at` |
| `ECM_ACL` | resource_type, resource_id, principal_type/id, permission bitmask, inherited flag | list by `realm_id` |
| `ECM_AUDIT_EVENT` | event, actor, resource, before/after, `prev_hash`, `event_hash` | **interval range monthly** on `event_time` |
| `ECM_OUTBOX` | transactional event outbox with relay cursor | range by `created_at` |
| `ECM_TIER_TRANSITION` | audit of every move with policy attribution | interval range monthly |

**v2.1 capability tables**

| Table | Purpose | Oracle partitioning |
|---|---|---|
| `ECM_LABEL_POLICY` | Sensitivity label → policy matrix (share, watermark, download, encryption, max expiry) | none |
| `ECM_DOC_RELATION` | `from_doc, to_doc, relation_type`; inverse maintained by the application, never by trigger | list by `realm_id` |
| `ECM_SUBSCRIPTION` | Watches and saved searches, digest mode, last-sent cursor | — |
| `ECM_OPERATION` / `ECM_OPERATION_ITEM` | Async operation header plus per-item outcome | range by `created_at` |
| `ECM_WEBHOOK` / `ECM_WEBHOOK_DELIVERY` | Host registration, HMAC secret reference, delivery attempts, dead-letter | range by `created_at` |
| `ECM_FIXITY_RESULT` | Per-object verification history: when checked, outcome, remediation | interval range monthly |
| `ECM_RETENTION_SCHEDULE` / `ECM_DISPOSITION_REVIEW` / `ECM_DESTRUCTION_CERT` | Records lifecycle; the certificate outlives the content it describes | — |
| `ECM_EDISCOVERY_CASE` / `ECM_CASE_ITEM` | Case, collected set, hold linkage, production manifest | — |
| `ECM_REALM_KEY` | Wrapped per-realm data key, KMS key reference, rotation generation | none |
| `ECM_INTAKE_SOURCE` / `ECM_INTAKE_BATCH` / `ECM_INTAKE_EXCEPTION` | Hot-folder and scan intake with exception queue | range by `created_at` |
| `ECM_ACCESS_REVIEW` / `ECM_ACCESS_REVIEW_ITEM` | Recertification campaigns and per-grant decisions | — |

### 5.3 Chunk table — dialect sketch

**Oracle 19c**

```sql
CREATE TABLE ECM_CONTENT_CHUNK (
  CHUNK_ID      CHAR(26)      NOT NULL,
  VERSION_ID    CHAR(26)      NOT NULL,
  SEQ_NO        NUMBER(10)    NOT NULL,
  BYTE_OFFSET   NUMBER(19)    NOT NULL,
  BYTE_LENGTH   NUMBER(10)    NOT NULL,
  CHUNK_SHA256  CHAR(64)      NOT NULL,
  REF_COUNT     NUMBER(10)    DEFAULT 1 NOT NULL,
  CIPHER_FLAG   CHAR(1)       DEFAULT 'N' NOT NULL,
  DATA          BLOB          NOT NULL,
  CREATED_AT    TIMESTAMP     DEFAULT SYSTIMESTAMP NOT NULL,
  CONSTRAINT PK_ECM_CHUNK PRIMARY KEY (CHUNK_ID),
  CONSTRAINT UQ_ECM_CHUNK_SEQ UNIQUE (VERSION_ID, SEQ_NO)
)
PARTITION BY HASH (VERSION_ID) PARTITIONS 64
LOB (DATA) STORE AS SECUREFILE ECM_CHUNK_LOB (
  TABLESPACE ECM_LOB_TS  CHUNK 32768  NOCACHE  LOGGING
  COMPRESS MEDIUM  RETENTION AUTO
);

CREATE INDEX IX_ECM_CHUNK_HASH ON ECM_CONTENT_CHUNK (CHUNK_SHA256) LOCAL;
```

**SQLite (dev)**

```sql
CREATE TABLE ECM_CONTENT_CHUNK (
  CHUNK_ID      TEXT    NOT NULL PRIMARY KEY,
  VERSION_ID    TEXT    NOT NULL,
  SEQ_NO        INTEGER NOT NULL,
  BYTE_OFFSET   INTEGER NOT NULL,
  BYTE_LENGTH   INTEGER NOT NULL,
  CHUNK_SHA256  TEXT    NOT NULL,
  REF_COUNT     INTEGER NOT NULL DEFAULT 1,
  CIPHER_FLAG   TEXT    NOT NULL DEFAULT 'N',
  DATA          BLOB    NOT NULL,
  CREATED_AT    TEXT    NOT NULL DEFAULT (datetime('now')),
  UNIQUE (VERSION_ID, SEQ_NO)
);
CREATE INDEX IX_ECM_CHUNK_HASH ON ECM_CONTENT_CHUNK (CHUNK_SHA256);
```

The application never sees the difference: chunk access goes through `ChunkStore`, whose only implementations are `JdbcChunkStore` (both dialects, streaming via `Blob.getBinaryStream`) and `ArchiveChunkStore`.

### 5.4 Realm isolation

Two independent mechanisms:

1. **Repository layer (portable):** every query passes through `RealmScopedRepository`, which appends the realm predicate from `TenancyContext`. A test asserts no repository method escapes it.
2. **Oracle VPD (defence in depth):** a policy function on realm-scoped tables adds `REALM_ID = SYS_CONTEXT('ECM_CTX','REALM_ID')`. The connection pool sets the context per request.

---

## 6. Storage Architecture

### 6.1 Tier state machine

```mermaid
stateDiagram-v2
    [*] --> UPLOADING : create session
    UPLOADING --> VERIFYING : commit session
    VERIFYING --> QUARANTINED : AV scan pending / positive
    VERIFYING --> HOT : hash verified + AV clean (DB_FIRST)
    VERIFYING --> ARCHIVED : hash verified + AV clean (DIRECT_ARCHIVE, size > threshold)
    QUARANTINED --> HOT : AV clean on re-scan
    QUARANTINED --> [*] : forensic retention / expunge
    HOT --> ARCHIVING : archival policy fires (no legal hold)
    ARCHIVING --> ARCHIVED : object sealed + checksum verified + chunks released
    ARCHIVING --> HOT : seal or checksum failure (rollback, alert)
    ARCHIVED --> REHYDRATING : promotion policy satisfied (lock acquired)
    REHYDRATING --> HOT : chunks written + whole-file hash verified
    REHYDRATING --> ARCHIVED : failure — keeps serving stream-through, alert
    HOT --> EXPUNGED : expunge (blocked under legal hold)
    ARCHIVED --> EXPUNGED : expunge (blocked under legal hold)
```

### 6.2 Upload — resumable, chunked, DB-first

```mermaid
sequenceDiagram
    autonumber
    participant UI as Angular Workspace
    participant GW as ecm-gateway
    participant CO as ecm-core-service
    participant CT as ecm-content-service
    participant DB as Oracle
    participant AV as Antivirus
    participant BUS as Event Bus

    UI->>GW: POST /v1/uploads {entityId, folderId, name, size, sha256}
    GW->>CO: authorize(write, folder)
    CO->>CO: check entity allowlist, size cap, quota
    CO-->>UI: 201 {sessionId, chunkSize, ingestMode}

    loop for each chunk (parallel, bounded)
        UI->>GW: PUT /v1/uploads/{s}/chunks/{n} + Idempotency-Key
        GW->>CT: store chunk
        CT->>CT: SHA-256(chunk)
        alt ingestMode = DB_FIRST
            CT->>DB: INSERT ECM_CONTENT_CHUNK (BLOB stream)
        else DIRECT_ARCHIVE (size > db_first_max_bytes)
            CT->>CT: append to archive object under /ECM/...
        end
        CT-->>UI: 204 {received: n}
    end

    UI->>GW: POST /v1/uploads/{s}/commit
    GW->>CT: commit
    CT->>CT: verify chunk count + whole-file SHA-256
    CT->>DB: INSERT ECM_VERSION, ECM_VERSION_TIER(VERIFYING)
    CT->>AV: scan
    alt clean
        CT->>DB: tier := HOT (or ARCHIVED) ; document visible
        CT->>DB: INSERT ECM_OUTBOX {DOCUMENT_COMMITTED}
        CT-->>UI: 201 {documentId, versionId}
    else infected
        CT->>DB: document.state := QUARANTINED ; legal hold applied
        CT-->>UI: 422 problem: CONTENT_REJECTED_MALWARE
    end
    BUS-->>BUS: index · OCR · audit fan-out
```

**Failure semantics:** a version is invisible until commit succeeds. Abandoned sessions and their chunks are reaped after TTL. Every chunk PUT is idempotent by `(sessionId, seqNo, chunkSha256)` so a retried chunk is a no-op, not a duplicate.

### 6.3 Download — hot, archived and stream-through

```mermaid
sequenceDiagram
    autonumber
    participant C as Client / Widget
    participant GW as ecm-gateway
    participant CT as ecm-content-service
    participant CA as Redis
    participant DB as Oracle
    participant FS as /ECM/ archive
    participant AR as ecm-archival-service

    C->>GW: GET /v1/content/{versionId} (Range?, If-None-Match?)
    GW->>CT: authorize + fetch
    CT->>CT: ACL re-check (never trust the token alone)

    alt ETag matches
        CT-->>C: 304 Not Modified
    else tier = HOT
        CT->>CA: lookup chunk by content hash
        alt cache hit
            CA-->>CT: bytes
        else miss
            CT->>DB: stream BLOB chunks for the requested range
            CT->>CA: populate (small files / hot chunks only)
        end
        CT-->>C: 200/206 stream, ETag = sha256
    else tier = ARCHIVED
        CT->>FS: open archive object, seek to range
        CT-->>C: 200/206 stream-through (reader never waits)
        CT->>DB: increment read counter in window
        opt promotion policy satisfied (N reads / M days)
            CT->>AR: requestRehydration(versionId)  [async]
            AR->>AR: acquire distributed lock (version-keyed)
            AR->>FS: read object
            AR->>DB: write chunks in a separate transaction
            AR->>AR: verify whole-file SHA-256
            AR->>DB: tier := HOT (atomic flip) ; else stay ARCHIVED + alert
        end
    end
```

**Why stream-through matters:** the naïve "restore to DB, then serve" design makes the first reader pay the entire restore latency and lets 50 concurrent readers trigger 50 restores. Here, readers are never blocked, and the version-keyed lock guarantees at most one rehydration.

### 6.4 Archival job

```mermaid
sequenceDiagram
    autonumber
    participant SCH as Scheduler
    participant AR as ecm-archival-service
    participant DB as Oracle
    participant FS as /ECM/ archive

    SCH->>AR: run(entityId)
    AR->>DB: SELECT versions WHERE tier=HOT AND policy matched AND no legal hold
    loop batched, rate-limited
        AR->>DB: tier := ARCHIVING (optimistic lock on version)
        AR->>DB: stream chunks in seq order
        AR->>FS: write sealed object at /ECM/{entity}/{mount}/{yyyy}/{mm}/{versionId}
        AR->>FS: fsync + read back checksum
        alt checksum matches manifest
            AR->>DB: INSERT ECM_ARCHIVE_OBJECT
            AR->>DB: DELETE chunks WHERE ref_count = 1 (decrement otherwise)
            AR->>DB: tier := ARCHIVED ; INSERT ECM_TIER_TRANSITION
        else mismatch
            AR->>FS: delete partial object
            AR->>DB: tier := HOT ; raise alert
        end
    end
    AR->>DB: INSERT ECM_JOB_RUN summary
```

**Order is the safety property:** write → fsync → verify → record pointer → *only then* release DB chunks. Content exists in two places for a moment and in zero places never.

---

## 7. Security Architecture

### 7.1 Request authorisation

```mermaid
graph LR
    R["Request + Kavach JWT"] --> V["Gateway:<br/>signature (JWKS)<br/>iss · aud · exp · nbf<br/>realm claim"]
    V --> T["TenancyContext<br/>subject · realm · roles · groups"]
    T --> P["PermissionEvaluator"]
    P --> DC{"DecisionCache<br/>TTL ≤ 60s"}
    DC -->|hit| G["Grant / Deny"]
    DC -->|miss| A["AclResolver:<br/>closure walk → inherited ACL<br/>+ explicit overrides<br/>+ Kavach group expansion"]
    A --> G
    G -->|deny| E["404 for cross-realm<br/>403 within realm"]
    G -->|grant| H["Handler"]
    INV["ACL change · share revoke ·<br/>group change · deprovision"] -.synchronous write-through.-> DC
```

Cross-realm requests return **404, not 403** — a 403 confirms the resource exists.

### 7.2 Viewer widget capability flow

```mermaid
sequenceDiagram
    autonumber
    participant HU as Host UI (browser)
    participant HB as Host Backend
    participant CO as ecm-core-service
    participant W as ecm-viewer widget
    participant CT as ecm-content-service

    HU->>HB: render document {fileId}
    HB->>CO: POST /v1/viewer/tokens (service credentials)<br/>{documentId, subject, purpose, permissions}
    CO->>CO: verify host service principal is registered
    CO->>CO: evaluate SUBJECT's ACL on the document
    CO-->>HB: {token, exp ≤ 10 min, scope, versionId}
    HB-->>HU: token (never the user's primary JWT)
    HU->>W: <ecm-viewer [token]="token">
    W->>CT: GET /v1/viewer/content?token=... (Range)
    CT->>CT: verify token signature, audience, binding, expiry
    CT->>CT: RE-EVALUATE the subject's ACL
    CT-->>W: 206 stream (+ watermark policy header)
    Note over CT: every request audited:<br/>VIEWER_STREAM {subject, host, doc, version, bytes}
```

**Threat model addressed:** identifier enumeration (ULIDs + rate limits + alerts), token replay (short expiry, audience and subject binding, single-use refresh), scope escalation (download attempted with a view-only token → 403 + audit), host impersonation (service-principal credentials, backend-only minting endpoint), and stale entitlement (ACL re-evaluated per request, not at mint time).

### 7.3 Audit chain

```
event_hash(n) = SHA-256( event_hash(n-1) ‖ canonical_json(event(n)) )
```

Append-only through a dedicated schema owner with no `DELETE`/`UPDATE` grant. A nightly job seals a digest of the day's terminal hash and verifies the chain backwards over a rolling window; a break raises a P1 alert. Where Oracle Blockchain Tables are available, the audit partition uses them.

---

## 8. Caching Architecture

```mermaid
graph TB
    REQ["Request"] --> L1["L1 · Caffeine in-process<br/>entity config · format registry<br/>folder metadata · authz decisions<br/>TTL ≤ 60s + event eviction"]
    L1 -->|miss| L2["L2 · Redis/Valkey<br/>key = content SHA-256<br/>chunk bytes (small files)<br/>rendered PDF pages · thumbnails · OCR text"]
    L2 -->|miss| SRC["Oracle chunks / archive object"]
    SRC --> L2
    L2 --> L1
    L1 --> RESP["Response<br/>ETag = content hash<br/>Cache-Control: private"]
```

Because versions and chunks are immutable and L2 keys are content hashes, **L2 entries can never be stale** — they are only evicted by capacity. Only L1 (mutable metadata and authorisation decisions) needs invalidation, and that is event-driven with a hard 60-second ceiling.

**Derivative cache:** rendered artefacts (PDF page rasters, thumbnails, Office→PDF conversions) are keyed by `sha256(content) + renderProfile`, so a rendered page survives archival, rehydration and even document moves.

---

## 8A. Mechanisms for the v2.1 Capabilities

### 8A.1 Label-driven policy — one enforcement point

```mermaid
graph LR
    ACT["Action:<br/>share · download · export · preview"] --> PDP["PolicyDecisionPoint"]
    ACL["ACL decision"] --> PDP
    LBL["Sensitivity label<br/>PUBLIC…RESTRICTED"] --> PDP
    POL["ECM_LABEL_POLICY<br/>per realm"] --> PDP
    HOLD["Legal hold · eDiscovery hold"] --> PDP
    PDP --> D{"Permit / Deny / Permit-with-obligation"}
    D -->|obligation| OBL["watermark · second approver ·<br/>expiry cap · no-download"]
```

Authorisation answers *may this principal act on this resource*; the label policy answers *may this action happen at all, and under what obligation*. Both must permit. Keeping them as one decision point means a new control (say, "RESTRICTED content may never leave the network") is configured once rather than implemented in six call sites.

### 8A.2 Fixity sweep

A leader-elected job walks both tiers on a rolling 90-day cycle, rate-limited so it never competes with user traffic. For each object it re-reads the bytes, recomputes SHA-256, compares against the stored manifest, and writes an `ECM_FIXITY_RESULT` row either way — a clean result is as important as a failure, because the audit question is "when was this last verified", not "has anything broken". On mismatch: mark the version, raise P1, attempt automatic restore from replica or backup, and re-verify. Sweep coverage and age-since-last-verification are dashboard metrics.

### 8A.3 Envelope encryption, per realm

```
KMS/HSM master key
   └─ wraps → ECM_REALM_KEY (per realm, per generation)
                  └─ encrypts → chunk data / archive objects
```

Bytes are encrypted with the realm data key; only the wrapped data key is stored. Rotation mints a new generation and re-wraps — it never rewrites content, so rotating a realm holding 40 TB is a metadata operation. Each chunk and archive object records the key generation that encrypted it. Destroying a realm key crypto-shreds that realm, recorded as a disposition event.

### 8A.4 Asynchronous operations

```mermaid
sequenceDiagram
    participant C as Client
    participant API as ecm-core-service
    participant Q as Work queue
    participant W as Worker (leader-elected)
    C->>API: POST /v1/operations {type, params} + Idempotency-Key
    API->>API: dedupe by key — retry joins the existing operation
    API-->>C: 202 {operationId, statusUrl}
    API->>Q: enqueue
    W->>Q: claim
    loop per item
        W->>W: execute, record ECM_OPERATION_ITEM outcome
    end
    C->>API: GET /v1/operations/{id}
    API-->>C: {status, progress, succeeded, failed, errors[]}
```

Bulk move, bulk export, archival, rehydration, redaction, reindex, disposition and eDiscovery collection all use this one shape. Partial failure is reported per item; an operation never reports success while items failed silently.

### 8A.5 Webhook dispatch

Events reach host applications through the same outbox that feeds indexing. The dispatcher signs each payload with an HMAC over body plus timestamp, retries with exponential backoff, and dead-letters after a bounded number of attempts with an alert to the host's registered contact. Payloads carry identifiers and metadata only — never bytes — and are filtered against what the subscribing host application is entitled to see, so a webhook can never become a disclosure channel.

### 8A.6 Intake pipeline

```
Hot folder / scanner → intake watcher → virus scan → barcode split →
OCR + extraction → batch indexing queue (operator confirms) → commit →
                                    └─ on any failure → exception queue (never dropped)
```

Intake sources are registered clients with their own credentials and rate limits, and every ingested document records the source, batch and operator who released it.

---

## 9. Frontend Architecture

```mermaid
graph TB
    subgraph SHARED["@rebit/ecm-* libraries"]
        UIKIT["ecm-ui-kit<br/>Optimus UI wrappers + design tokens"]
        DATA["ecm-data-access<br/>generated OpenAPI clients + signal stores"]
        VIEWER["ecm-viewer<br/>PDF · image · media · text · office"]
        AUTH["ecm-auth<br/>Kavach interceptor + realm switcher"]
    end

    ADMIN["ecm-admin-console"] --> UIKIT
    ADMIN --> DATA
    ADMIN --> AUTH
    WORK["ecm-user-workspace"] --> UIKIT
    WORK --> DATA
    WORK --> AUTH
    WORK --> VIEWER
    HOST["Any host application"] --> VIEWER
```

**Angular 21 conventions:** standalone components only · signals for state, `resource()`/`httpResource` for async reads · new control flow (`@if`/`@for`/`@switch`) · zoneless change detection · `@defer` for the viewer and heavy panels · lazy routes per feature · `OnPush` everywhere · CDK virtual scroll for the file list · Web Worker for client-side hashing during upload.

**Optimus UI is wrapped, never used directly** in feature code. `ecm-ui-kit` exposes `EcmButton`, `EcmTable`, `EcmTree`, `EcmDialog`, `EcmStatusPill` etc., delegating to Optimus internally. If the library's API shifts or a component is missing, one wrapper changes rather than two hundred call sites.

**Widget packaging:** the same source builds three artefacts — an Angular library (for Angular hosts), a custom element bundle via `@angular/elements` (for any host), and an iframe host page with a `postMessage` protocol (for strict isolation). All three consume the same capability token.

---

## 10. Deployment

```mermaid
graph TB
    subgraph OCP["OpenShift — namespace: rbi-ecm"]
        ING["Route / Ingress + WAF"]
        GWP["ecm-gateway ×3"]
        COP["ecm-core-service ×4 (HPA on CPU + QPS)"]
        CTP["ecm-content-service ×4 (HPA on network I/O)"]
        ARP["ecm-archival-service ×2 (leader-elected jobs)"]
        AIP["ecm-ai-search-service ×3 (HPA on queue depth)"]
        RND["render-worker pods<br/>no egress · resource-capped · ephemeral"]
        RDS["Redis / Valkey (HA)"]
        CFG["ConfigMaps · Sealed Secrets"]
    end
    ORA[("Oracle 19c RAC<br/>Data Guard standby")]
    NFS[("/ECM/ archive — NFS / ODF object")]
    OSI[("Search cluster")]

    ING --> GWP --> COP & CTP & AIP
    ARP --> ORA & NFS
    CTP --> ORA & NFS & RDS
    COP --> ORA & RDS
    AIP --> OSI & RDS
    AIP --> RND
```

**Notes.** Archival and reconciliation jobs are leader-elected so two replicas never process the same batch. Render workers run with no network egress and a hard timeout — untrusted document conversion is the highest-risk code in the system. The archive mount is `ReadWriteMany`; content-service pods mount it read-only and only archival-service writes, so an application-layer compromise cannot rewrite cold storage.

---

## 11. Architecture Decision Records

| ADR | Decision | Alternatives rejected | Consequence |
|---|---|---|---|
| **ADR-01** | Realm (identity) and Entity (storage/policy) are separate nested concepts | Single "tenant"; entity-as-realm | Slightly more join depth; removes the largest ambiguity in the source spec |
| **ADR-02** | DB-first chunked ingest with a per-entity size threshold | Pure DB; pure filesystem; object storage only | DB stays the record of truth for the common case; the large-file tail does not destroy backup windows |
| **ADR-03** | Stream-through serving + async, locked, policy-gated rehydration | Restore-then-serve; always rehydrate | No latency cliff, no thundering herd, no hot-tier pollution from one-off reads |
| **ADR-04** | Capability tokens for the viewer, ACL re-checked per request | Pass the user's JWT; pass a raw file id | Eliminates IDOR; costs one backend hop per embed |
| **ADR-05** | Five services, one write-owner per table group, ArchUnit-enforced | Nine microservices on a shared schema; single monolith | Real isolation where workloads differ; no distributed monolith |
| **ADR-06** | ULID `CHAR(26)` identifiers | Oracle sequences; `RAW(16)` UUID; auto-increment | Portable across both dialects, sortable, unguessable; 26 bytes per key |
| **ADR-07** | Content-hash-keyed L2 cache | TTL-keyed cache; no distributed cache | Cache entries are structurally incapable of being stale |
| **ADR-08** | Oracle is the CI correctness authority; SQLite is developer convenience only | SQLite parity; Oracle-only development | Slower CI; eliminates "worked on my machine" |
| **ADR-09** | Optimus UI wrapped behind `ecm-ui-kit` | Direct use in features | One indirection; insulates 2 applications + 1 library from upstream churn |
| **ADR-10** | Deduplication deferred, `ref_count` + content-hash index present from day one | Dedupe in v1; ignore dedupe entirely | No migration needed when it is switched on; no v1 complexity around expunge and legal hold |
| **ADR-11** | Archive mount is written only by `ecm-archival-service`; content-service mounts read-only | All services read-write | Application compromise cannot corrupt cold storage |
| **ADR-12** | Java 21 virtual threads for streaming endpoints | Reactive stack (WebFlux) | Blocking-style code with reactive scalability; no reactive learning curve across the team |
| **ADR-13** | Sensitivity label and ACL are evaluated at one combined decision point, with obligations | Enforce label rules inside each feature | A new control is configured once; no feature can forget it |
| **ADR-14** | Envelope encryption with per-realm data keys | Single instance-wide key; per-document keys | Rotation without content rewrite; crypto-shredding per realm; per-document keys rejected as unmanageable at 250 M objects |
| **ADR-15** | One asynchronous operations framework for all long-running work | Per-feature progress mechanisms | Consistent observability, cancellation and partial-failure semantics |
| **ADR-16** | Fixity results are recorded on success as well as failure | Log only failures | "When was this last verified" is the auditable question |
| **ADR-17** | Document relationship inverses maintained in application code, not DB triggers | Triggers | Triggers are invisible to the domain model and untestable in SQLite |
| **ADR-18** | Webhooks carry identifiers and metadata only, never content | Include content or signed content URLs | A webhook can never become an out-of-band disclosure channel |

---

## 12. Risk Register

| # | Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|---|
| R1 | Oracle LOB write throughput becomes the ingest bottleneck | Medium | High | Ingest threshold; dedicated LOB tablespace; `NOCACHE`; parallel chunk writes; early load test in Phase 0 |
| R2 | Archive mount latency makes stream-through breach the 3 s TTFB target | Medium | Medium | Measure early; prefetch first chunk on document open; tune promotion policy; consider object storage with range GET |
| R3 | Kavach cannot issue reduced-scope tokens | Medium | Medium | ECM mints its own capability tokens (design already supports both) |
| R4 | SQLite/Oracle divergence surfaces late | High if unmanaged | High | Oracle in CI from Phase 0; no vendor SQL outside `infrastructure` |
| R5 | Optimus UI incompatible with Angular 21 | Medium | Medium | `ecm-ui-kit` wrapper layer; a headless fallback implementation behind the same API |
| R6 | Untrusted document conversion exploited | Low | Very High | Sandboxed, network-isolated, resource-capped, ephemeral render workers |
| R7 | Search index drifts from the repository | Medium | Medium | Transactional outbox + nightly reconciliation with repair |
| R8 | Quota accounting drifts from physical usage | High | Low | Nightly reconciliation with variance report |
| R9 | Audit volume overwhelms the primary schema | Medium | Medium | Monthly interval partitioning + DB archival of aged partitions |
| R10 | Fixity sweep I/O competes with user traffic at 250 M objects | Medium | Medium | Rate-limited, off-peak windows, prioritised by age since last verification rather than uniform scanning |
| R11 | Sensitivity labels are applied inconsistently, making label-driven policy meaningless | High | High | Entity-level default, uploader may only raise, AI suggestion at ingest, and a label-coverage metric on the admin dashboard |
| R12 | Key rotation or KMS unavailability makes content unreadable | Low | Very High | Cached wrapped keys with a bounded TTL, previous-generation keys retained until re-wrap completes, documented break-glass, and a rotation drill in the DR exercise |
| R13 | Webhook consumers are slow or down and back-pressure the outbox relay | Medium | Medium | Per-host delivery isolation, bounded queues, circuit breaker, dead-letter with alerting — a failing host never delays indexing or audit |
| R14 | Automated disposition destroys something it should not | Low | Very High | Nothing is ever destroyed without human approval; holds override every schedule; destruction certificates are permanent |

---

*End of System Architecture Document v1.1.*
