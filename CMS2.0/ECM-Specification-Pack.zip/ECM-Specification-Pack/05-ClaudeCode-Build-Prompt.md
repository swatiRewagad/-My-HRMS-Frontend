# Claude Code — ECM Build Prompt

> **How to use this.** Put this file at the repo root as `BUILD_PROMPT.md`, together with `01`–`04` in `/docs`. Start Claude Code and paste §0 as your first message. Then work phase by phase — one phase per session, never more. At the start of each session say: *"Read BUILD_PROMPT.md and docs/03-ECM-PRD-v2.1-FINAL.md and docs/04-ECM-System-Architecture-v1.1.md. We are starting Phase N. Show me your plan before writing code."*

---

## §0 — Opening message (paste this first)

You are building **ECM (Enterprise Content Management)** for the RBI Enterprise Platform at ReBIT, from scratch.

Authoritative specifications are in `/docs`:
- `03-ECM-PRD-v2.1-FINAL.md` — product requirements (the contract)
- `04-ECM-System-Architecture-v1.1.md` — architecture, data model, sequence and state diagrams, ADRs

**Read both fully before writing a single line.** Where this prompt and those documents disagree, the documents win. Where all three are silent, **ask me — do not invent a requirement.**

**Root Java package: `org.rebit.ecm`. Never deviate from it.**

### Stack (fixed)
| Layer | Choice |
|---|---|
| Language | Java 21 (virtual threads on for streaming endpoints) |
| Framework | Spring Boot 3.4+, Spring Modulith for module boundaries |
| Build | Gradle multi-project with version catalog |
| Prod DB | Oracle 19c, partitioned, SecureFiles LOBs |
| Dev DB | SQLite (developer convenience only — never the correctness authority) |
| Migrations | Flyway, vendor-split (`common` / `oracle` / `sqlite`) |
| Cache | Caffeine (L1) + Redis/Valkey (L2) |
| Search | OpenSearch/Elasticsearch behind an interface (engine choice is an open question — code to the interface) |
| Frontend | Angular 21 — standalone, signals, zoneless, new control flow, `@defer` |
| Component lib | Optimus UI, **always behind `ecm-ui-kit` wrappers** |
| Testing | JUnit 5, AssertJ, Mockito, Testcontainers (Oracle + Redis + search), ArchUnit, k6, Playwright, axe-core |
| Identity | Kavach (JWT). **Mock provider behind the same SPI for all dev and test work.** |

### Twelve non-negotiables

1. **Domain packages import nothing from Spring, JPA or Jackson.** Framework types live in `application` and `infrastructure` only. ArchUnit enforces this from Phase 0.
2. **No vendor-specific SQL outside `infrastructure`.** All SQL is either JPQL, Criteria, or dialect-split native queries selected by a `SqlDialect` bean.
3. **Every table has a single owning service.** See the ownership table in the architecture doc. ArchUnit enforces the package-level version of this rule.
4. **Realm isolation is implemented twice** — repository-layer predicate and (on Oracle) VPD. A test asserts every realm-scoped repository method applies the predicate.
5. **Cross-realm access returns 404, never 403.** A 403 confirms existence.
6. **A version is invisible until commit succeeds and the whole-file SHA-256 verifies.** No partially-visible content, ever.
7. **Archival order is: write → fsync → read-back verify → record pointer → release DB chunks.** Never release before verification.
8. **Reads of archived content stream through from the archive immediately.** Rehydration is asynchronous, version-locked, and gated by a promotion policy. A reader never waits for rehydration.
9. **Viewer tokens are capabilities, not authorisation.** ACL is re-evaluated on every stream request.
10. **Every state change emits an audit event** with actor, resource, before/after and correlation id, through the hash-chained audit sink.
11. **Every mutation endpoint accepts `Idempotency-Key`.** Every collection endpoint is cursor-paginated. Every error is RFC 9457 problem details.
12. **No secrets, credentials, connection strings or real data in the repo.** Config via environment and Sealed Secrets.

### Working agreement — front-load, then run autonomously

**This is the most important instruction in this document. Read it twice.**

Every session has exactly two modes, and you switch between them once.

**Mode 1 — Interrogation (first message of the session only).** Before writing any code, produce a single consolidated message containing *everything* you need from me:

- every clarifying question about requirements, ambiguity or conflicting specs
- every permission you will need for the whole phase — file writes outside the repo, package installs, container pulls, port bindings, network calls, destructive git operations, schema drops, long-running processes
- every assumption you intend to make where I do not answer, stated explicitly as "if you do not answer, I will assume X"
- your file-by-file plan for the phase, in dependency order, with the parallel work streams identified (see §0.6)

Ask **all** of it at once. Batch it. Do not trickle questions to me one at a time across the session — that is the single most expensive failure mode, and I would rather answer twenty questions in one go than four questions across four interruptions.

**Mode 2 — Autonomous execution (everything after my one reply).** Once I answer, **run the entire phase to completion without further intervention.** Do not ask permission again. Do not stop to confirm a design choice. Do not pause at a phase boundary within the work you were given. Where you hit something genuinely unforeseen, apply the assumption you declared in Mode 1, log it in `docs/ASSUMPTIONS.md` with a `⚠ NEEDS CONFIRMATION` marker, and keep moving. Surface the accumulated markers in your closing report — not mid-flight.

The only three things that may interrupt autonomous execution:
1. A request that would breach one of the twelve non-negotiables in §0.
2. A discovery that invalidates the phase plan wholesale (not a detail — the plan).
3. Anything requiring a real credential, real institutional data, or a production system.

Everything else: decide, document, continue.

### Standing rules

- **Small commits** with conventional-commit messages, each leaving the build green.
- **Write the test first** for domain logic and for anything involving bytes, permissions or quota.
- **Never mock in an integration test what you can run in a container.**
- Maintain `docs/CHANGELOG.md`, `docs/RUNBOOK.md`, `docs/ASSUMPTIONS.md` and `docs/ADVERSARIAL-LOG.md` as you go, not at the end.
- Close every session with a report: what was built, what the adversarial pass found and fixed, what assumptions need confirmation, what is left.

### §0.6 — Work in parallel

You have subagents and background tasks. Use them aggressively. Sequential execution of independent work is wasted wall-clock time.

**At the start of each phase, decompose into parallel streams** and say so in your Mode 1 plan. Fan out where the work is genuinely independent; join at integration points. A reasonable default shape:

| Stream | Typical content |
|---|---|
| **A · Schema & persistence** | Flyway migrations for both dialects, JPA entities, repositories, dialect abstraction |
| **B · Domain & application** | Aggregates, invariants, use cases, domain events — pure, no DB needed to start |
| **C · API & contract** | Controllers, DTOs, OpenAPI, problem details, idempotency, pagination |
| **D · Frontend** | Angular shells, `ecm-ui-kit`, feature components — against the OpenAPI contract, not the running backend |
| **E · Test harness & ops** | Testcontainers factories, data builders, docker-compose, CI pipeline, k6 skeletons |
| **F · Adversarial verification** | §11A — runs *against* the other streams, continuously, not at the end |

Rules for parallel work:

- **Contract-first at every seam.** Write the OpenAPI spec and the port interfaces *before* fanning out, so streams that depend on each other agree without talking.
- **One stream owns one set of files.** Two subagents must never edit the same file. If they need to, that is a seam that should have been an interface.
- **Rebase and run the full suite at every join point,** not just the stream's own tests.
- Run long jobs — Oracle container startup, Gradle builds, npm installs, k6 runs, integration suites — **in the background** while other streams continue.
- Prefer **many small parallel verifications** over one big serial one: unit, ArchUnit, lint, OpenAPI diff and dialect-migration checks can all run concurrently.
- If a stream blocks, do not idle: switch to another stream and report the block in the closing report.

---

## §1 — Repository layout

```
rbi-ecm/
├─ build.gradle.kts · settings.gradle.kts · gradle/libs.versions.toml
├─ BUILD_PROMPT.md
├─ docs/            (01..04, CHANGELOG.md, RUNBOOK.md, ADR/)
├─ backend/
│  ├─ ecm-common/            org.rebit.ecm.common
│  ├─ ecm-security/          org.rebit.ecm.security      (SPI + kavach + mock + authz + capability)
│  ├─ ecm-persistence/       org.rebit.ecm.persistence   (dialect abstraction, Flyway, base repos)
│  ├─ ecm-gateway/           org.rebit.ecm.gateway
│  ├─ ecm-core-service/      org.rebit.ecm.core.*
│  ├─ ecm-content-service/   org.rebit.ecm.content.*
│  ├─ ecm-archival-service/  org.rebit.ecm.archival.*
│  ├─ ecm-aisearch-service/  org.rebit.ecm.aisearch.*
│  └─ ecm-test-support/      shared fixtures, container factories, data builders
├─ frontend/
│  ├─ libs/ecm-ui-kit/       Optimus wrappers + design tokens
│  ├─ libs/ecm-data-access/  generated OpenAPI clients + signal stores
│  ├─ libs/ecm-auth/         Kavach interceptor, realm switcher, mock login
│  ├─ libs/ecm-viewer/       viewer widget library (+ custom-element build)
│  ├─ apps/ecm-admin-console/
│  ├─ apps/ecm-user-workspace/
│  └─ apps/ecm-widget-demo/  runnable sample host application
├─ ops/  (docker-compose.dev.yml, oracle-init/, k6/, openshift/)
└─ tools/ (openapi codegen, seed data generators)
```

---

## §2 — Phase 0 · Walking skeleton (start here)

**Goal:** a user logs in with a mock Kavach token, uploads one PDF into a Public folder, it is chunked into the database, appears in the file manager, downloads byte-identical, and every step is in the audit trail. Both Angular shells exist. Both dialects migrate cleanly.

**Deliverables**

1. Gradle multi-project skeleton; all modules compile; version catalog populated.
2. `ecm-common`: `UlidId` and typed id wrappers, `EcmException` hierarchy + `ErrorCode` enum, `ProblemDetailFactory`, `Cursor`/`Page<T>`, `TenancyContext` + holder, `ClockProvider`.
3. `ecm-persistence`: `SqlDialect` abstraction, Flyway configured with `db/migration/{common,oracle,sqlite}`, `RealmScopedRepository` base with the mandatory realm predicate.
4. **V1 migration** (both dialects) for: `ECM_REALM`, `ECM_ENTITY_CONFIG`, `ECM_FOLDER`, `ECM_FOLDER_CLOSURE`, `ECM_DOCUMENT`, `ECM_DOCUMENT_FOLDER_LINK`, `ECM_VERSION`, `ECM_VERSION_TIER`, `ECM_CONTENT_CHUNK`, `ECM_UPLOAD_SESSION`, `ECM_ACL`, `ECM_AUDIT_EVENT`, `ECM_OUTBOX`. Use the DDL sketches in the architecture doc §5.3 as the pattern: Oracle gets partitioning and SecureFiles, SQLite gets the portable equivalent.
5. `ecm-security`: the SPI (`IdentityProvider`, `PrincipalResolver`, `TokenValidator`) plus a **complete `MockIdentityProvider`** — local RSA keypair, a `/dev/token` endpoint that mints tokens for seeded users, seeded realms (`RBI_CORP`, `DICGC`), seeded entities (IPS, DMS), and seeded users covering every role in PRD §2.3. Profile-switched; production code paths are identical.
6. `ecm-core-service`: realm/entity/folder/document/version domain + minimal REST — create folder, list folder, list documents, get document metadata.
7. `ecm-content-service`: upload session create → chunk PUT → commit, and download with `Range` support. Fixed 4 MiB chunking. SHA-256 per chunk and whole file.
8. Audit sink with hash chaining, writing on every state change.
9. Angular: two app shells with the platform header (RBI lockup, dark-mode toggle, A-/A/A+ scaling, language selector, notifications, user identity, app-switcher grid) and the collapsible dark nav rail with About/Collapse pinned bottom. `ecm-ui-kit` with the design tokens from PRD §22.2 as CSS custom properties. Mock login flow.
10. `ops/docker-compose.dev.yml`: Oracle XE (or free), Redis, search engine.
11. CI: build, unit tests, ArchUnit, **integration tests against a real Oracle container**.

**Phase 0 acceptance (must all pass)**

- [ ] `./gradlew clean build` green from a cold clone.
- [ ] Flyway migrates cleanly on both SQLite and Oracle from empty.
- [ ] Property test: content of sizes `0, 1, 4MiB-1, 4MiB, 4MiB+1, 100MB` → upload → download → **byte-identical**, SHA-256 matches.
- [ ] Cross-realm folder request returns 404.
- [ ] Audit chain verifies over the whole test run.
- [ ] Both Angular apps start, render the shell, and complete an upload → list → download round trip against the running backend.
- [ ] ArchUnit passes: no Spring/JPA imports in any `domain` package; no cross-service package dependency.

---

## §3 — Phase 1 · Repository

Folder tree with closure table and materialised path · folder classes (PUBLIC / PRIVATE auto-provisioned per user per entity / RESTRICTED) · multi-link documents (primary + secondary) · immutable versions with restore-as-new-version · check-out/check-in with expiring locks · recycle bin with retention · expunge with mandatory reason · ACL model with inheritance and explicit override · `PermissionEvaluator` with a ≤ 60 s decision cache and synchronous write-through invalidation · entity configuration with maker–checker (maker cannot approve own submission — enforce server-side) · quota enforcement with 80% warning and 100% hard stop · format registry with magic-byte validation · mount-point validation (traversal, symlink escape, depth, charset, collision).

**Plus (PRD v2.1):**
- **E1-01…03 Sensitivity labels** — four-level label on every document, entity default, uploader may raise but never lower, downgrade restricted to an entitled role with mandatory reason and elevated audit. Build the combined **PolicyDecisionPoint** described in architecture §8A.1 now, even though only a few obligations exist yet — retrofitting it later means editing every call site.
- **E8-01, E8-02, E8-04 Permission explorer** — effective-permissions view for any resource showing *why* each principal has access (direct / inherited from which ancestor / via which group / via which role), the reverse per-user view, and exportable permission-change history.
- **E10 Async operations framework** — build this before the first bulk action needs it. `202` + operation resource, per-item outcomes, cancellation, idempotency joining an existing operation. Every later bulk feature uses it.

**Acceptance**
- [ ] Authorisation matrix test: every role × every resource type × every operation × (own realm / other realm) — 100% of cells asserted.
- [ ] A `RESTRICTED` document cannot be externally shared by any role; the attempt is audited.
- [ ] The permission explorer's "why" for a nested grant matches a hand-traced expectation across a 5-deep tree with group expansion.
- [ ] A retried bulk operation with the same `Idempotency-Key` joins the existing operation rather than starting a second.
- [ ] Restoring v1 of a 3-version document produces v4 with v1's bytes; v1–v3 remain retrievable.
- [ ] Concurrent check-in by a non-holder returns 409 with the lock holder named.
- [ ] Two parallel uploads that would together exceed quota: exactly one succeeds.
- [ ] Every mount-point attack string in the fixture list is rejected.
- [ ] A maker's own approval attempt is rejected by the API, not just hidden in the UI.

---

## §4 — Phase 2 · Storage lifecycle

Implement the tier state machine exactly as drawn in architecture doc §6.1.

- Per-entity `chunk_size` and `db_first_max_bytes` (default 4 MiB / 100 MiB), **frozen per version at write time**.
- `DIRECT_ARCHIVE` ingest path for oversize content, with an identical read path.
- Archival job: policy match (age / idle / min size / legal hold) → optimistic-lock to `ARCHIVING` → stream chunks in sequence → write sealed object under `/ECM/{entity}/{mount}/{yyyy}/{mm}/{versionId}` → fsync → read-back checksum → record pointer → release chunks (decrement `ref_count`, delete at zero) → `ARCHIVED` + `ECM_TIER_TRANSITION`. Any failure rolls back to `HOT` and alerts.
- Read path: `ARCHIVED` serves **stream-through** with `Range` support; read counter incremented in a rolling window; promotion policy (default 2 reads / 7 days) triggers async rehydration under a **version-keyed distributed lock**; rehydration verifies the whole-file hash and flips state atomically, or stays `ARCHIVED` and alerts.
- Resumable upload sessions with idempotent chunk PUTs, TTL and a reaper for orphans.
- Legal hold at document/folder/entity scope, blocking archival, expunge and purge.
- Nightly quota reconciliation producing a per-entity variance report.
- Leader election so two archival replicas never process the same batch.

**Plus (PRD v2.1):**
- **E3-01…03 Fixity sweep** — leader-elected, rate-limited, rolling 90-day cycle over both tiers; records a result row on success as well as failure; P1 alert and automatic restore attempt on mismatch; coverage and age-since-verification as dashboard metrics.
- **E7 Duplicate detection** — on commit, an existing whole-file hash within the entity offers the uploader: link to it, version it, or store separately with a reason. Plus an admin duplicates report with reclaimable bytes.
- **E11 Per-user quota** inside the PRIVATE root, with consumption breakdown and the "largest / oldest / duplicate files" reclamation reports.

**Acceptance**
- [ ] Full round trip: upload → archive → chunks released → download → byte-identical.
- [ ] A deliberately corrupted archive object is detected within one sweep cycle, flagged, alerted, and a restore attempted.
- [ ] Uploading an identical file twice surfaces the existing document rather than silently creating a second copy.
- [ ] 50 concurrent reads of one `ARCHIVED` version trigger **exactly one** rehydration; all 50 get correct bytes; TTFB p95 < 3 s.
- [ ] Simulated checksum failure during archival leaves the version `HOT` with no orphaned archive object.
- [ ] Simulated crash mid-rehydration leaves the version `ARCHIVED` and still readable.
- [ ] A version under legal hold is not selected by any archival or purge job.
- [ ] An abandoned upload session and its chunks are gone after TTL.

---

## §5 — Phase 3 · Access, discovery and the viewer widget

**Search:** indexing driven by the transactional outbox; permission trimming at query time (counts must not leak inaccessible documents); facets; nightly index-drift reconciliation with repair.

**Sharing:** share links with expiry, password, download limit, view-only/download, watermark; realm policy ceilings users cannot exceed; tokens stored hashed; immediate revocation with synchronous cache write-through.

**OCR:** ingest-time OCR for scanned images and non-searchable PDFs, running in a **sandboxed, network-isolated, resource-capped, ephemeral worker** with a hard timeout. Extracted text stored alongside the original and indexed.

**Viewer token service:** `POST /v1/viewer/tokens`, backend-to-backend only (reject browser-origin), service-principal authenticated, minting tokens bound to document + optional version + subject + host audience + permission set, expiry ≤ 10 minutes. Every stream request re-verifies the token *and* re-evaluates the subject's ACL.

**Viewer widget library `@rebit/ecm-viewer`:**

| Type | Renderer |
|---|---|
| PDF | pdf.js, lazy page rendering, text layer exposed to screen readers, JavaScript in PDF disabled |
| Images | JPEG/PNG/WebP/TIFF, sanitised SVG (no scripts), zoom/pan/rotate |
| Text-ish | txt/md/csv/json/xml/log, virtualised for large files, syntax highlight, CSV as a table |
| Media | HTML5 audio/video over `Range`, seekable without full download, caption-track support |
| Office | server-side conversion to PDF in the sandboxed worker, then the PDF viewer |
| Unknown | metadata card + download button (permission-gated) |

Common shell: page navigation, zoom, rotate, fit-width/fit-page, thumbnail rail, in-document search, download/print buttons **rendered only when the token grants them**, watermark overlay with viewer identity and timestamp, full keyboard operability, `prefers-reduced-motion` respected, theming via CSS custom properties.

Build **three artefacts from one source**: Angular library, custom element (`@angular/elements`), and an iframe host page with a `postMessage` protocol. Ship `apps/ecm-widget-demo` as a runnable sample host that demonstrates the backend token mint.

**Plus (PRD v2.1):**
- **E9 Webhooks, SDK, sandbox realm** — HMAC-signed outbound events with retry, per-host isolation, circuit breaker and dead-letter; payloads carry identifiers and metadata only, filtered to what the host may see; Java and TypeScript SDKs wrapping auth, resumable upload, ranged download and viewer-token minting; a sandbox realm with synthetic data; a per-host dashboard.
- **E6 Notifications, subscriptions, saved searches** — watches on documents and folders, digest modes, subscribable saved searches, and **permission re-check at send time** so a notification never discloses a title the recipient can no longer see.

**Acceptance**
- [ ] A view-only token used against the download endpoint returns 403 and writes `TOKEN_SCOPE_EXCEEDED`.
- [ ] A webhook payload never contains content bytes, and never names a resource the subscribing host cannot see.
- [ ] A dead host application's failing deliveries do not delay indexing or audit for anyone else.
- [ ] A notification queued for a user whose access was revoked before send is suppressed.
- [ ] A token minted for subject A, presented for subject B's session, is rejected.
- [ ] An expired token is rejected; an ACL revoked *after* minting causes the next stream request to fail.
- [ ] The widget renders a `HOT` and an `ARCHIVED` document with no functional difference visible to the user.
- [ ] A 500 MB video seeks to the midpoint without downloading the preceding bytes.
- [ ] Search results never include a document the caller cannot open, and the result count matches the trimmed set.
- [ ] axe-core reports no serious violations on the viewer.

---

## §6 — Phase 4 · Intelligence and records

Structured extraction with confidence scores and low-confidence flagging · semantic/vector search behind the same search interface · **redaction pipeline** (derivative → strip text layer → re-OCR → **purge and re-index that version's search entries** → automated verification that redacted strings are absent → publish) · annotations · usage statistics and admin dashboards · exportable CSV/PDF compliance reports · bulk import/export.

**Plus (PRD v2.1):**
- **E2 Retention, disposition and eDiscovery** — retention schedules by document class with trigger events; rule-based application; a **disposition review queue where nothing is ever destroyed without human approval**; permanent destruction certificates that outlive the content; eDiscovery cases with cross-realm collection under elevated entitlement, hold placement that overrides every other rule, and production sets with manifest, hash list and chain of custody.
- **E4 Document relationships** — typed links with automatically maintained inverses, a superseded-document banner in the viewer, and relationship context in search results.
- **E5 Bulk intake and scanning** — watched hot folders, barcode/QR separator-sheet splitting, an operator batch-indexing queue, and an exception queue where nothing is silently dropped or silently released.
- **E1-04…06 DLP** — AI-suggested classification as a recommendation only, egress anomaly detection on download volume, second-approver requirement for bulk export of `RESTRICTED` content.

**Acceptance**
- [ ] After redaction, searching for a redacted string returns zero hits and text extraction from the served file does not contain it.
- [ ] The original unredacted version remains retrievable only by explicitly entitled principals, and that access is audited at elevated severity.
- [ ] No code path destroys content without a recorded human approval; a hold blocks every schedule; a destruction certificate survives the content it describes.
- [ ] Creating a `SUPERSEDES` link automatically creates the inverse, and the inverse cannot be deleted independently.
- [ ] A scan batch with three separator sheets yields three documents with reference numbers populated from the codes; a malformed batch lands in the exception queue with a readable reason.

---

## §7 — Phase 5 · Scale and hardening

k6 profiles proving every target in PRD §20.2 · Oracle explain-plan review of the ten hottest queries · connection-pool and LOB tuning · DR drill with restore verification over a 1,000-document sample · DB archival of aged partitions · chargeback report · canary rollout by realm with feature flags · documented backout per phase.

**Plus (PRD v2.1):**
- **E12 Per-realm envelope encryption** — data keys wrapped by the HSM/KMS master key, rotation by re-wrap without content rewrite, key generation recorded per chunk and archive object, crypto-shredding as a disposition event, and a **key-rotation drill included in the DR exercise**.
- **E3-04…06 Preservation** — PDF/A renditions for flagged classes, RFC 3161 timestamping of the whole-file hash at commit, and a downloadable integrity certificate (hash, timestamp token, audit extract, chain position).
- **E8-03 Access review campaigns** — scheduled recertification where owners confirm or revoke, and unconfirmed grants expire.

**Acceptance**
- [ ] A realm key rotation completes on a 100 GB realm without rewriting a single content byte, and all content remains readable throughout.
- [ ] With the KMS unavailable, cached wrapped keys keep reads working for the documented TTL and then fail loudly rather than silently serving ciphertext.
- [ ] An integrity certificate verifies independently of ECM, using only the timestamp token and the file.

---

## §8 — Backend engineering standards

- **Module shape:** `api` (controllers, DTOs, mappers) → `application` (use cases, `@Transactional` boundaries, orchestration) → `domain` (aggregates, value objects, invariants, domain events — **no framework**) ← `infrastructure` (JPA entities, JDBC, filesystem, HTTP clients, cache adapters).
- **Never** expose a JPA entity through a controller. DTOs at the edge, mapped explicitly (MapStruct or hand-written — no reflection magic).
- **Transactions live in `application`,** never in `api` or `domain`. Never hold a transaction open across a network call or a byte stream.
- **Streaming:** use `StreamingResponseBody` / `InputStreamResource` with virtual threads. Never buffer a whole file in memory. Never `byte[]` a file — the codebase should not contain a single full-file byte array outside tests.
- **Optimistic locking** (`@Version`) on documents, versions, tier state and quota rows.
- **Outbox:** every domain event that must reach another service is written in the same transaction as the state change, then relayed. Consumers are idempotent by event id.
- **Errors:** one `ErrorCode` enum, one problem-detail `type` URN per code, no stack traces or internal identifiers in responses.
- **Logging:** structured JSON, correlation id on every line, never log content bytes, tokens, or file contents.
- **Config:** typed `@ConfigurationProperties` records with validation. No `@Value` scattered through the code.
- **Nullability:** JSpecify annotations; `Optional` for return types only, never for fields or parameters.

---

## §9 — Testing standards (the brief explicitly asks for independently testable services)

| Level | Rules |
|---|---|
| Domain unit | No Spring context, no DB, no mocks of value objects. Table-driven where it fits. |
| Application | Ports mocked; assert orchestration, transaction boundaries and emitted events. |
| Adapter slice | `@DataJpaTest` per repository against **both** dialects; `@WebMvcTest` per controller. |
| Contract | Assert the running service against its published OpenAPI; the spec is generated from code and checked into the repo, and a diff is a review event. |
| Integration | Testcontainers: real Oracle, real Redis, real search, real archive mount (a bind-mounted temp dir). Full flows only. |
| Integrity property | Randomised content across boundary sizes through the entire lifecycle → byte-identical. |
| Concurrency | Parallel check-in, parallel rehydration, parallel quota consumption at the boundary, parallel chunk PUT retries. |
| Authorisation matrix | Generated, exhaustive, 100% of cells asserted. |
| Architecture | ArchUnit: layering, no framework in domain, no cross-service packages, no `System.out`, no `Instant.now()` outside `ClockProvider`. |
| Frontend | Vitest/Jest units, Playwright E2E for upload → list → preview → share, axe-core on every primary screen. |
| Load | k6 against §20.2 targets, nightly, regression blocks release. |

**Coverage gates:** `domain` ≥ 85%, `application` ≥ 80%. Coverage is a floor, not a goal — a test that asserts nothing is worse than no test.

**Test data:** builders with sensible defaults (`aDocument().withVersions(3).build()`), never shared mutable fixtures, never real institutional data.

---

## §10 — Frontend engineering standards

- **Angular 21:** standalone components only, signals for state, `resource()`/`httpResource` for async reads, `@if`/`@for`/`@switch`, zoneless change detection, `OnPush`, `@defer` for the viewer and heavy panels, lazy routes per feature, `inject()` over constructor injection.
- **Optimus UI is wrapped.** Feature code imports `EcmButton`, `EcmTable`, `EcmTree`, `EcmDialog`, `EcmStatusPill`, `EcmFileIcon` from `ecm-ui-kit`. If Optimus lacks a component or its API shifts, one wrapper changes.
- **Design tokens** are CSS custom properties exactly as listed in PRD §22.2 — nav gradient `#0B1836→#152449`, primary `#1A56DB`, accent `#2B7FBF`, canvas `#F7F8FA`, border `#E3E8EF`, text `#1F2937`/`#6B7280`, info banner `#EAF1FE`/`#1A56DB`, pending pill `#FDF0E3`/`#C2700B`, approved `#E7F6EC`/`#1E7B3C`, rejected `#FDECEC`/`#C0392B`, radius `8px`. **Type sizes in `rem`** so the A-/A/A+ control scales the entire interface.
- **Two applications, two audiences.** Admin console: entity configuration (governed storage tier list, multi-select extensions, bounded document size, fixed `/ECM/` path prefix with the blue rule banner, maker–checker status pills, kebab row menu), policies, health dashboard. User workspace: exactly two roots per entity — **Public** and **My Private** — plus the file manager, search and viewer. Admins see all roots including Restricted.
- **File manager:** CDK virtual scroll, full ARIA `tree` semantics with type-ahead, breadcrumbs, right-click context menu, multi-select with cut/copy/paste, drag-and-drop upload including folder structures, optimistic rename with rollback.
- **Upload:** Web Worker computes SHA-256 while chunking; bounded parallel chunk PUTs; per-file progress; pause/resume; resume across a page reload using the persisted session id.
- **Accessibility is a build gate,** not a review comment: axe-core in CI, visible focus, no focus traps, contrast ≥ 4.5:1 including status pills, `prefers-reduced-motion` respected.
- **i18n:** every string externalised from the first commit — English and Hindi. Locale-aware dates, numbers and file sizes. Devanagari-capable fonts in the viewer.
- **API clients are generated** from the checked-in OpenAPI specs. Never hand-write a client.

---

## §11A — Adversarial verification (mandatory, every layer, every phase)

Passing tests prove the code does what you intended. They do not prove it resists what you did not think of. **Every phase ends with an adversarial pass, and the pass is a deliverable, not a formality.**

Method: after the phase's normal tests are green, **switch role**. Stop being the engineer who wrote it and become the person trying to break it, exfiltrate from it, corrupt it, or make it lie. Write the attacks as permanent tests — not as a one-off exploration. Record every finding in `docs/ADVERSARIAL-LOG.md` with severity, the failing case, and the fix. A phase is not done while a HIGH finding is open.

Run this per layer:

**Database layer**
- Concurrent writers to the same document, version, quota row and tier state — does optimistic locking actually hold, or do you get lost updates?
- Kill the process mid-transaction during chunk write, during archival, during rehydration. Is there ever an orphan, a half-visible version, or a released chunk with no archive object?
- Does any query escape the realm predicate? Attempt cross-realm access by direct identifier, by cursor manipulation, by sort injection, by filter injection.
- Do the Oracle and SQLite migrations produce semantically equivalent schemas? Diff them and assert.
- Force partition-boundary conditions, clock skew, duplicate ULIDs, and `NULL`s in every nullable column.

**Storage layer**
- Byte-exactness across every boundary: `0, 1, chunkSize-1, chunkSize, chunkSize+1, threshold-1, threshold, threshold+1, 1 GB`.
- Corrupt an archive object on disk, then read it. Corrupt one chunk in the DB, then read it. Does it fail loudly or serve silent garbage? **Serving silent garbage is a CRITICAL finding.**
- Fill the archive mount. Make it read-only. Disconnect it mid-stream. Make it return slowly. What does the user see?
- Race: archive a version while it is being read; rehydrate while it is being archived; expunge while it is being rehydrated; two archival replicas claim the same batch.
- Truncate an upload. Replay a chunk PUT. Send chunks out of order. Send a chunk with a wrong hash. Commit with a wrong whole-file hash. Commit twice.

**Security layer** — the highest-value pass, do it properly
- **IDOR sweep:** for every endpoint taking an identifier, attempt access with another realm's id, another user's private folder, a soft-deleted document, a quarantined document, an expunged document. Cross-realm must return 404, never 403.
- **Viewer token abuse:** expired token, token for a different subject, different host audience, different document, replayed after ACL revocation, view-only token against download and print, token in a URL that lands in a log, token minted from a browser origin.
- **Privilege escalation:** maker approving own submission via API, user raising own ACL, user lowering a sensitivity label, non-admin invoking break-glass, auditor attempting a write, share-link recipient attempting to enumerate siblings.
- **Policy bypass:** share a `RESTRICTED` document externally, exceed the realm's maximum expiry, disable a mandatory watermark, download from a link past its download limit, use a revoked link, use a link whose underlying ACL was removed.
- **Cache poisoning and staleness:** revoke a permission and immediately re-request; confirm the ≤60 s ceiling actually holds and that write-through invalidation fires on every revocation path.
- **Injection and traversal:** mount paths (`../`, absolute, symlink, unicode normalisation, null byte), filenames, metadata values, search queries, cursor tokens, ETags.
- **Malicious content:** zip bomb, PDF with embedded JavaScript, SVG with a script, polyglot file whose magic bytes disagree with its extension, 10 GB declared size with 1 KB body, filename with path separators, EICAR test string through the AV path.
- **Audit integrity:** attempt to update or delete an audit row; break the hash chain deliberately and confirm verification catches it.

**Service and API layer**
- Malformed, oversized, deeply nested and duplicate-key payloads on every endpoint.
- Missing, replayed and conflicting `Idempotency-Key` values.
- Cursor tampering — forged, truncated, from another realm, from another sort order.
- Every downstream dependency down, slow, and flapping: Oracle, Redis, search, archive mount, AV, KMS, Kavach JWKS. Confirm the degradation posture in PRD §19 is what actually happens.
- Backwards compatibility: does an old client still work after this phase's changes?

**Frontend layer**
- XSS via filename, folder name, metadata value, search term, share message and OCR text rendered in the UI.
- CSP violations; whether the widget in iframe mode can reach its parent; whether `postMessage` validates origin.
- Does the UI ever render an action the server would reject — a download button on a view-only token, a delete option under legal hold? UI and server must agree, and the server must be the authority.
- Keyboard-only traversal of the file tree and viewer; screen-reader pass; 200% zoom; `prefers-reduced-motion`.
- Upload of 500 files, a 2 GB file, a file with a 255-character name, a folder nested 30 deep; page reload mid-upload.

**Data-integrity layer (cross-cutting)**
- The end-to-end property test after every phase: random content → upload → classify → archive → release → fixity-verify → rehydrate → download → **byte-identical**, with the audit chain intact throughout.
- Deliberately desynchronise the search index and confirm the reconciliation job repairs it.
- Deliberately corrupt quota accounting and confirm the nightly reconciliation reports it.

**Deliverable per phase:** `docs/ADVERSARIAL-LOG.md` updated, all new attack cases committed as permanent tests, zero open HIGH or CRITICAL findings, and a one-paragraph summary in the closing report of what you tried that *didn't* break it — that is as informative as what did.

---

## §11 — Mock Kavach (build this properly, it will be used for months)

`org.rebit.ecm.security.mock`, active under the `dev` and `test` profiles, behind the identical SPI:

- Local RSA keypair generated at startup; JWKS served at the same path shape as real Kavach.
- `POST /dev/token {username}` mints a valid token with the seeded user's realm, roles and groups.
- Seed data covering every persona in PRD §2.3, two realms, two entities, and users entitled to one realm, both realms, and neither (for negative tests).
- A dev-only login screen in both Angular apps offering the seeded users as one-click logins.
- Configurable failure injection: expired token, wrong audience, wrong issuer, revoked group, JWKS unavailable — so the real integration path is exercised before Kavach is available.

**The switch to real Kavach must be a configuration change and a new adapter class. If it requires touching anything in `core`, `content` or `archival`, the abstraction is wrong — fix it then, not later.**

---

## §12 — Raise these in Mode 1, at the start of the session

Put every one of these that is relevant to the phase into your **single opening message**, together with the fallback assumption you will proceed on if I don't answer. Do not stop mid-phase to ask about them:

1. Search engine — OpenSearch, Elasticsearch or Oracle Text. *(Code to the interface until answered.)*
2. Archive tier medium — NFS mount or S3-compatible object storage. *(Abstract behind `ArchiveStore` until answered.)*
3. Kavach token exchange — real RFC 8693 support, or ECM mints its own capability tokens.
4. Optimus UI version, package name and theming API for Angular 21.
5. OCR engine and Devanagari language pack availability.
6. Whether embeddings may live in Oracle or need an approved vector store.
7. Antivirus service interface and scan-latency SLA.
8. Sensitivity-classification taxonomy — does the institution mandate one, or does ECM define it?
9. RFC 3161 timestamping authority availability; whether PDF/A is mandated for any document class.
10. HSM/KMS API for per-realm data-key wrapping and rotation.
11. Whether scanning stations and hot-folder mounts sit in the ECM network zone.
12. Anything that would require storing a credential, a secret, or real institutional data.
13. Any change that would break one of the twelve non-negotiables in §0 — if you believe one of them is wrong, argue for it explicitly in Mode 1 rather than working around it in Mode 2.

**Also ask for, in the same opening message, every permission the phase will need** — package installs, container pulls, port bindings, outbound network, writes outside the repo, long-running background processes, destructive git or schema operations. Get them all granted once so Mode 2 never has to interrupt me.

---

## §13 — Definition of done (every story, every phase)

- [ ] Code plus tests meeting the coverage gate
- [ ] OpenAPI regenerated and committed; the diff reviewed
- [ ] Flyway migration written for **both** dialects and verified forward from empty
- [ ] Audit events emitted for every state change
- [ ] Metrics exposed and at least one alert defined where the story touches a target in PRD §20.2
- [ ] Error paths return problem details with a stable error code
- [ ] `Idempotency-Key` honoured on mutations; cursor pagination on collections
- [ ] axe-core clean on any touched screen
- [ ] ArchUnit and the full Oracle integration suite green
- [ ] **Adversarial pass complete per §11A; attack cases committed as permanent tests; zero open HIGH or CRITICAL findings**
- [ ] Sensitivity-label policy consulted on any action that shares, exports, downloads or previews content
- [ ] `docs/CHANGELOG.md`, `docs/ASSUMPTIONS.md` and `docs/ADVERSARIAL-LOG.md` updated; `docs/RUNBOOK.md` where operationally relevant
- [ ] Demonstrable end-to-end through the UI — not just a passing test

---

## §14 — First session script

```
Read BUILD_PROMPT.md, docs/03-ECM-PRD-v2.1-FINAL.md and
docs/04-ECM-System-Architecture-v1.1.md in full.

You are in MODE 1. Do not write any code yet. Produce ONE consolidated message
containing all of the following, and then stop:

1. The twelve non-negotiables (§0) restated in your own words, so I can confirm
   you have them, plus any you think are wrong and why.
2. EVERY question you need answered for Phase 0 — requirements, ambiguities,
   conflicts between the documents — each with the fallback assumption you will
   proceed on if I don't answer it.
3. EVERY permission you will need for the whole of Phase 0: package installs,
   container pulls, port bindings, outbound network, writes outside the repo,
   background processes, destructive git or schema operations. All of them, now.
4. Your Phase 0 plan, file by file, in dependency order, showing:
   - the Gradle module graph
   - the V1 Flyway migration table by table, for BOTH dialects
   - the parallel work streams per §0.6, what each subagent owns, where they join
   - the OpenAPI contract you will write FIRST, before fanning out
5. Your Phase 0 adversarial plan per §11A — what you intend to attack, per layer.

I will answer everything in one reply.

You are then in MODE 2: build all of Phase 0 to completion without asking me
anything further. Work the streams in parallel. Run long jobs in the background.
Apply your declared assumptions where reality differs and log them with
⚠ NEEDS CONFIRMATION. Finish with the adversarial pass, then report:
what was built · what the adversarial pass found and fixed · what it survived ·
open assumptions · the Phase 0 acceptance checklist with actual results.
```
