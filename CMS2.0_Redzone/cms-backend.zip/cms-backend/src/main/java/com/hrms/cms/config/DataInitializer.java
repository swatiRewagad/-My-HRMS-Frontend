package com.hrms.cms.config;

import com.hrms.cms.entity.AccountTypeMaster;
import com.hrms.cms.entity.Bank;
import com.hrms.cms.entity.Complaint;
import com.hrms.cms.entity.ComplaintCategory;
import com.hrms.cms.entity.EmailDraft;
import com.hrms.cms.entity.ExtractionRule;
import com.hrms.cms.entity.FormConfig;
import com.hrms.cms.entity.OfficeCodeMaster;
import com.hrms.cms.entity.OmbudsmanOfficeMaster;
import com.hrms.cms.entity.RegulatedEntity;
import com.hrms.cms.repository.AccountTypeMasterRepository;
import com.hrms.cms.repository.BankRepository;
import com.hrms.cms.repository.ComplaintCategoryRepository;
import com.hrms.cms.repository.ComplaintRepository;
import com.hrms.cms.repository.EmailDraftRepository;
import com.hrms.cms.repository.ExtractionRuleRepository;
import com.hrms.cms.repository.FormConfigRepository;
import com.hrms.cms.repository.OfficeCodeMasterRepository;
import com.hrms.cms.repository.OmbudsmanOfficeMasterRepository;
import com.hrms.cms.repository.RegulatedEntityRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@Profile("!prod")
@RequiredArgsConstructor
@Order(1)
public class DataInitializer implements CommandLineRunner {

    private final ComplaintCategoryRepository categoryRepo;
    private final BankRepository bankRepo;
    private final FormConfigRepository formConfigRepo;
    private final ComplaintRepository complaintRepo;
    private final RegulatedEntityRepository regulatedEntityRepo;
    private final EmailDraftRepository emailDraftRepo;
    private final ExtractionRuleRepository extractionRuleRepo;
    private final AccountTypeMasterRepository accountTypeRepo;
    private final OmbudsmanOfficeMasterRepository ombudsmanOfficeRepo;
    private final OfficeCodeMasterRepository officeCodeRepo;

    @Override
    public void run(String... args) {
        try {
            if (categoryRepo.count() == 0) {
                seedCategories();
            }
            if (bankRepo.count() == 0) {
                seedBanks();
            }
            if (formConfigRepo.count() == 0) {
                seedComplaintForm();
            }
            if (complaintRepo.count() == 0) {
                seedComplaints();
            }
            if (regulatedEntityRepo.count() == 0) {
                seedRegulatedEntities();
            }
            if (extractionRuleRepo.count() == 0) {
                seedExtractionRules();
            }
            if (accountTypeRepo.count() == 0) {
                seedAccountTypes();
            }
            if (emailDraftRepo.count() == 0) {
                seedCrpcEmailDrafts();
            }
            migrateUuidDraftIds();
        } catch (Exception e) {
            System.out.println("DataInitializer warning: " + e.getMessage());
        }
        if (bankRepo.count() == 0) {
            seedBanks();
        }
        if (formConfigRepo.count() == 0) {
            seedComplaintForm();
        }
        if (complaintRepo.count() == 0) {
            seedComplaints();
        }
        if (regulatedEntityRepo.count() == 0) {
            seedRegulatedEntities();
        }
        if (extractionRuleRepo.count() == 0) {
            seedExtractionRules();
        }
        if (accountTypeRepo.count() == 0) {
            seedAccountTypes();
        }
        if (emailDraftRepo.count() == 0) {
            seedCrpcEmailDrafts();
        }
        if (ombudsmanOfficeRepo.count() == 0) {
            seedOmbudsmanOfficeMaster();
        }
        if (officeCodeRepo.count() == 0) {
            seedOfficeCodeMaster();
        }
        migrateUuidDraftIds();
    }

    private void seedCrpcEmailDrafts() {
        LocalDateTime now = LocalDateTime.now();

        // Draft 1: Standard email complaint - ATM issue (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100001")
                .threadId("THR-EMAIL-001")
                .senderEmail("ramesh.gupta@gmail.com")
                .subject("ATM did not dispense cash but Rs 20,000 debited from my account")
                .body("Dear Sir/Madam,\n\nI am writing to complain about an ATM transaction failure. On 15th August 2026, I tried to withdraw Rs 20,000 from HDFC Bank ATM at MG Road, Pune. The machine displayed 'Transaction Cancelled' but the amount was debited from my savings account (A/C No: 1234567890).\n\nI have already complained to the bank branch on 16th August but no resolution has been provided. My mobile number is 9876543210.\n\nAddress: Flat 12B, Sunrise Apartments, MG Road, Pune, Maharashtra - 411001\n\nKindly look into this matter urgently.\n\nRegards,\nRamesh Gupta")
                .complainantName("Ramesh Gupta")
                .complainantPhone("9876543210")
                .complainantAddress("Flat 12B, Sunrise Apartments, MG Road, Pune")
                .complainantState("MH")
                .complainantDistrict("Pune")
                .complainantPincode("411001")
                .category("ATM")
                .entityName("HDFC Bank")
                .entityType("BANK")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .amountInvolved(20000.0)
                .receivedAt(now.minusDays(2))
                .createdAt(now.minusDays(2))
                .build());

        // Draft 2: Credit card fraud complaint (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100002")
                .threadId("THR-EMAIL-002")
                .senderEmail("priya.mehta@yahoo.com")
                .subject("Unauthorized credit card transactions - Rs 45,000 charged")
                .body("To Whom It May Concern,\n\nI wish to report unauthorized transactions on my ICICI Bank credit card ending 8976. On 12th August 2026, three transactions totaling Rs 45,000 were made on Amazon and Flipkart which I did not authorize. My card was in my possession the entire time.\n\nI have blocked the card and raised a dispute with ICICI Bank on 13th Aug. Reference number: ICR-2026-45678. However, no temporary credit has been provided.\n\nPlease investigate this matter. Contact: 9123456789. Residing at 45, Sector 22, Noida, Uttar Pradesh - 201301.\n\nPriya Mehta")
                .complainantName("Priya Mehta")
                .complainantPhone("9123456789")
                .complainantAddress("45, Sector 22, Noida")
                .complainantState("UP")
                .complainantDistrict("Gautam Buddha Nagar")
                .complainantPincode("201301")
                .category("CREDIT_CARD")
                .entityName("ICICI Bank")
                .entityType("BANK")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .amountInvolved(45000.0)
                .receivedAt(now.minusDays(1))
                .createdAt(now.minusDays(1))
                .build());

        // Draft 3: UPI fraud - PhonePe (CEPC entity, assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100003")
                .threadId("THR-EMAIL-003")
                .senderEmail("anil.sharma@hotmail.com")
                .subject("PhonePe unauthorized UPI debit of Rs 8,500")
                .body("Sir,\n\nPhonePe debited Rs 8,500 from my linked SBI account without my authorization on 10th August 2026. I did not initiate any payment. The UPI transaction ID is 2026081090123456.\n\nI raised a complaint with PhonePe (Ticket #PH-2026-99887) on 11th Aug but they say the transaction is legitimate. I have never shared my UPI PIN with anyone.\n\nMy details:\nName: Anil Sharma\nPhone: 9988776655\nAddress: 78, Gandhi Nagar, Jaipur, Rajasthan - 302015\n\nPlease help.\nAnil Sharma")
                .complainantName("Anil Sharma")
                .complainantPhone("9988776655")
                .complainantAddress("78, Gandhi Nagar, Jaipur")
                .complainantState("RJ")
                .complainantDistrict("Jaipur")
                .complainantPincode("302015")
                .category("UPI")
                .entityName("PhonePe Private Limited")
                .entityType("PAYMENT_SYSTEM")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .amountInvolved(8500.0)
                .receivedAt(now.minusHours(18))
                .createdAt(now.minusHours(18))
                .build());

        // Draft 4: Loan harassment - NBFC (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100004")
                .threadId("THR-EMAIL-004")
                .senderEmail("sunita.devi@gmail.com")
                .subject("Harassment by Bajaj Finance recovery agents")
                .body("Respected Sir/Madam,\n\nI am being harassed by Bajaj Finance recovery agents. My EMI was delayed by only 7 days due to medical emergency (husband hospitalized). Recovery agents are coming to my house at 6 AM, using abusive language in front of neighbors, and threatening my family.\n\nLoan Account: BAF-PL-2024-567890. Total outstanding is Rs 1,80,000. I have paid all previous EMIs on time for 18 months.\n\nThis is causing mental trauma to my family. Please intervene.\n\nSunita Devi\nMobile: 9876501234\nAddress: 23, Shivaji Nagar, Kolhapur, Maharashtra - 416001")
                .complainantName("Sunita Devi")
                .complainantPhone("9876501234")
                .complainantAddress("23, Shivaji Nagar, Kolhapur")
                .complainantState("MH")
                .complainantDistrict("Kolhapur")
                .complainantPincode("416001")
                .category("LOAN")
                .entityName("Bajaj Finance Limited")
                .entityType("NBFC")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .amountInvolved(180000.0)
                .receivedAt(now.minusHours(12))
                .createdAt(now.minusHours(12))
                .build());

        // Draft 5: Vernacular complaint in Hindi (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100005")
                .threadId("THR-EMAIL-005")
                .senderEmail("mohan.yadav@gmail.com")
                .subject("बैंक खाते से अनधिकृत निकासी - कृपया सहायता करें")
                .body("महोदय,\n\nमेरे पंजाब नेशनल बैंक के बचत खाते (खाता संख्या: 0987654321) से 8 अगस्त 2026 को बिना मेरी अनुमति के रु 35,000 की निकासी हुई है। मैंने कोई ATM लेनदेन नहीं किया था और न ही किसी को अपना PIN दिया है।\n\nमैंने बैंक शाखा में शिकायत दर्ज की है (संदर्भ: PNB-CMP-2026-12345) लेकिन 10 दिन हो गए, कोई कार्रवाई नहीं हुई।\n\nनाम: मोहन यादव\nमोबाइल: 9011223344\nपता: 56, विकास नगर, लखनऊ, उत्तर प्रदेश - 226022\n\nकृपया मेरी मदद करें।")
                .complainantName("Mohan Yadav")
                .complainantPhone("9011223344")
                .complainantAddress("56, Vikas Nagar, Lucknow")
                .complainantState("UP")
                .complainantDistrict("Lucknow")
                .complainantPincode("226022")
                .category("ATM")
                .entityName("Punjab National Bank")
                .entityType("BANK")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .isVernacular(true)
                .detectedLanguage("HINDI")
                .languageName("Hindi")
                .amountInvolved(35000.0)
                .receivedAt(now.minusHours(6))
                .createdAt(now.minusHours(6))
                .build());

        // Draft 6: Not a complaint - just a general inquiry (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100006")
                .threadId("THR-EMAIL-006")
                .senderEmail("info@techstartup.in")
                .subject("Inquiry about RBI payment aggregator license process")
                .body("Dear RBI Team,\n\nWe are a fintech startup looking to apply for a Payment Aggregator license under the RBI guidelines. Could you please share the detailed process, documentation requirements, and timeline for the application?\n\nAlso, is there a helpdesk or nodal officer we can contact for queries during the application process?\n\nRegards,\nVikram Sinha\nCTO, TechStartup Payments Pvt Ltd\nMobile: 9876509876\nEmail: vikram@techstartup.in\nAddress: WeWork, BKC, Mumbai, Maharashtra - 400051")
                .complainantName("Vikram Sinha")
                .complainantPhone("9876509876")
                .complainantAddress("WeWork, BKC, Mumbai")
                .complainantState("MH")
                .complainantDistrict("Mumbai")
                .complainantPincode("400051")
                .category("GENERAL")
                .entityName("")
                .entityType("")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .receivedAt(now.minusHours(4))
                .createdAt(now.minusHours(4))
                .build());

        // Draft 7: Physical letter - CPGRAMS forwarded (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100007")
                .threadId("THR-CPGRAMS-001")
                .senderEmail("cpgrams-forward@gov.in")
                .subject("CPGRAMS Forwarded: Gold loan ornaments not returned by Muthoot Finance")
                .body("CPGRAMS Reference: PMOPG/D/2026/0812345\n\nComplainant: Lakshmi Narayanan\nMobile: 9090909090\nAddress: 12, Temple Street, Coimbatore, Tamil Nadu - 641001\n\nComplaint Details:\nI repaid my gold loan (Loan A/C: MF-GL-2025-98765) in full on 1st July 2026 at Muthoot Finance, RS Puram Branch, Coimbatore. Despite full repayment, they have not returned my gold ornaments (total 45 grams). Each time I visit, they cite different reasons - system issue, branch manager not available, etc.\n\nAmount of gold loan was Rs 2,25,000 (fully repaid). Gold ornaments worth approximately Rs 3,00,000 at current market rate.\n\nThis has been going on for 45 days. Please intervene.")
                .complainantName("Lakshmi Narayanan")
                .complainantPhone("9090909090")
                .complainantAddress("12, Temple Street, Coimbatore")
                .complainantState("TN")
                .complainantDistrict("Coimbatore")
                .complainantPincode("641001")
                .cpgramsNumber("PMOPG/D/2026/0812345")
                .category("LOAN")
                .entityName("Muthoot Finance Ltd")
                .entityType("NBFC")
                .modeOfReceipt("CPGRAMS")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .amountInvolved(225000.0)
                .receivedAt(now.minusHours(3))
                .createdAt(now.minusHours(3))
                .build());

        // Draft 8: Cooperative bank issue (assigned to deo.user)
        emailDraftRepo.save(EmailDraft.builder()
                .draftId("100008")
                .threadId("THR-EMAIL-008")
                .senderEmail("deepak.patil@gmail.com")
                .subject("Saraswat Bank refusing to update nominee on FD account")
                .body("Dear Ombudsman,\n\nI am facing an issue with Saraswat Co-operative Bank, Dadar Branch, Mumbai. They are refusing to update the nominee on my Fixed Deposit account (FD A/C: SAR-FD-2020-11223) despite providing all required documents (death certificate of earlier nominee, new nominee's Aadhaar, PAN).\n\nI have visited the branch 5 times in the last 2 months. Each time they ask for a different document. This seems like deliberate harassment.\n\nFD Amount: Rs 10,00,000 (maturing in Dec 2026).\n\nDeepak Patil\nMobile: 9876567890\nAddress: 34, Dadar West, Mumbai, Maharashtra - 400028")
                .complainantName("Deepak Patil")
                .complainantPhone("9876567890")
                .complainantAddress("34, Dadar West, Mumbai")
                .complainantState("MH")
                .complainantDistrict("Mumbai")
                .complainantPincode("400028")
                .category("DEPOSIT")
                .entityName("Saraswat Co-operative Bank Limited")
                .entityType("COOPERATIVE_BANK")
                .modeOfReceipt("EMAIL")
                .status("ASSIGNED")
                .assignedTo("deo.user")
                .amountInvolved(1000000.0)
                .receivedAt(now.minusHours(2))
                .createdAt(now.minusHours(2))
                .build());
    }

    private void migrateUuidDraftIds() {
        List<EmailDraft> drafts = emailDraftRepo.findAll();
        for (EmailDraft draft : drafts) {
            boolean changed = false;
            if (draft.getDraftId() != null && draft.getDraftId().contains("-") && draft.getDraftId().length() > 20) {
                draft.setDraftId(String.format("%06d", draft.getId()));
                changed = true;
            }
            // Migrate displayName assignments to userId
            String assigned = draft.getAssignedTo();
            if ("Amit Verma".equals(assigned)) { draft.setAssignedTo("deo_001"); changed = true; }
            else if ("Sneha Patil".equals(assigned)) { draft.setAssignedTo("deo_002"); changed = true; }
            else if ("Ramesh Iyer".equals(assigned)) { draft.setAssignedTo("deo_003"); changed = true; }
            else if ("Priya Sharma".equals(assigned)) { draft.setAssignedTo("deo_001"); changed = true; }

            if (changed) emailDraftRepo.save(draft);
        }
    }

    private void seedComplaints() {
        LocalDateTime now = LocalDateTime.now();

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260601-A1B2C3")
                .complainantName("Rajesh Kumar")
                .complainantEmail("rajesh.kumar@email.com")
                .complainantPhone("9876543210")
                .bankId(1L).categoryId(1L)
                .subject("ATM did not dispense cash but account debited Rs. 10,000")
                .description("Tried to withdraw Rs 10,000 from SBI ATM near MG Road. Machine showed error but amount was debited.")
                .status("pending").priority("high")
                .filingType("WEB_PORTAL")
                .createdAt(now.minusDays(2)).updatedAt(now.minusDays(2)).filedAt(now.minusDays(2))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260601-D4E5F6")
                .complainantName("Priya Sharma")
                .complainantEmail("priya.sharma@email.com")
                .complainantPhone("9123456789")
                .bankId(6L).categoryId(4L)
                .subject("UPI transaction failed but Rs. 5,000 debited from account")
                .description("Made UPI payment to merchant. Transaction shows failed but money debited. No refund received in 7 days.")
                .status("in_progress").priority("high")
                .filingType("WEB_PORTAL").assignedOfficer("Team Alpha")
                .createdAt(now.minusDays(5)).updatedAt(now.minusDays(1)).filedAt(now.minusDays(5))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260530-G7H8I9")
                .complainantName("Amit Patel")
                .complainantEmail("amit.patel@email.com")
                .complainantPhone("9988776655")
                .bankId(7L).categoryId(5L)
                .subject("Excessive interest charged on home loan EMI")
                .description("Bank increased interest rate without prior notice. EMI increased by Rs 3,500 per month.")
                .status("in_progress").priority("medium")
                .filingType("WEB_PORTAL").assignedOfficer("Team Beta")
                .createdAt(now.minusDays(8)).updatedAt(now.minusDays(3)).filedAt(now.minusDays(8))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260528-J1K2L3")
                .complainantName("Sunita Devi")
                .complainantEmail("sunita.d@email.com")
                .complainantPhone("9876501234")
                .bankId(2L).categoryId(2L)
                .subject("Unauthorized credit card transaction of Rs. 25,000")
                .description("Found unauthorized online transaction on credit card statement. Card was in my possession.")
                .status("escalated").priority("high")
                .filingType("EMAIL").assignedOfficer("Escalation Desk")
                .createdAt(now.minusDays(12)).updatedAt(now.minusDays(1)).filedAt(now.minusDays(12))
                .escalatedAt(now.minusDays(2))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260525-M4N5O6")
                .complainantName("Mohammed Farooq")
                .complainantEmail("farooq.m@email.com")
                .complainantPhone("9012345678")
                .bankId(3L).categoryId(6L)
                .subject("Fixed deposit maturity amount not credited")
                .description("FD matured on 15th May but amount still not credited to savings account. Multiple branch visits done.")
                .status("resolved").priority("medium")
                .filingType("WEB_PORTAL").assignedOfficer("Team Gamma")
                .createdAt(now.minusDays(20)).updatedAt(now.minusDays(5)).filedAt(now.minusDays(20))
                .resolvedAt(now.minusDays(5))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260520-P7Q8R9")
                .complainantName("Kavita Reddy")
                .complainantEmail("kavita.r@email.com")
                .complainantPhone("9876509876")
                .bankId(8L).categoryId(3L)
                .subject("Internet banking account locked without reason")
                .description("Online banking access blocked. Branch says technical issue. Unable to access account for 10 days.")
                .status("resolved").priority("low")
                .filingType("WEB_PORTAL").assignedOfficer("Team Alpha")
                .createdAt(now.minusDays(25)).updatedAt(now.minusDays(10)).filedAt(now.minusDays(25))
                .resolvedAt(now.minusDays(10))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260518-S1T2U3")
                .complainantName("Deepak Gupta")
                .complainantEmail("deepak.g@email.com")
                .complainantPhone("9011223344")
                .bankId(1L).categoryId(8L)
                .subject("NEFT transfer of Rs. 2,00,000 not credited to beneficiary")
                .description("Initiated NEFT transfer 5 days ago. Amount debited from my account but not received by beneficiary.")
                .status("closed").priority("high")
                .filingType("WEB_PORTAL").assignedOfficer("Team Beta")
                .createdAt(now.minusDays(30)).updatedAt(now.minusDays(15)).filedAt(now.minusDays(30))
                .resolvedAt(now.minusDays(18)).closedAt(now.minusDays(15))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260515-V4W5X6")
                .complainantName("Anita Mishra")
                .complainantEmail("anita.m@email.com")
                .complainantPhone("9988001122")
                .bankId(4L).categoryId(7L)
                .subject("Pension amount not credited for 3 months")
                .description("Monthly pension from PNB not received for April, May, and June. Visited branch multiple times.")
                .status("escalated").priority("high")
                .filingType("PHYSICAL_LETTER").assignedOfficer("Escalation Desk")
                .createdAt(now.minusDays(35)).updatedAt(now.minusDays(3)).filedAt(now.minusDays(35))
                .escalatedAt(now.minusDays(5))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260601-Y7Z8A9")
                .complainantName("Vikram Singh")
                .complainantEmail("vikram.s@email.com")
                .complainantPhone("9876512345")
                .bankId(9L).categoryId(4L)
                .subject("Unauthorized UPI debit of Rs. 15,000 from savings account")
                .description("Received SMS about Rs 15,000 UPI debit. Did not authorize any transaction. Suspect fraud.")
                .status("pending").priority("high")
                .filingType("WEB_PORTAL")
                .createdAt(now.minusHours(6)).updatedAt(now.minusHours(6)).filedAt(now.minusHours(6))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260531-B1C2D3")
                .complainantName("Lakshmi Iyer")
                .complainantEmail("lakshmi.i@email.com")
                .complainantPhone("9090909090")
                .bankId(5L).categoryId(9L)
                .subject("Insurance claim rejected without valid reason")
                .description("Health insurance claim for hospitalization rejected citing pre-existing condition. Policy is 5 years old.")
                .status("under_review").priority("medium")
                .filingType("WEB_PORTAL").assignedOfficer("Team Gamma")
                .createdAt(now.minusDays(4)).updatedAt(now.minusDays(1)).filedAt(now.minusDays(4))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260529-E4F5G6")
                .complainantName("Ravi Shankar")
                .complainantEmail("ravi.s@email.com")
                .complainantPhone("9876567890")
                .bankId(10L).categoryId(5L)
                .subject("Harassment by loan recovery agents")
                .description("Recovery agents visiting home at odd hours, using abusive language. Loan EMI was delayed by only 5 days.")
                .status("in_progress").priority("high")
                .filingType("WEB_PORTAL").assignedOfficer("Team Alpha")
                .createdAt(now.minusDays(7)).updatedAt(now.minusDays(2)).filedAt(now.minusDays(7))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260527-H7I8J9")
                .complainantName("Neha Kapoor")
                .complainantEmail("neha.k@email.com")
                .complainantPhone("9123498765")
                .bankId(6L).categoryId(10L)
                .subject("Bank refusing to close savings account")
                .description("Requested account closure 3 weeks ago. Bank keeps asking for additional documents and delaying.")
                .status("pending").priority("low")
                .filingType("WEB_PORTAL")
                .createdAt(now.minusDays(10)).updatedAt(now.minusDays(10)).filedAt(now.minusDays(10))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMS-20260522-K1L2M3")
                .complainantName("Suresh Babu")
                .complainantEmail("suresh.b@email.com")
                .complainantPhone("9000112233")
                .bankId(2L).categoryId(1L)
                .subject("Debit card cloned - multiple unauthorized transactions")
                .description("Found 8 unauthorized ATM withdrawals from different cities. Total loss Rs 80,000. Card was with me.")
                .status("closed").priority("high")
                .filingType("EMAIL").assignedOfficer("Team Beta")
                .createdAt(now.minusDays(40)).updatedAt(now.minusDays(20)).filedAt(now.minusDays(40))
                .resolvedAt(now.minusDays(25)).closedAt(now.minusDays(20))
                .build());

        // ═══ CEPC Complaints (routed based on entity in REGULATED_ENTITIES table) ═══
        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260605-100001")
                .complainantName("Arun Verma")
                .complainantEmail("arun.v@email.com")
                .complainantPhone("9876500001")
                .subject("Bajaj Finance charged excessive processing fee on personal loan")
                .description("Applied for personal loan via Bajaj Finance. Processing fee charged was 4% instead of advertised 1.5%. No prior disclosure.")
                .status("assigned").priority("high")
                .filingType("EMAIL").department("CEPC").assignedRole("CEPC_DO")
                .entityCode("Bajaj Finance Limited").workflowStage("INITIAL_REVIEW")
                .createdAt(now.minusDays(3)).updatedAt(now.minusDays(3)).filedAt(now.minusDays(3))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260604-100002")
                .complainantName("Meera Joshi")
                .complainantEmail("meera.j@email.com")
                .complainantPhone("9876500002")
                .subject("Muthoot Finance not releasing gold ornaments after loan repayment")
                .description("Fully repaid gold loan on 15th May. Multiple visits to branch. They keep saying system issue and not releasing pledged gold.")
                .status("in_progress").priority("high")
                .filingType("PHYSICAL_LETTER").department("CEPC").assignedRole("CEPC_DO").assignedOfficer("cepc.officer1")
                .entityCode("Muthoot Finance Ltd").workflowStage("EXAMINATION")
                .createdAt(now.minusDays(5)).updatedAt(now.minusDays(1)).filedAt(now.minusDays(5))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260603-100003")
                .complainantName("Sanjay Patil")
                .complainantEmail("sanjay.p@email.com")
                .complainantPhone("9876500003")
                .subject("PhonePe unauthorized debit of Rs. 8,500 - no refund after 45 days")
                .description("PhonePe deducted Rs 8,500 from linked bank account without authorization. Raised complaint 45 days ago. No resolution.")
                .status("reviewer_review").priority("medium")
                .filingType("WEB_PORTAL").department("CEPC").assignedRole("CEPC_REVIEWER").assignedOfficer("cepc.reviewer1")
                .entityCode("PhonePe Private Limited").workflowStage("REVIEWER_REVIEW")
                .createdAt(now.minusDays(7)).updatedAt(now.minusDays(2)).filedAt(now.minusDays(7))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260602-100004")
                .complainantName("Divya Rao")
                .complainantEmail("divya.r@email.com")
                .complainantPhone("9876500004")
                .subject("Saraswat Co-op Bank refusing to update nominee details")
                .description("Visited branch 4 times to update nominee on FD. Each time they ask for different documents. Seems deliberate delay.")
                .status("incharge_review").priority("medium")
                .filingType("EMAIL").department("CEPC").assignedRole("CEPC_INCHARGE")
                .entityCode("Saraswat Co-operative Bank Limited").workflowStage("INCHARGE_REVIEW")
                .createdAt(now.minusDays(10)).updatedAt(now.minusDays(3)).filedAt(now.minusDays(10))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260601-100005")
                .complainantName("Kiran Deshmukh")
                .complainantEmail("kiran.d@email.com")
                .complainantPhone("9876500005")
                .subject("IIFL Finance harassment - recovery agents threatening family")
                .description("Recovery agents from IIFL Finance visiting home at 6 AM, threatening family members. EMI was delayed by 10 days due to medical emergency.")
                .status("awaiting_closure").priority("high")
                .filingType("EMAIL").department("CEPC").assignedRole("CEPC_CLOSING_AUTHORITY")
                .entityCode("IIFL Finance Limited").workflowStage("AWAITING_CLOSURE")
                .createdAt(now.minusDays(15)).updatedAt(now.minusDays(4)).filedAt(now.minusDays(15))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260530-100006")
                .complainantName("Prakash Mehta")
                .complainantEmail("prakash.m@email.com")
                .complainantPhone("9876500006")
                .subject("Razorpay holding merchant settlement for 3 weeks")
                .description("Payment gateway Razorpay holding Rs 2.5 lakhs settlement amount for 3 weeks. No clear reason given. Affecting business operations.")
                .status("info_requested").priority("medium")
                .filingType("WEB_PORTAL").department("CEPC").assignedRole("CEPC_DO").assignedOfficer("cepc.officer1")
                .entityCode("Razorpay Software Private Limited").workflowStage("AWAITING_INFO")
                .createdAt(now.minusDays(12)).updatedAt(now.minusDays(5)).filedAt(now.minusDays(12))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260528-100007")
                .complainantName("Rekha Sharma")
                .complainantEmail("rekha.s@email.com")
                .complainantPhone("9876500007")
                .subject("Standard Chartered Bank closed NRE account without notice")
                .description("NRE savings account closed by Standard Chartered without any prior notice or communication. Balance Rs 12 lakhs not transferred.")
                .status("escalated").priority("high")
                .filingType("EMAIL").department("CEPC").assignedRole("CEPC_INCHARGE")
                .entityCode("Standard Chartered Bank").workflowStage("ESCALATED")
                .createdAt(now.minusDays(8)).updatedAt(now.minusDays(2)).filedAt(now.minusDays(8))
                .build());

        // ═══ RBIO Complaints ═══
        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260605-200001")
                .complainantName("Ramesh Gupta")
                .complainantEmail("ramesh.g@email.com")
                .complainantPhone("9876600001")
                .subject("SBI ATM swallowed card and debited Rs 20,000")
                .description("SBI ATM at Connaught Place swallowed my card. Amount Rs 20,000 debited but no cash dispensed. Card not returned.")
                .status("assigned").priority("high")
                .filingType("WEB_PORTAL").department("RBIO").assignedRole("RBIO_OFFICER")
                .entityCode("State Bank of India").workflowStage("INITIAL_REVIEW")
                .createdAt(now.minusDays(2)).updatedAt(now.minusDays(2)).filedAt(now.minusDays(2))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260604-200002")
                .complainantName("Pooja Singh")
                .complainantEmail("pooja.s@email.com")
                .complainantPhone("9876600002")
                .subject("PNB wrong NEFT transfer - money sent to wrong account")
                .description("NEFT transfer of Rs 5,00,000 sent to wrong beneficiary account by PNB branch. Bank not helping with reversal.")
                .status("in_progress").priority("high")
                .filingType("WEB_PORTAL").department("RBIO").assignedRole("RBIO_OFFICER").assignedOfficer("rbio.officer1")
                .entityCode("Punjab National Bank").workflowStage("INVESTIGATION")
                .createdAt(now.minusDays(4)).updatedAt(now.minusDays(1)).filedAt(now.minusDays(4))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260603-200003")
                .complainantName("Vijay Nair")
                .complainantEmail("vijay.n@email.com")
                .complainantPhone("9876600003")
                .subject("Canara Bank refusing education loan despite eligibility")
                .description("Applied for education loan for IIT admission. Meet all criteria. Branch manager verbally refused without giving written reason.")
                .status("assigned").priority("medium")
                .filingType("WEB_PORTAL").department("RBIO").assignedRole("RBIO_OFFICER")
                .entityCode("Canara Bank").workflowStage("INITIAL_REVIEW")
                .createdAt(now.minusDays(6)).updatedAt(now.minusDays(6)).filedAt(now.minusDays(6))
                .build());

        // ═══ RBIO Complaints — Mumbai officer (rbio_mum1) queue ═══
        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260606-200004")
                .complainantName("Anjali Deshpande")
                .complainantEmail("anjali.d@email.com")
                .complainantPhone("9876600004")
                .complainantState("Maharashtra").complainantDistrict("Mumbai")
                .subject("HDFC Bank locker rent deducted twice in same month")
                .description("HDFC Bank Fort branch deducted locker rent twice within the same billing cycle. Branch acknowledges error but no refund issued in 3 weeks.")
                .status("assigned").priority("medium")
                .filingType("WEB_PORTAL").department("RBIO").assignedRole("RBIO_OFFICER").assignedOfficer("rbio_mum1")
                .entityCode("HDFC Bank").entityState("Maharashtra").entityDistrict("Mumbai").workflowStage("INITIAL_REVIEW")
                .createdAt(now.minusDays(1)).updatedAt(now.minusDays(1)).filedAt(now.minusDays(1))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260605-200005")
                .complainantName("Rohit Shetty")
                .complainantEmail("rohit.s@email.com")
                .complainantPhone("9876600005")
                .complainantState("Maharashtra").complainantDistrict("Mumbai")
                .subject("ICICI Bank credit card annual fee charged despite waiver offer")
                .description("Card was issued with a lifetime-free offer in writing. ICICI charged Rs 2,500 annual fee anyway. Branch redirects to call centre with no resolution.")
                .status("in_progress").priority("high")
                .filingType("EMAIL").department("RBIO").assignedRole("RBIO_OFFICER").assignedOfficer("rbio_mum1")
                .entityCode("ICICI Bank").entityState("Maharashtra").entityDistrict("Mumbai").workflowStage("INVESTIGATION")
                .createdAt(now.minusDays(3)).updatedAt(now.minusHours(12)).filedAt(now.minusDays(3))
                .build());

        complaintRepo.save(Complaint.builder()
                .complaintNumber("CMP-20260604-200006")
                .complainantName("Sneha Kulkarni")
                .complainantEmail("sneha.k@email.com")
                .complainantPhone("9876600006")
                .complainantState("Maharashtra").complainantDistrict("Thane")
                .subject("Bank of Baroda delaying gold loan disbursement by 2 weeks")
                .description("Gold loan approved on paper 2 weeks ago against pledged jewellery, but disbursement still pending with no clear reason from Thane branch.")
                .status("assigned").priority("low")
                .filingType("WEB_PORTAL").department("RBIO").assignedRole("RBIO_OFFICER").assignedOfficer("rbio_mum1")
                .entityCode("Bank of Baroda").entityState("Maharashtra").entityDistrict("Thane").workflowStage("INITIAL_REVIEW")
                .createdAt(now.minusDays(5)).updatedAt(now.minusDays(5)).filedAt(now.minusDays(5))
                .build());
    }

    private void seedComplaintForm() {
        String schema = """
        {
          "formTitle": "Raise a Complaint",
          "steps": [
            {
              "stepNumber": 1,
              "title": "Tell Us About You",
              "description": "Share some basic details about yourself to help us contact you regarding your complaint.",
              "helpText": "Why are we asking this?",
              "fields": [
                {
                  "key": "complainantCategory",
                  "label": "Complainant Category",
                  "type": "select",
                  "required": true,
                  "fullWidth": true,
                  "options": [
                    {"label": "Individual", "value": "individual"},
                    {"label": "Business", "value": "business"},
                    {"label": "Other", "value": "other"}
                  ]
                },
                {
                  "key": "name",
                  "label": "Name",
                  "type": "text",
                  "required": true,
                  "placeholder": "Enter your full name"
                },
                {
                  "key": "mobileNumber",
                  "label": "Mobile Number",
                  "type": "tel",
                  "required": true,
                  "placeholder": "Enter Mobile Number",
                  "prefix": "+91",
                  "hasVerify": true
                },
                {
                  "key": "email",
                  "label": "Email (Optional)",
                  "type": "email",
                  "required": false,
                  "placeholder": "Enter email address"
                },
                {
                  "key": "pincode",
                  "label": "Pincode",
                  "type": "text",
                  "required": true,
                  "placeholder": "Enter",
                  "maxLength": 6
                },
                {
                  "key": "district",
                  "label": "District",
                  "type": "select",
                  "required": true,
                  "optionsSource": "districts"
                },
                {
                  "key": "state",
                  "label": "State",
                  "type": "select",
                  "required": true,
                  "optionsSource": "states"
                },
                {
                  "key": "address",
                  "label": "Address",
                  "type": "textarea",
                  "required": true,
                  "fullWidth": true,
                  "placeholder": "Enter",
                  "rows": 3
                }
              ]
            },
            {
              "stepNumber": 2,
              "title": "Entity Details",
              "description": "Tell us about the bank or financial institution you want to complain against.",
              "helpText": "Why are we asking this?",
              "fields": [
                {
                  "key": "entityType",
                  "label": "Entity Type",
                  "type": "select",
                  "required": true,
                  "options": [
                    {"label": "Bank", "value": "bank"},
                    {"label": "NBFC", "value": "nbfc"},
                    {"label": "Payment System", "value": "payment"}
                  ]
                },
                {
                  "key": "entityName",
                  "label": "Entity Name",
                  "type": "select",
                  "required": true,
                  "optionsSource": "banks"
                },
                {
                  "key": "branch",
                  "label": "Branch (if applicable)",
                  "type": "text",
                  "required": false,
                  "placeholder": "Enter branch name"
                },
                {
                  "key": "accountNumber",
                  "label": "Account Number (if applicable)",
                  "type": "text",
                  "required": false,
                  "placeholder": "Enter account number"
                }
              ]
            },
            {
              "stepNumber": 3,
              "title": "Final Step: Share Your Complaint",
              "description": "Describe your complaint, actions taken, responses received, and include supporting documents.",
              "helpText": "Why are we asking this?",
              "fields": [
                {
                  "key": "complaintCategory",
                  "label": "Complaint Category",
                  "type": "select",
                  "required": true,
                  "optionsSource": "categories"
                },
                {
                  "key": "subCategory1",
                  "label": "Complaint Sub-Category 1",
                  "type": "select",
                  "required": false,
                  "optionsSource": "subCategories1",
                  "dependsOn": "complaintCategory"
                },
                {
                  "key": "subCategory2",
                  "label": "Complaint Sub-Category 2",
                  "type": "select",
                  "required": false,
                  "optionsSource": "subCategories2",
                  "dependsOn": "subCategory1"
                },
                {
                  "key": "facts",
                  "label": "Facts of the complaint",
                  "type": "textarea",
                  "required": true,
                  "fullWidth": true,
                  "placeholder": "Enter",
                  "rows": 4
                },
                {
                  "key": "isSubJudice",
                  "label": "Is your complaint sub-judice/under arbitration/already dealt with on merits by a Court/Tribunal/Arbitrator/Authority?",
                  "type": "radio",
                  "required": true,
                  "fullWidth": true,
                  "options": [
                    {"label": "Yes", "value": true},
                    {"label": "No", "value": false}
                  ]
                },
                {
                  "key": "throughAdvocate",
                  "label": "Is your complaint made through an advocate (unless you are yourself an advocate)?",
                  "type": "radio",
                  "required": true,
                  "fullWidth": true,
                  "options": [
                    {"label": "Yes", "value": true},
                    {"label": "No", "value": false}
                  ]
                },
                {
                  "key": "alreadyWithOmbudsman",
                  "label": "Has your complaint already been dealt with or is under process on the same ground with the Ombudsman?",
                  "type": "radio",
                  "required": true,
                  "fullWidth": true,
                  "options": [
                    {"label": "Yes", "value": true},
                    {"label": "No", "value": false}
                  ]
                },
                {
                  "key": "regulatedEntityStaff",
                  "label": "Is complaint from the staff of a regulated entity and involves employer employee relationship?",
                  "type": "radio",
                  "required": true,
                  "fullWidth": true,
                  "options": [
                    {"label": "Yes", "value": true},
                    {"label": "No", "value": false}
                  ]
                },
                {
                  "key": "attachments",
                  "label": "Attachments",
                  "type": "file",
                  "required": false,
                  "fullWidth": true,
                  "accept": ".pdf,.jpg,.png",
                  "multiple": true,
                  "maxSize": 5242880,
                  "hint": "Support formats: PDF, JPG, PNG. Maximum size: 5MB"
                },
                {
                  "key": "authorizeRepresentative",
                  "label": "If you want to authorize a representative to appear and make submission on your behalf before the Ombudsman, please select 'Yes' and furnish the details of the Authorized Representative",
                  "type": "radio",
                  "required": false,
                  "fullWidth": true,
                  "options": [
                    {"label": "Yes", "value": true},
                    {"label": "No", "value": false}
                  ]
                }
              ]
            }
          ],
          "preFilingModal": {
            "title": "Before Filing a Complaint",
            "subtitle": "SELECT WHICHEVER IS APPLICABLE",
            "options": [
              {
                "id": "not_contacted",
                "number": 1,
                "title": "I have not contacted my bank or financial institution",
                "description": "Select this option if you have not filed a complaint with your bank or financial institution yet."
              },
              {
                "id": "already_filed",
                "number": 2,
                "title": "I have filed a complaint with bank or financial institution",
                "description": "Select this option if you are not satisfied with the reply provided by your bank or financial institute or if they have not provided a response to your complaint in 30 days.",
                "conditionalFields": [
                  {
                    "key": "bankComplaintDate",
                    "label": "When did you first file the complaint with your bank or financial institution?",
                    "type": "date",
                    "required": true
                  },
                  {
                    "key": "receivedReply",
                    "label": "Have you received any reply from your bank or financial institution?",
                    "type": "radio",
                    "required": true,
                    "options": [
                      {"label": "Yes", "value": "yes"},
                      {"label": "No", "value": "no"}
                    ]
                  }
                ]
              }
            ]
          }
        }
        """;

        formConfigRepo.save(FormConfig.builder()
                .formKey("raise-complaint")
                .formName("Raise a Complaint")
                .schemaJson(schema)
                .active(true)
                .version("1.0")
                .build());
    }

    private void seedCategories() {
        categoryRepo.save(ComplaintCategory.builder().name("ATM / Debit Card").description("Issues related to ATM transactions and debit cards").sortOrder(1).build());
        categoryRepo.save(ComplaintCategory.builder().name("Credit Card").description("Issues related to credit card transactions and billing").sortOrder(2).build());
        categoryRepo.save(ComplaintCategory.builder().name("Internet Banking").description("Issues with online banking services").sortOrder(3).build());
        categoryRepo.save(ComplaintCategory.builder().name("Mobile Banking / UPI").description("Issues with mobile banking apps and UPI transactions").sortOrder(4).build());
        categoryRepo.save(ComplaintCategory.builder().name("Loan / Advances").description("Issues with loan processing, EMI, interest rates").sortOrder(5).build());
        categoryRepo.save(ComplaintCategory.builder().name("Deposit Accounts").description("Issues with savings, current, or fixed deposit accounts").sortOrder(6).build());
        categoryRepo.save(ComplaintCategory.builder().name("Pension").description("Pension related grievances").sortOrder(7).build());
        categoryRepo.save(ComplaintCategory.builder().name("Remittance / Transfer").description("Issues with fund transfers, NEFT, RTGS, IMPS").sortOrder(8).build());
        categoryRepo.save(ComplaintCategory.builder().name("Insurance").description("Insurance related complaints").sortOrder(9).build());
        categoryRepo.save(ComplaintCategory.builder().name("Others").description("Other banking related complaints").sortOrder(10).build());
    }

    private void seedBanks() {
        bankRepo.save(Bank.builder().name("State Bank of India").code("SBI").type("public").build());
        bankRepo.save(Bank.builder().name("Punjab National Bank").code("PNB").type("public").build());
        bankRepo.save(Bank.builder().name("Bank of Baroda").code("BOB").type("public").build());
        bankRepo.save(Bank.builder().name("Canara Bank").code("CANARA").type("public").build());
        bankRepo.save(Bank.builder().name("Union Bank of India").code("UNION").type("public").build());
        bankRepo.save(Bank.builder().name("HDFC Bank").code("HDFC").type("private").build());
        bankRepo.save(Bank.builder().name("ICICI Bank").code("ICICI").type("private").build());
        bankRepo.save(Bank.builder().name("Axis Bank").code("AXIS").type("private").build());
        bankRepo.save(Bank.builder().name("Kotak Mahindra Bank").code("KOTAK").type("private").build());
        bankRepo.save(Bank.builder().name("IndusInd Bank").code("INDUSIND").type("private").build());
        bankRepo.save(Bank.builder().name("Yes Bank").code("YES").type("private").build());
        bankRepo.save(Bank.builder().name("IDBI Bank").code("IDBI").type("public").build());
    }

    private void seedRegulatedEntities() {
        // CEPC entities (from CEPC_English_Portal.pdf — 8,609 entities)
        // Representative sample: NBFCs, Cooperative Banks, Fintech companies, Payment operators
        List<String[]> cepcEntities = List.of(
            new String[]{"Bajaj Finance Limited", "NBFC"},
            new String[]{"Muthoot Finance Ltd", "NBFC"},
            new String[]{"Manappuram Finance Limited", "NBFC"},
            new String[]{"Shriram Finance Limited", "NBFC"},
            new String[]{"Mahindra & Mahindra Financial Services Limited", "NBFC"},
            new String[]{"Tata Capital Financial Services Limited", "NBFC"},
            new String[]{"L&T Finance Limited", "NBFC"},
            new String[]{"Piramal Capital & Housing Finance Limited", "NBFC"},
            new String[]{"HDB Financial Services Limited", "NBFC"},
            new String[]{"Aditya Birla Finance Limited", "NBFC"},
            new String[]{"Fullerton India Credit Company Limited", "NBFC"},
            new String[]{"IIFL Finance Limited", "NBFC"},
            new String[]{"Hero FinCorp Limited", "NBFC"},
            new String[]{"Cholamandalam Investment and Finance Company Limited", "NBFC"},
            new String[]{"Sundaram Finance Limited", "NBFC"},
            new String[]{"Muthoot Fincorp Limited", "NBFC"},
            new String[]{"Ujjivan Financial Services Limited", "NBFC"},
            new String[]{"CreditAccess Grameen Limited", "NBFC"},
            new String[]{"Arohan Financial Services Limited", "NBFC"},
            new String[]{"Satin Creditcare Network Limited", "NBFC"},
            new String[]{"Asirvad Microfinance Limited", "NBFC"},
            new String[]{"Annapurna Finance Private Limited", "NBFC"},
            new String[]{"Fusion Micro Finance Limited", "NBFC"},
            new String[]{"Northern Arc Capital Limited", "NBFC"},
            new String[]{"Five Star Business Finance Limited", "NBFC"},
            new String[]{"Home First Finance Company India Limited", "NBFC"},
            new String[]{"Aptus Value Housing Finance India Limited", "NBFC"},
            new String[]{"AAVAS Financiers Limited", "NBFC"},
            new String[]{"Can Fin Homes Limited", "NBFC"},
            new String[]{"India Shelter Finance Corporation Limited", "NBFC"},
            new String[]{"PNB Housing Finance Limited", "NBFC"},
            new String[]{"LIC Housing Finance Limited", "NBFC"},
            new String[]{"HDFC Credila Financial Services Limited", "NBFC"},
            new String[]{"Indiabulls Housing Finance Limited", "NBFC"},
            new String[]{"Repco Home Finance Limited", "NBFC"},
            new String[]{"Saraswat Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Cosmos Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Shamrao Vithal Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Bharat Co-operative Bank (Mumbai) Limited", "Cooperative Bank"},
            new String[]{"TJSB Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Bassein Catholic Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Citizen Credit Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Abhyudaya Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Apna Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Janata Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"New India Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Nutan Nagarik Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Kalupur Commercial Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Mehsana Urban Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Rajkot Nagrik Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Surat People's Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Ahmednagar Merchants Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Sangli Urban Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"Rajarambapu Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Dombivli Nagari Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Thane Bharat Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"GP Parsik Sahakari Bank Limited", "Cooperative Bank"},
            new String[]{"Maharashtra State Co-operative Bank Limited", "Cooperative Bank"},
            new String[]{"The AP Mahesh Co-operative Urban Bank Limited", "Cooperative Bank"},
            new String[]{"PhonePe Private Limited", "Payment System Operator"},
            new String[]{"Google Pay (Google India Digital Services)", "Payment System Operator"},
            new String[]{"Paytm Payments Bank Limited", "Payment System Operator"},
            new String[]{"Amazon Pay (India) Private Limited", "Payment System Operator"},
            new String[]{"BharatPe (Resilient Innovations Private Limited)", "Payment System Operator"},
            new String[]{"MobiKwik Systems Limited", "Payment System Operator"},
            new String[]{"Freecharge Payment Technologies Private Limited", "Payment System Operator"},
            new String[]{"Razorpay Software Private Limited", "Payment System Operator"},
            new String[]{"PayU Payments Private Limited", "Payment System Operator"},
            new String[]{"Pine Labs Private Limited", "Payment System Operator"},
            new String[]{"Slice (Quadrillion Finance Private Limited)", "Payment System Operator"},
            new String[]{"Jupiter Money (Amica Financial Technologies)", "Payment System Operator"},
            new String[]{"CRED (Dreamplug Technologies Private Limited)", "Payment System Operator"},
            new String[]{"Navi Finserv Limited", "NBFC"},
            new String[]{"Poonawalla Fincorp Limited", "NBFC"},
            new String[]{"JM Financial Products Limited", "NBFC"},
            new String[]{"Reliance Commercial Finance Limited", "NBFC"},
            new String[]{"SMFG India Credit Company Limited", "NBFC"},
            new String[]{"Deutsche Bank AG", "Foreign Bank"},
            new String[]{"Standard Chartered Bank", "Foreign Bank"},
            new String[]{"Citibank N.A.", "Foreign Bank"},
            new String[]{"HSBC Limited", "Foreign Bank"},
            new String[]{"Barclays Bank PLC", "Foreign Bank"},
            new String[]{"DBS Bank India Limited", "Foreign Bank"},
            new String[]{"Bank of America", "Foreign Bank"},
            new String[]{"JP Morgan Chase Bank N.A.", "Foreign Bank"},
            new String[]{"BNP Paribas", "Foreign Bank"}
        );

        // RBIO entities (from RBIO_English_Portal.pdf — 3,080 entities)
        // Scheduled Commercial Banks (Public Sector, Private Sector, SFBs, Payment Banks)
        List<String[]> rbioEntities = List.of(
            new String[]{"State Bank of India", "Public Sector Bank"},
            new String[]{"Punjab National Bank", "Public Sector Bank"},
            new String[]{"Bank of Baroda", "Public Sector Bank"},
            new String[]{"Canara Bank", "Public Sector Bank"},
            new String[]{"Union Bank of India", "Public Sector Bank"},
            new String[]{"Bank of India", "Public Sector Bank"},
            new String[]{"Indian Bank", "Public Sector Bank"},
            new String[]{"Central Bank of India", "Public Sector Bank"},
            new String[]{"Indian Overseas Bank", "Public Sector Bank"},
            new String[]{"UCO Bank", "Public Sector Bank"},
            new String[]{"Bank of Maharashtra", "Public Sector Bank"},
            new String[]{"Punjab & Sind Bank", "Public Sector Bank"},
            new String[]{"IDBI Bank Limited", "Public Sector Bank"},
            new String[]{"HDFC Bank Limited", "Private Sector Bank"},
            new String[]{"ICICI Bank Limited", "Private Sector Bank"},
            new String[]{"Axis Bank Limited", "Private Sector Bank"},
            new String[]{"Kotak Mahindra Bank Limited", "Private Sector Bank"},
            new String[]{"IndusInd Bank Limited", "Private Sector Bank"},
            new String[]{"Yes Bank Limited", "Private Sector Bank"},
            new String[]{"IDFC First Bank Limited", "Private Sector Bank"},
            new String[]{"Bandhan Bank Limited", "Private Sector Bank"},
            new String[]{"Federal Bank Limited", "Private Sector Bank"},
            new String[]{"RBL Bank Limited", "Private Sector Bank"},
            new String[]{"South Indian Bank Limited", "Private Sector Bank"},
            new String[]{"City Union Bank Limited", "Private Sector Bank"},
            new String[]{"Karur Vysya Bank Limited", "Private Sector Bank"},
            new String[]{"Tamilnad Mercantile Bank Limited", "Private Sector Bank"},
            new String[]{"DCB Bank Limited", "Private Sector Bank"},
            new String[]{"Dhanlaxmi Bank Limited", "Private Sector Bank"},
            new String[]{"CSB Bank Limited", "Private Sector Bank"},
            new String[]{"Nainital Bank Limited", "Private Sector Bank"},
            new String[]{"Jammu & Kashmir Bank Limited", "Private Sector Bank"},
            new String[]{"Karnataka Bank Limited", "Private Sector Bank"},
            new String[]{"Lakshmi Vilas Bank Limited", "Private Sector Bank"},
            new String[]{"Au Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Equitas Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Ujjivan Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Jana Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Suryoday Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Fincare Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"ESAF Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"North East Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Capital Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Unity Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Shivalik Small Finance Bank Limited", "Small Finance Bank"},
            new String[]{"Airtel Payments Bank Limited", "Payments Bank"},
            new String[]{"India Post Payments Bank Limited", "Payments Bank"},
            new String[]{"Fino Payments Bank Limited", "Payments Bank"},
            new String[]{"Jio Payments Bank Limited", "Payments Bank"},
            new String[]{"NSDL Payments Bank Limited", "Payments Bank"},
            new String[]{"National Payments Corporation of India", "Payment Infrastructure"},
            new String[]{"Clearing Corporation of India Limited", "Payment Infrastructure"},
            new String[]{"HDFC Bank", "Private Sector Bank"},
            new String[]{"ICICI Bank", "Private Sector Bank"},
            new String[]{"Axis Bank", "Private Sector Bank"},
            new String[]{"Kotak Mahindra Bank", "Private Sector Bank"},
            new String[]{"SBI", "Public Sector Bank"},
            new String[]{"PNB", "Public Sector Bank"},
            new String[]{"BOB", "Public Sector Bank"}
        );

        for (String[] e : cepcEntities) {
            regulatedEntityRepo.save(RegulatedEntity.builder()
                    .name(e[0])
                    .nameNormalized(RegulatedEntity.normalize(e[0]))
                    .department("CEPC")
                    .entityType(e[1])
                    .build());
        }

        for (String[] e : rbioEntities) {
            regulatedEntityRepo.save(RegulatedEntity.builder()
                    .name(e[0])
                    .nameNormalized(RegulatedEntity.normalize(e[0]))
                    .department("RBIO")
                    .entityType(e[1])
                    .build());
        }
    }

    private void seedExtractionRules() {
        List<ExtractionRule> rules = List.of(
            ExtractionRule.builder().ruleName("Phone Number").ruleCode("PHONE_REGEX").patternType("REGEX")
                .pattern("(?:mobile|phone|contact|mob|cell)[:\\s]*([6-9]\\d{9})").targetField("complainantPhone")
                .extractGroup(1).priority(10).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Phone Fallback").ruleCode("PHONE_FALLBACK_REGEX").patternType("REGEX")
                .pattern("\\b([6-9]\\d{9})\\b").targetField("complainantPhone")
                .extractGroup(1).priority(11).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Email Address").ruleCode("EMAIL_REGEX").patternType("REGEX")
                .pattern("(?:email|e-mail|mail)[:\\s]*([a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,})").targetField("complainantEmail")
                .extractGroup(1).priority(20).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Pincode").ruleCode("PINCODE_REGEX").patternType("REGEX")
                .pattern("(?:pin\\s*code|pincode|pin)[:\\s]*(\\d{6})").targetField("complainantPincode")
                .extractGroup(1).priority(30).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Pincode Fallback").ruleCode("PINCODE_FALLBACK_REGEX").patternType("REGEX")
                .pattern("\\b(\\d{6})\\b").targetField("complainantPincode")
                .extractGroup(1).priority(31).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Name").ruleCode("NAME_REGEX").patternType("REGEX")
                .pattern("(?:name|complainant|from)[:\\s]*([A-Z][a-zA-Z]+(?:\\s[A-Z][a-zA-Z]+){1,3})").targetField("complainantName")
                .extractGroup(1).priority(40).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Amount").ruleCode("AMOUNT_REGEX").patternType("REGEX")
                .pattern("(?:amount|rs|inr|₹)[.\\s:]*([0-9,]+(?:\\.\\d{1,2})?)").targetField("amountInvolved")
                .extractGroup(1).priority(50).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("CPGRAMS Number").ruleCode("CPGRAMS_REGEX").patternType("REGEX")
                .pattern("(?:CPGRAMS|cpgrams|CPGRM)[:\\s#]*([A-Z0-9/\\-]+)").targetField("cpgramsNumber")
                .extractGroup(1).transform("UPPERCASE").priority(55).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Entity Name - Bank").ruleCode("ENTITY_BANK_KW").patternType("KEYWORD_LIST")
                .pattern("HDFC Bank,ICICI Bank,State Bank of India,SBI,Axis Bank,Kotak Mahindra Bank,Punjab National Bank,PNB,Bank of Baroda,Canara Bank,Union Bank,Indian Bank,Bank of India,IDBI Bank,Yes Bank,IndusInd Bank,Federal Bank,RBL Bank,Bandhan Bank")
                .targetField("entityName").priority(60).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Category - Credit Card").ruleCode("CAT_CC_KW").patternType("KEYWORD_LIST")
                .pattern("credit card,credit-card,creditcard,card statement,card charge,annual fee,card limit,EMI conversion")
                .targetField("category").priority(70).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Category - Loan").ruleCode("CAT_LOAN_KW").patternType("KEYWORD_LIST")
                .pattern("home loan,personal loan,car loan,education loan,loan account,EMI,loan closure,foreclosure,prepayment")
                .targetField("category").priority(71).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Category - ATM").ruleCode("CAT_ATM_KW").patternType("KEYWORD_LIST")
                .pattern("ATM,cash not dispensed,ATM transaction,debit without dispensing,ATM withdrawal")
                .targetField("category").priority(72).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("State").ruleCode("STATE_KW").patternType("KEYWORD_LIST")
                .pattern("Maharashtra,Karnataka,Tamil Nadu,Delhi,Uttar Pradesh,Gujarat,Rajasthan,West Bengal,Madhya Pradesh,Kerala,Andhra Pradesh,Telangana,Bihar,Punjab,Haryana,Odisha,Assam,Jharkhand,Chhattisgarh,Uttarakhand,Goa")
                .targetField("complainantState").priority(80).isActive(true).sourceScope("BOTH").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Address").ruleCode("ADDRESS_REGEX").patternType("REGEX")
                .pattern("(?:address|residing at|resident of)[:\\s]*(.{10,150}?)(?:\\.|$)").targetField("complainantAddress")
                .extractGroup(1).transform("TRIM").priority(90).isActive(true).sourceScope("BODY").createdBy("system").build(),
            ExtractionRule.builder().ruleName("Date").ruleCode("DATE_REGEX").patternType("REGEX")
                .pattern("(?:dated?|on)[:\\s]*(\\d{1,2}[/\\-]\\d{1,2}[/\\-]\\d{2,4})").targetField("letterDate")
                .extractGroup(1).priority(100).isActive(true).sourceScope("BOTH").createdBy("system").build()
        );
        extractionRuleRepo.saveAll(rules);
    }

    private void seedAccountTypes() {
        accountTypeRepo.saveAll(List.of(
            AccountTypeMaster.builder().label("Savings Account").value("savings").active(true).sortOrder(1).build(),
            AccountTypeMaster.builder().label("Current Account").value("current").active(true).sortOrder(2).build(),
            AccountTypeMaster.builder().label("Loan Account").value("loan").active(true).sortOrder(3).build(),
            AccountTypeMaster.builder().label("Fixed Deposit").value("fixed_deposit").active(true).sortOrder(4).build(),
            AccountTypeMaster.builder().label("Recurring Deposit").value("recurring_deposit").active(true).sortOrder(5).build(),
            AccountTypeMaster.builder().label("ATM / Debit Card").value("atm_debit").active(true).sortOrder(6).build(),
            AccountTypeMaster.builder().label("Credit Card").value("credit_card").active(true).sortOrder(7).build(),
            AccountTypeMaster.builder().label("Wallet").value("wallet").active(true).sortOrder(8).build(),
            AccountTypeMaster.builder().label("PPF Account").value("ppf").active(true).sortOrder(9).build(),
            AccountTypeMaster.builder().label("Others").value("others").active(true).sortOrder(10).build()
        ));
    }

    private void seedOmbudsmanOfficeMaster() {
        ombudsmanOfficeRepo.saveAll(List.of(
            OmbudsmanOfficeMaster.builder().id(1).officeName("Ahmedabad").jurisdiction("Gujarat, Union Territories of Dadra and Nagar Haveli, Daman and Diu").build(),
            OmbudsmanOfficeMaster.builder().id(2).officeName("Bengaluru").jurisdiction("Karnataka").build(),
            OmbudsmanOfficeMaster.builder().id(3).officeName("Bhopal").jurisdiction("Madhya Pradesh").build(),
            OmbudsmanOfficeMaster.builder().id(4).officeName("Bhubaneswar").jurisdiction("Odisha").build(),
            OmbudsmanOfficeMaster.builder().id(5).officeName("Chandigarh").jurisdiction("Punjab and Union Territory of Chandigarh").build(),
            OmbudsmanOfficeMaster.builder().id(6).officeName("Chennai-I").jurisdiction("Nine districts of Tamil Nadu viz., Thiruvallur, Chennai, Vellore, Ranipet, Kancheepuram, Chengalpattu, Krishnagiri, Tirupathur and Tiruvannamalai; and Union Territory of Andaman and Nicobar Islands").build(),
            OmbudsmanOfficeMaster.builder().id(7).officeName("Chennai-II").jurisdiction("Tamil Nadu (excluding Districts of Thiruvallur, Chennai, Vellore, Ranipet, Kancheepuram, Chengalpattu, Krishnagiri, Tirupathur and Tiruvannamalai); and Union Territory of Puducherry (except Mahe Region)").build(),
            OmbudsmanOfficeMaster.builder().id(8).officeName("Dehradun").jurisdiction("Uttarakhand and seven districts of Uttar Pradesh viz., Saharanpur, Shamli (Prabudh Nagar), Muzaffarnagar, Baghpat, Meerut, Bijnor and Amroha (Jyotiba Phule Nagar)").build(),
            OmbudsmanOfficeMaster.builder().id(9).officeName("Guwahati").jurisdiction("Assam, Arunachal Pradesh, Manipur, Meghalaya, Mizoram, Nagaland and Tripura").build(),
            OmbudsmanOfficeMaster.builder().id(10).officeName("Hyderabad").jurisdiction("Andhra Pradesh and Telangana").build(),
            OmbudsmanOfficeMaster.builder().id(11).officeName("Jaipur").jurisdiction("Rajasthan").build(),
            OmbudsmanOfficeMaster.builder().id(12).officeName("Jammu").jurisdiction("Union Territories of Jammu & Kashmir and Ladakh").build(),
            OmbudsmanOfficeMaster.builder().id(13).officeName("Kanpur").jurisdiction("Uttar Pradesh (excluding Districts of Ghaziabad, Gautam Buddha Nagar, Saharanpur, Shamli (Prabudh Nagar), Muzaffarnagar, Baghpat, Meerut, Bijnor and Amroha (Jyotiba Phule Nagar))").build(),
            OmbudsmanOfficeMaster.builder().id(14).officeName("Kolkata-I").jurisdiction("Three districts of West Bengal viz., Kolkata, South 24 Parganas, Howrah; and Sikkim").build(),
            OmbudsmanOfficeMaster.builder().id(15).officeName("Kolkata-II").jurisdiction("West Bengal (excluding districts of Kolkata, South 24 Parganas and Howrah)").build(),
            OmbudsmanOfficeMaster.builder().id(16).officeName("Mumbai-I").jurisdiction("Districts of Mumbai, Mumbai Suburban and Thane").build(),
            OmbudsmanOfficeMaster.builder().id(17).officeName("Mumbai-II").jurisdiction("Goa and Maharashtra (except the districts of Mumbai, Mumbai Suburban and Thane)").build(),
            OmbudsmanOfficeMaster.builder().id(18).officeName("New Delhi-I").jurisdiction("Delhi").build(),
            OmbudsmanOfficeMaster.builder().id(19).officeName("New Delhi-II").jurisdiction("Haryana and Ghaziabad and Gautam Buddha Nagar districts of Uttar Pradesh").build(),
            OmbudsmanOfficeMaster.builder().id(20).officeName("Patna").jurisdiction("Bihar").build(),
            OmbudsmanOfficeMaster.builder().id(21).officeName("Raipur").jurisdiction("Chhattisgarh").build(),
            OmbudsmanOfficeMaster.builder().id(22).officeName("Ranchi").jurisdiction("Jharkhand").build(),
            OmbudsmanOfficeMaster.builder().id(23).officeName("Shimla").jurisdiction("Himachal Pradesh").build(),
            OmbudsmanOfficeMaster.builder().id(24).officeName("Thiruvananthapuram").jurisdiction("Kerala, Union Territory of Lakshadweep and Union Territory of Puducherry (only Mahe Region)").build()
        ));
    }

    private void seedOfficeCodeMaster() {
        officeCodeRepo.saveAll(List.of(
            OfficeCodeMaster.builder().officeType("BO").officeName("Ahmedabad").officeCode("001").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Bengaluru").officeCode("002").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Bhubaneswar").officeCode("003").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Bhopal").officeCode("004").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Kolkata-I").officeCode("005").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Chennai-I").officeCode("006").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Chandigarh").officeCode("007").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Guwahati").officeCode("008").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Hyderabad").officeCode("009").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Jaipur").officeCode("010").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Kanpur").officeCode("011").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Patna").officeCode("012").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Mumbai-I").officeCode("013").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("New Delhi-I").officeCode("014").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Thiruvananthapuram").officeCode("015").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("New Delhi-II").officeCode("016").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Dehradun").officeCode("017").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Ranchi").officeCode("018").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Raipur").officeCode("019").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Jammu").officeCode("020").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Mumbai-II").officeCode("021").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Kolkata-II").officeCode("022").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("New Delhi-III").officeCode("023").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Chennai-II").officeCode("024").build(),
            OfficeCodeMaster.builder().officeType("BO").officeName("Shimla").officeCode("025").build()
        ));
    }
}
