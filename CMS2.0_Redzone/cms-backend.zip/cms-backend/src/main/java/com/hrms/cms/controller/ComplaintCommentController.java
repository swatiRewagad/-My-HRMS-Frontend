package com.hrms.cms.controller;

import com.hrms.cms.entity.ComplaintComment;
import com.hrms.cms.repository.ComplaintCommentRepository;
import com.hrms.cms.repository.ComplaintRepository;
import com.hrms.cms.repository.NodalOfficerRecordRepository;
import com.hrms.cms.security.CepcIdentityResolver;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Officer notes on a complaint and on its Nodal Officer Records — the comment threads in the assessment,
 * approval and Contact Entity tabs.
 *
 * <p>Two threads, one store; see {@link ComplaintComment} for how they are told apart.
 */
@RestController
@RequestMapping("/api/v1/complaints")
@RequiredArgsConstructor
public class ComplaintCommentController {

    /** The COMPLAINT_COMMENTS.text column width. Checked here so an over-long note is a 400, not a 500. */
    private static final int MAX_TEXT = 2000;

    private final ComplaintCommentRepository commentRepository;
    private final ComplaintRepository complaintRepository;
    private final NodalOfficerRecordRepository nodalOfficerRecordRepository;
    private final CepcIdentityResolver identity;

    @GetMapping("/{complaintNumber}/comments")
    public ResponseEntity<Map<String, Object>> getComments(@PathVariable String complaintNumber) {
        List<Map<String, Object>> items =
                commentRepository.findByComplaintNumberAndNoRecordNumberIsNullOrderByCreatedAtAsc(complaintNumber)
                        .stream().map(ComplaintCommentController::view).toList();
        return ResponseEntity.ok(body(true, "OK", items));
    }

    @PostMapping("/{complaintNumber}/comments")
    public ResponseEntity<Map<String, Object>> addComment(@PathVariable String complaintNumber,
                                                          @RequestBody Map<String, String> request) {
        String text = trimmed(request.get("text"));
        if (text.isEmpty()) {
            return ResponseEntity.badRequest().body(body(false, "A comment cannot be empty", null));
        }
        if (text.length() > MAX_TEXT) {
            return ResponseEntity.badRequest()
                    .body(body(false, "A comment may be at most " + MAX_TEXT + " characters", null));
        }
        if (complaintRepository.findByComplaintNumber(complaintNumber).isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(body(false, "Complaint not found: " + complaintNumber, null));
        }

        ComplaintComment comment = commentRepository.save(ComplaintComment.builder()
                .complaintNumber(complaintNumber)
                .author(authorName(request))
                .authorUserId(identity.resolveActor())
                .initials(trimmed(request.get("initials")))
                .text(text)
                .role(trimmed(request.get("role")))
                .color(request.get("color"))
                .build());

        return ResponseEntity.status(HttpStatus.CREATED).body(body(true, "Comment added", view(comment)));
    }

    @GetMapping("/nodal-records/{recordNumber}/comments")
    public ResponseEntity<Map<String, Object>> getNodalRecordComments(@PathVariable String recordNumber) {
        List<Map<String, Object>> items = commentRepository.findByNoRecordNumberOrderByCreatedAtDesc(recordNumber)
                .stream().map(ComplaintCommentController::view).toList();
        return ResponseEntity.ok(body(true, "OK", items));
    }

    @PostMapping("/nodal-records/{recordNumber}/comments")
    public ResponseEntity<Map<String, Object>> addNodalRecordComment(@PathVariable String recordNumber,
                                                                     @RequestBody Map<String, String> request) {
        String text = trimmed(request.get("text"));
        if (text.isEmpty()) {
            return ResponseEntity.badRequest().body(body(false, "A comment cannot be empty", null));
        }
        if (text.length() > MAX_TEXT) {
            return ResponseEntity.badRequest()
                    .body(body(false, "A comment may be at most " + MAX_TEXT + " characters", null));
        }

        String target = trimmed(request.get("target")).toUpperCase();
        if (target.isEmpty()) {
            target = "NO";
        }
        if (!"NO".equals(target) && !"PNO".equals(target)) {
            return ResponseEntity.badRequest().body(body(false, "target must be NO or PNO", null));
        }

        // The record is the authority for which complaint this note belongs to. The client sends a
        // complaintNumber too, but taking it on trust would let a note be filed against a record under
        // one complaint while appearing in another complaint's history.
        String complaintNumber = nodalOfficerRecordRepository.findByRecordNumber(recordNumber)
                .map(r -> r.getComplaintNumber())
                .orElse(null);
        if (complaintNumber == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(body(false, "Nodal officer record not found: " + recordNumber, null));
        }

        ComplaintComment comment = commentRepository.save(ComplaintComment.builder()
                .noRecordNumber(recordNumber)
                .complaintNumber(complaintNumber)
                .author(authorName(request))
                .authorUserId(identity.resolveActor())
                .initials(trimmed(request.get("initials")))
                .text(text)
                .target(target)
                .color(request.get("color"))
                .build());

        return ResponseEntity.status(HttpStatus.CREATED).body(body(true, "Comment added", view(comment)));
    }

    /**
     * Both thread shapes in one projection.
     *
     * <p>{@code role} and {@code target} are each meaningful on only one of the two threads, and the
     * screen reads whichever it needs; carrying both costs nothing and avoids two near-identical mappers.
     */
    private static Map<String, Object> view(ComplaintComment c) {
        Map<String, Object> item = new LinkedHashMap<>();
        item.put("id", c.getId());
        item.put("author", c.getAuthor());
        item.put("initials", c.getInitials());
        item.put("text", c.getText());
        item.put("role", c.getRole());
        item.put("target", c.getTarget());
        item.put("color", c.getColor());
        item.put("createdAt", c.getCreatedAt() != null ? c.getCreatedAt().toString() : "");
        return item;
    }

    /** The display name to show, preferring what the client sent and falling back to the resolved user. */
    private String authorName(Map<String, String> request) {
        String supplied = trimmed(request.get("author"));
        if (!supplied.isEmpty() && !"Unknown".equalsIgnoreCase(supplied)) {
            return supplied;
        }
        String actor = identity.resolveActor();
        return actor != null && !actor.isBlank() ? actor : "Unknown";
    }

    private static String trimmed(String value) {
        return value == null ? "" : value.trim();
    }

    private static Map<String, Object> body(boolean success, String message, Object data) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("success", success);
        out.put("message", message);
        out.put("data", data);
        out.put("timestamp", LocalDateTime.now().toString());
        return out;
    }
}
