package com.hrms.cms.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;

/**
 * A free-text note an officer leaves on a complaint, or on one of its Nodal Officer Records.
 *
 * <p>One table serves both because they are the same act with a different addressee, and the assessment
 * screen shows them in the same visual style. The two are told apart by {@link #noRecordNumber}: null
 * means the note is on the complaint, non-null means it is on that record, and {@link #target} then says
 * whether it was addressed to the Nodal Officer or the Principal Nodal Officer.
 */
@Entity
@Table(name = "COMPLAINT_COMMENTS", indexes = {
        @Index(name = "idx_comment_complaint", columnList = "complaintNumber"),
        @Index(name = "idx_comment_no_record", columnList = "noRecordNumber")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ComplaintComment {

    /** The colour used when the caller does not choose one. Matches the assessment tab's own default. */
    public static final String DEFAULT_COLOR = "#6366f1";

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String complaintNumber;

    /** The display name shown on the note. Supplied by the client, so it is presentation only. */
    @Column(nullable = false, length = 100)
    private String author;

    /**
     * Who actually posted it, resolved from the token rather than the request body.
     *
     * <p>{@link #author} is whatever the client sent, so on its own it is forgeable: an officer could
     * post a note under a colleague's name. This column is the attributable one, and is what any later
     * audit or "delete your own comment" rule must key on.
     */
    @Column(length = 100)
    private String authorUserId;

    @Column(length = 10)
    private String initials;

    @Column(nullable = false, length = 2000)
    private String text;

    @Column(length = 50)
    private String role;

    @Column(length = 10)
    private String color;

    /** Set only on a Nodal Officer Record comment; null on a comment against the complaint itself. */
    @Column(length = 50)
    private String noRecordNumber;

    /** "NO" or "PNO" — who the note was addressed to. Only meaningful with {@link #noRecordNumber}. */
    @Column(length = 10)
    private String target;

    @Column
    private LocalDateTime createdAt;

    /**
     * Assigns only what is still absent, so a seeded or imported comment keeps its own timestamp.
     * An unconditional assignment here would flatten every backdated comment to the moment of import
     * and make the thread's ordering meaningless.
     */
    @PrePersist
    protected void onCreate() {
        if (createdAt == null) {
            createdAt = LocalDateTime.now();
        }
        if (color == null || color.isBlank()) {
            color = DEFAULT_COLOR;
        }
    }
}
