package com.hrms.cms.repository;

import com.hrms.cms.entity.ComplaintComment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ComplaintCommentRepository extends JpaRepository<ComplaintComment, Long> {

    /**
     * The complaint's own comment thread, oldest first.
     *
     * <p>{@code noRecordNumber IS NULL} is what keeps the two threads apart. A Nodal Officer Record
     * comment also carries the complaint number (it is stored so the record's notes can be found from
     * the complaint), so without this clause every NO/PNO note would also surface in the assessment
     * tab's thread, addressed to somebody the reader cannot see.
     *
     * <p>Ascending because the assessment tab renders the array in order and appends each newly posted
     * comment to the end; returning newest-first would make the thread re-order itself the moment the
     * officer posts.
     */
    List<ComplaintComment> findByComplaintNumberAndNoRecordNumberIsNullOrderByCreatedAtAsc(String complaintNumber);

    /**
     * Same thread as above, newest first, for the {@code /comments} listing endpoint, which renders
     * most-recent-first rather than appending.
     *
     * <p>Carries the same {@code noRecordNumber IS NULL} clause for the same reason, and not merely for
     * symmetry: that endpoint is reachable by the complainant, so dropping the clause would publish
     * every NO/PNO note on the complaint to them.
     */
    List<ComplaintComment> findByComplaintNumberAndNoRecordNumberIsNullOrderByCreatedAtDesc(String complaintNumber);

    /** A record's NO/PNO notes, newest first — the nodal detail view prepends each new post. */
    List<ComplaintComment> findByNoRecordNumberOrderByCreatedAtDesc(String noRecordNumber);
}
