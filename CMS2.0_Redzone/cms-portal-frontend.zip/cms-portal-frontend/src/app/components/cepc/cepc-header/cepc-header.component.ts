import { Component, ElementRef, inject, OnInit, signal, computed } from '@angular/core';
import { ButtonModule } from 'primeng/button';
import { AvatarModule } from 'primeng/avatar';
import { PopoverModule } from 'primeng/popover';

import { KeycloakAuthService } from '../../../services/keycloak-auth.service';
import { CepcContextService } from '../../../services/cepc-context.service';
import { NotificationBellComponent } from '../../../shared/notification-bell/notification-bell.component';
import { LanguageSelectComponent } from '../../../shared/language-select/language-select.component';
import { FontSizeControlsComponent } from '../../../shared/font-size-controls/font-size-controls.component';

@Component({
  selector: 'app-cepc-header',
  standalone: true,
  imports: [
    ButtonModule,
    AvatarModule,
    PopoverModule,
    NotificationBellComponent,
    LanguageSelectComponent,
    FontSizeControlsComponent
  ],
  templateUrl: './cepc-header.component.html',
  styleUrl: './cepc-header.component.scss',
})
export class CepcHeaderComponent implements OnInit {
  private auth = inject(KeycloakAuthService);
  private host = inject<ElementRef<HTMLElement>>(ElementRef);
  readonly dept = inject(CepcContextService);

  currentUser = this.auth.currentUser;
  isDarkMode = signal<boolean>(false);

  userInitial = computed(() => {
    const user = this.currentUser();
    return user?.firstName ? user.firstName.charAt(0).toUpperCase() : '?';
  });

  displayName = computed(() => {
    const user = this.currentUser();
    if (!user) return '';
    return `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username;
  });

  displayRole = computed(() => {
    if (!this.currentUser()) return '';
    return this.dept.primaryRole();
  });

  /**
   * The CEPC subtree root. Dark mode toggles here rather than on documentElement so it cannot
   * repaint the rest of the portal, which has its own `body.high-contrast` accessibility theme.
   */
  private darkModeRoot(): HTMLElement | null {
    return this.host.nativeElement.closest('.cepc-scope');
  }

  ngOnInit(): void {
    this.isDarkMode.set(this.darkModeRoot()?.classList.contains('cepc-dark') ?? false);
  }

  toggleDarkMode(): void {
    const nextDarkState = !this.isDarkMode();
    this.darkModeRoot()?.classList.toggle('cepc-dark', nextDarkState);
    this.isDarkMode.set(nextDarkState);
  }

  logout(): void {
    this.auth.logout();
  }
}
