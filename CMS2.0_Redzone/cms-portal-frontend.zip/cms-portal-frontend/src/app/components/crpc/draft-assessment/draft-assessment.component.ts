import { Component, OnInit, OnDestroy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { CrpcService } from '../../../services/crpc.service';
import { KeycloakAuthService } from '../../../services/keycloak-auth.service';
import { ReviewerUser } from '../../../models/crpc.model';
import { environment } from '../../../../environments/environment';
import { SpeechButtonComponent } from '../../../shared/speech-button/speech-button.component';
import { AutoClosureComponent } from '../auto-closure/auto-closure.component';
import { highlightEmailText, escapeHtml } from '../../../utils/highlight-text.util';

interface MaintainabilityQuestion {
  id: string;
  question: string;
  answer: 'YES' | 'NO' | 'NA' | null;
  weight: number;
}

interface Attachment {
  id: string;
  name: string;
  size: string;
  type: string;
  uploadedAt: string;
  uploadedBy: string;
  url?: string;
}

interface EmailCorrespondence {
  id: string;
  direction: 'SENT' | 'RECEIVED';
  subject: string;
  to: string;
  sentAt: string;
  body: string;
}

@Component({
  selector: 'app-draft-assessment',
  standalone: true,
  imports: [CommonModule, FormsModule, SpeechButtonComponent, AutoClosureComponent],
  templateUrl: './draft-assessment.component.html',
  styleUrl: './draft-assessment.component.scss'
})
export class DraftAssessmentComponent implements OnInit, OnDestroy {

  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private crpcService = inject(CrpcService);
  private auth = inject(KeycloakAuthService);
  private http = inject(HttpClient);
  private sanitizer = inject(DomSanitizer);

  // ─── View Mode ───
  editMode = signal(false);
  activeStep = signal<'creation' | 'assignment'>('creation');
  showAiWarning = true;

  // Auto-Closure (new question engine)
  showAutoClosureEngine = signal(false);
  autoClosureCompleted = signal(false);
  autoClosureOutcome = signal('');
  autoClosureSubJudice = signal(false);
  autoClosureClauseRef = signal('');
  autoClosureResponses = signal<any[]>([]);
  schemeVersion = 'RBIOS_2026';

  // ─── PDF Preview (Physical Letter) ───
  pdfPreviewUrl = signal<SafeResourceUrl | null>(null);
  pdfExpanded = signal(false);

  // ─── Suggestions (AI-extracted) ───
  suggestions = signal<{ field: string; value: string; applied: boolean }[]>([]);
  showSuggestionsPanel = signal(false);
  selectedSuggestionIdx = signal<number>(0);

  // ─── Confirmation Dialog ───
  showConfirmDialog = signal(false);
  confirmAssignmentMode = 'Automatic';
  selectedReviewerName = 'CRPC Reviewer';

  // ─── Blob URL cache: maps attachment id → safe blob URL (avoids X-Frame-Options block) ───
  private blobUrlCache = new Map<string, string>();
  attachmentBlobUrls = signal<Record<string, SafeResourceUrl>>({});

  // ─── Attachments Side Panel ───
  showAttachmentsPanel = signal(false);
  viewingAttachment = signal<Attachment | null>(null);
  pdfCurrentPage = signal(1);
  pdfTotalPages = signal(5);

  // ─── Email Communication Tab ───
  emailSections = { open: true, drafts: true, closed: false };
  selectedEmail = signal<EmailCorrespondence | null>(null);

  // ─── History Panel ───
  showHistoryPanel = signal(false);
  showSimilarPanel = signal(false);
  historyEntries = signal<any[]>([]);
  loadingHistory = signal(false);

  // ─── Assignment Mode ───
  assignmentMode = 'Manual';

  // ─── Panel Expand/Collapse ───
  expandedPanel = signal<'email' | 'complaint' | ''>('');

  toggleExpand(panel: 'email' | 'complaint') {
    this.expandedPanel.set(this.expandedPanel() === panel ? '' : panel);
  }

  // ─── Email Highlight on Field Focus ───
  focusedFieldValue = signal<string>('');
  emailBodyHtml = signal<string>('');
  emailSubjectHtml = signal<string>('');
  emailSenderHtml = signal<string>('');

  isEmailMode(): boolean {
    return (this.modeOfReceipt || '').toUpperCase() === 'EMAIL';
  }

  onFieldFocus(fieldValue: string | undefined | null) {
    if (!this.isEmailMode()) return;
    this.focusedFieldValue.set(fieldValue?.trim() || '');
    this.updateEmailHighlight();
  }

  onFieldBlur() {
    this.focusedFieldValue.set('');
    this.updateEmailHighlight();
  }

  onFieldClick(fieldValue: string | undefined | null) {
    if (!this.isEmailMode()) return;
    this.focusedFieldValue.set(fieldValue?.trim() || '');
    this.updateEmailHighlight();
  }

  updateEmailHighlight() {
    const fieldVal = this.focusedFieldValue();

    // Subject highlight
    const subj = this.subject || '';
    if (!fieldVal) {
      this.emailSubjectHtml.set(escapeHtml(subj));
    } else {
      this.emailSubjectHtml.set(highlightEmailText(subj, fieldVal));
    }

    // Sender info highlight
    const senderText = `${this.complainantName || 'Unknown'} <${this.complainantEmail || ''}>`;
    if (!fieldVal) {
      this.emailSenderHtml.set(escapeHtml(senderText));
    } else {
      this.emailSenderHtml.set(highlightEmailText(senderText, fieldVal));
    }

    // Body highlight
    if (!this.description) {
      this.emailBodyHtml.set('');
      return;
    }
    if (!fieldVal) {
      this.emailBodyHtml.set(escapeHtml(this.description));
      return;
    }
    this.emailBodyHtml.set(highlightEmailText(this.description, fieldVal));
  }

  // ─── Collapsible Sections ───
  sectionOpen = {
    complaint: true,
    eligibility: false,
    entity: true,
    complainant: false,
    classification: false,
    financial: false,
    legal: false,
    flags: false,
    linkage: false,
    declaration: false,
  } as any;

  draftId = '';
  draftStatus = 'DRAFT';
  deoAssessmentRemarks = '';
  deoAssessmentDecision = '';
  loading = signal(true);

  currentTab = signal<'details' | 'attachments' | 'assessment' | 'screening' | 'route'>('details');

  // ─── Editable Draft Fields (DEO can modify) ───
  complainantName = '';
  complainantPhone = '';
  complainantEmail = '';
  complainantAddress = '';
  complainantState = '';
  complainantDistrict = '';
  complainantPincode = '';
  contactPreference: 'EMAIL' | 'PHONE' | 'POST' = 'EMAIL';

  modeOfReceipt: 'EMAIL' | 'PHYSICAL_LETTER' | 'PORTAL' | 'CPGRAMS' = 'EMAIL';
  cpgramsReference = '';
  category = '';
  subCategory = '';
  entityName = '';
  entityType = 'BANK';
  entityState = '';
  entityCategory = '';
  entityBsrCode = '';
  entityPincode = '';
  entityCountry = '';
  entityDistrict = '';
  entityCity = '';
  entityBranchName = '';
  entityBranchCategory = '';
  entityAddress = '';
  branchCenterName = '';
  cosmosCode = '';
  assetSizeInCrores: number | null = null;
  depositTakingEntity = false;
  assetSizeGreater100Crores = false;
  liquidatedPresent = false;
  subject = '';
  description = '';
  amountInvolved: number | null = null;
  transactionDate = '';
  letterDate = '';
  receivedDate = '';
  vernacular = false;
  vernacularLanguage = '';
  vernacularLanguages = ['Hindi', 'Marathi', 'Tamil', 'Telugu', 'Kannada', 'Bengali', 'Gujarati', 'Malayalam', 'Punjabi', 'Odia', 'Urdu', 'Assamese', 'Konkani', 'Sanskrit'];
  emailType: 'TO' | 'CC_BCC' | '' = '';
  systemSuggestion: 'MAINTAINABLE' | 'NON_MAINTAINABLE' | 'PENDING' = 'PENDING';

  otherEntityName = '';
  registrationWithRbiDate = '';

  // ─── Complaint Classification ───
  complaintCategory = '';
  complaintSubCategory1 = '';
  complaintSubCategory2 = '';
  filingDate = '';
  registrationDateValid = true;

  // ─── Reminder & Financial Details ───
  reminderSent = true;
  disputedAmount: number | null = null;
  compensationSought = '';
  compensationSoughtYesNo = true;

  // ─── Legal & Case Details ───
  legalCaseFiled = false;
  preEnquiryReceived = false;
  highPriority = false;
  loanDisposalAmount: number | null = null;

  // ─── Flags & Indicators ───
  pensionComplaint = false;
  businessCorrespondent = false;
  atmCreditDebitCard = false;
  atmCardNumber = '';
  schemeFlag = '';
  rboCgpcOld = '';
  groundsFlag = '';

  // ─── Complaint Linkage ───
  freeMarkedComplaint = false;
  complaintReferenceNumber = '';
  currentComplaintNumber = '';
  replyWithin30Days: 'YES' | 'NO' | 'NA' = 'NA';

  // ─── Additional Info ───
  crpcProposedAction = '';
  additionalComments = '';

  // ─── Declaration ───
  declarationChecked = false;

  // ─── Attachments ───
  attachments = signal<Attachment[]>([]);
  uploadError = '';

  // ─── Email Correspondence (Request Additional Info) ───
  emailCorrespondence = signal<EmailCorrespondence[]>([]);
  showEmailComposer = signal(false);
  emailTo = '';
  emailSubject = '';
  emailBody = '';
  sendingEmail = signal(false);
  attachFormPdf = false;
  formPdfFields = [
    { key: 'name', label: 'Full Name', include: true },
    { key: 'phone', label: 'Phone Number', include: true },
    { key: 'email', label: 'Email Address', include: true },
    { key: 'address', label: 'Complete Address', include: true },
    { key: 'state', label: 'State', include: false },
    { key: 'district', label: 'District', include: false },
    { key: 'pincode', label: 'Pincode', include: false },
    { key: 'accountNumber', label: 'Account Number', include: false },
    { key: 'transactionId', label: 'Transaction ID / Reference', include: true },
    { key: 'transactionDate', label: 'Transaction Date', include: true },
    { key: 'amount', label: 'Amount Involved (₹)', include: true },
    { key: 'branchName', label: 'Branch Name', include: false },
    { key: 'description', label: 'Detailed Description', include: true },
    { key: 'supportingDocs', label: 'List of Supporting Documents', include: false },
  ];

  // ─── Maintainability Assessment ───
  maintainabilityQuestions: MaintainabilityQuestion[] = [
    { id: 'MQ1', question: 'Is the complaint against a Regulated Entity (Bank/NBFC/Payment System)?', answer: null, weight: 3 },
    { id: 'MQ2', question: 'Does the complaint fall under the grounds specified in the RBI Ombudsman Scheme?', answer: null, weight: 3 },
    { id: 'MQ3', question: 'Has the complainant first approached the RE and waited the stipulated period?', answer: null, weight: 2 },
    { id: 'MQ4', question: 'Is the complaint within the limitation period (1 year)?', answer: null, weight: 2 },
    { id: 'MQ5', question: 'Is the matter NOT sub-judice before any court/tribunal/forum?', answer: null, weight: 3 },
    { id: 'MQ6', question: 'Is the complainant identifiable (not anonymous)?', answer: null, weight: 1 },
    { id: 'MQ7', question: 'Does the complaint contain sufficient details to proceed?', answer: null, weight: 1 },
    { id: 'MQ8', question: 'Is the relief sought quantifiable or specific?', answer: null, weight: 1 },
  ];

  // ─── Auto-Closure Screening (Sequential) ───
  screeningQuestions = signal([
    { id: 'SQ1', question: 'Is the complaint time-barred (filed beyond 1 year from cause of action)?', answer: null as ('YES' | 'NO' | null), closureClause: 'TIME_BARRED' },
    { id: 'SQ2', question: 'Is the matter currently sub-judice before a court/tribunal/forum?', answer: null as ('YES' | 'NO' | null), closureClause: 'SUB_JUDICE' },
    { id: 'SQ3', question: 'Is the complaint regarding a matter already settled by agreement?', answer: null as ('YES' | 'NO' | null), closureClause: 'ALREADY_SETTLED' },
    { id: 'SQ4', question: 'Has the complainant not approached the RE before filing with the Ombudsman?', answer: null as ('YES' | 'NO' | null), closureClause: 'NOT_APPROACHED_RE' },
    { id: 'SQ5', question: 'Is the complaint anonymous (no identifiable complainant)?', answer: null as ('YES' | 'NO' | null), closureClause: 'ANONYMOUS' },
    { id: 'SQ6', question: 'Does the complaint lack specifics required for investigation?', answer: null as ('YES' | 'NO' | null), closureClause: 'INSUFFICIENT_DETAILS' },
    { id: 'SQ7', question: 'Is the subject matter outside the jurisdiction of RBI Ombudsman?', answer: null as ('YES' | 'NO' | null), closureClause: 'OUT_OF_JURISDICTION' },
    { id: 'SQ8', question: 'Is the complaint frivolous or vexatious in nature?', answer: null as ('YES' | 'NO' | null), closureClause: 'FRIVOLOUS' },
  ]);

  currentScreeningIndex = signal(0);

  autoClosureTriggered = computed(() => {
    return this.screeningQuestions().some(q => q.answer === 'YES');
  });

  autoClosureClause = computed(() => {
    const triggered = this.screeningQuestions().find(q => q.answer === 'YES');
    return triggered?.closureClause || '';
  });

  allScreeningComplete = computed(() => {
    return this.screeningQuestions().every(q => q.answer !== null);
  });

  // ─── Decision & Routing ───
  deoDecision: 'MAINTAINABLE' | 'NON_MAINTAINABLE' | '' = '';
  nonMaintainableReason = '';
  notAComplaintOthersReason = '';
  suggestionDepartment = '';
  suggestionNature = '';
  closureTag = '';
  selectedReviewer = '';
  assignmentType = 'MANUAL';
  deoRemarks = '';
  savedTemplateId = '';

  nonMaintainableReasons = [
    { value: 'APPEAL', label: 'Appeal' },
    { value: 'BROADCAST_MESSAGE', label: 'Broadcast Message' },
    { value: 'PASSWORD_CHANGE', label: 'Password Change Request' },
    { value: 'SUGGESTION', label: 'Suggestion' },
    { value: 'OTHERS', label: 'Others' },
    { value: 'TIME_BARRED', label: 'Time Barred (beyond 1 year)' },
    { value: 'SUB_JUDICE', label: 'Matter is Sub-Judice' },
    { value: 'ALREADY_SETTLED', label: 'Already Settled by Agreement' },
    { value: 'NOT_APPROACHED_RE', label: 'Complainant has not approached RE' },
    { value: 'ANONYMOUS', label: 'Anonymous Complaint' },
    { value: 'INSUFFICIENT_DETAILS', label: 'Insufficient Details' },
    { value: 'OUT_OF_JURISDICTION', label: 'Outside Jurisdiction' },
    { value: 'FRIVOLOUS', label: 'Frivolous/Vexatious' },
    { value: 'DUPLICATE', label: 'Duplicate Complaint' },
  ];

  closureTags = [
    { value: 'NM_CLAUSE_1', label: 'NM Clause 1 - Time Barred' },
    { value: 'NM_CLAUSE_2', label: 'NM Clause 2 - Sub Judice' },
    { value: 'NM_CLAUSE_3', label: 'NM Clause 3 - Outside Jurisdiction' },
    { value: 'NM_CLAUSE_4', label: 'NM Clause 4 - No Pecuniary Loss' },
    { value: 'NM_CLAUSE_5', label: 'NM Clause 5 - HR/Service Matter' },
    { value: 'VERNACULAR', label: 'Vernacular - Translation Required' },
  ];

  commentTemplates = [
    { id: 'T1', label: 'Standard Maintainable', text: 'Complaint meets all criteria for processing under the RBIOS scheme. All mandatory fields verified. Forwarding to Reviewer for action.' },
    { id: 'T2', label: 'Non-Maintainable - Time Barred', text: 'Complaint is time-barred (filed beyond 1 year from cause of action). Auto-closure screening confirmed. Recommended for closure under NM Clause 1.' },
    { id: 'T3', label: 'Non-Maintainable - Sub Judice', text: 'Matter is currently before a court/tribunal. Cannot be processed under RBIOS. Closure under NM Clause 2.' },
    { id: 'T4', label: 'Non-Maintainable - Outside Jurisdiction', text: 'Subject matter falls outside the jurisdiction of RBI Ombudsman. Closure under NM Clause 3.' },
    { id: 'T5', label: 'Incomplete - Awaiting Info', text: 'Complaint lacks sufficient details. Additional information requested from complainant via email. Pending response.' },
    { id: 'T6', label: 'CPGRAMS Referral', text: 'Complaint received via CPGRAMS. Reference verified. Processing as per CPGRAMS SLA guidelines.' },
    { id: 'T7', label: 'Vernacular - Translation Pending', text: 'Complaint received in regional language. Flagged for translation. Assessment pending translated content.' },
  ];

  reviewers = signal<ReviewerUser[]>([]);

  activeReviewers = computed(() => this.reviewers().filter(r => r.isActive && !r.isOnLeave));

  suggestedReviewer = computed(() => {
    const active = this.activeReviewers();
    const sorted = [...active].sort((a, b) => a.currentLoad - b.currentLoad);
    return sorted[0]?.id || '';
  });

  reviewerOnLeave = computed(() => {
    if (!this.selectedReviewer) return false;
    const rev = this.reviewers().find(r => r.id === this.selectedReviewer);
    return rev?.isOnLeave || false;
  });

  maintainabilityScore = computed(() => {
    let score = 0;
    let maxScore = 0;
    for (const q of this.maintainabilityQuestions) {
      if (q.answer === 'NA') continue;
      maxScore += q.weight;
      if (q.answer === 'YES') score += q.weight;
    }
    return maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
  });

  allQuestionsAnswered = computed(() => {
    return this.maintainabilityQuestions.every(q => q.answer !== null);
  });

  // ─── Read-Only Mode (view-only for statuses beyond DRAFT/ASSIGNED) ───
  get isReadOnly(): boolean {
    return this.draftStatus === 'SENT_TO_REVIEWER' || this.draftStatus === 'APPROVED' || this.draftStatus === 'APPROVED_ROUTED';
  }

  // ─── Mandatory Field Validation ───
  mandatoryFieldsComplete(): boolean {
    return this.complainantName.trim().length > 0 &&
           this.complainantState.trim().length > 0 &&
           this.complainantDistrict.trim().length > 0 &&
           (this.complainantPhone.trim().length > 0 || this.complainantEmail.trim().length > 0) &&
           this.category.trim().length > 0 &&
           this.entityName.trim().length > 0 &&
           this.subject.trim().length > 0;
  }

  missingMandatoryFields(): string[] {
    const missing: string[] = [];
    if (!this.complainantName.trim()) missing.push('Complainant Name');
    if (!this.complainantState.trim()) missing.push('State');
    if (!this.complainantDistrict.trim()) missing.push('District');
    if (!this.complainantPhone.trim() && !this.complainantEmail.trim()) missing.push('Phone or Email');
    if (!this.category.trim()) missing.push('Category');
    if (!this.entityName.trim()) missing.push('Entity Name');
    if (!this.subject.trim()) missing.push('Subject');
    return missing;
  }

  submitting = signal(false);
  submitted = signal(false);
  savingDraft = signal(false);
  draftSaved = signal(false);

  categories = ['ATM', 'CREDIT_CARD', 'UPI', 'LOAN', 'DEPOSIT', 'INSURANCE', 'NEFT_RTGS', 'GENERAL'];

  states = signal<string[]>([]);
  districts = signal<string[]>([]);
  pincodeLoading = signal(false);

  loggedInUser: { id: string; name: string; role: string } | null = null;

  // ─── Entity Search (from REGULATED_ENTITIES table) ───
  entitySearchText = '';
  entitySearchResults = signal<{ id: number; name: string; department: string; entityType: string }[]>([]);
  entitySearchLoading = signal(false);
  showEntityDropdown = signal(false);
  private entitySearchTimeout: any = null;
  entityDropdownTop = 0;
  entityDropdownLeft = 0;
  entityDropdownWidth = 300;

  // ─── Past & Similar Complaints ───
  pastComplaints = signal<any[]>([]);
  similarCases = signal<any[]>([]);
  loadingPastComplaints = signal(false);
  loadingSimilarCases = signal(false);

  // ─── Past Complaint Detail Modal ───
  showPastComplaintDetail = signal(false);
  pastComplaintDetail = signal<any>(null);
  loadingPastDetail = signal(false);

  ngOnInit() {
    const stored = sessionStorage.getItem('crpc_user');
    if (stored) {
      this.loggedInUser = JSON.parse(stored);
    } else {
      const user = this.auth.currentUser();
      if (user) {
        const role = this.auth.getRoles().find(r => ['DEO', 'REVIEWER', 'CRPC_HEAD'].includes(r)) || 'DEO';
        this.loggedInUser = { id: user.username, name: `${user.firstName} ${user.lastName}`.trim() || user.username, role };
        sessionStorage.setItem('crpc_user', JSON.stringify(this.loggedInUser));
      }
    }
    this.draftId = this.route.snapshot.paramMap.get('id') || '';
    this.loadDraft();
    this.loadStates();
    this.crpcService.getReviewers().subscribe(data => {
      if (data.length > 0) {
        this.reviewers.set(data);
      } else {
        this.reviewers.set([
          { id: 'reviewer1', displayName: 'Meera Krishnan', email: 'meera@rbi.org.in', isActive: true, isOnLeave: false, maxLoad: 25, currentLoad: 6, region: 'South', sortOrder: 1 },
          { id: 'reviewer.user', displayName: 'Shikha P', email: 'shikha@rbi.org.in', isActive: true, isOnLeave: false, maxLoad: 25, currentLoad: 10, region: 'North', sortOrder: 2 },
          { id: 'REV003', displayName: 'Radhika Rao', email: 'radhika@rbi.org.in', isActive: true, isOnLeave: true, maxLoad: 25, currentLoad: 12, region: 'North', sortOrder: 3 },
          { id: 'REV004', displayName: 'Priya Sharma', email: 'priya@rbi.org.in', isActive: true, isOnLeave: false, maxLoad: 25, currentLoad: 15, region: 'West', sortOrder: 4 },
        ]);
      }
    });
  }

  loadStates() {
    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/location/states`).subscribe({
      next: (res) => this.states.set(res?.data || []),
      error: () => {}
    });
  }

  onStateChange(state: string) {
    this.complainantState = state;
    this.complainantDistrict = '';
    this.districts.set([]);
    if (state) {
      this.loadDistrictsForState(state);
    }
  }

  loadDistrictsForState(state: string) {
    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/location/districts`, { params: { state } }).subscribe({
      next: (res) => this.districts.set(res?.data || []),
      error: () => {}
    });
  }

  onPincodeInput(value: string) {
    this.complainantPincode = value;
    if (value && value.length === 6 && /^\d{6}$/.test(value)) {
      this.pincodeLoading.set(true);
      this.http.get<any[]>(`/api/pincode/${value}`).subscribe({
        next: (res) => {
          this.pincodeLoading.set(false);
          if (res && res[0] && res[0].Status === 'Success' && res[0].PostOffice?.length) {
            const po = res[0].PostOffice[0];
            if (po.State) {
              this.complainantState = po.State;
              this.onStateChange(po.State);
            }
            if (po.District) {
              this.complainantDistrict = po.District;
            }
          }
        },
        error: () => this.pincodeLoading.set(false)
      });
    }
  }

  onEntitySearchInput(value: string) {
    this.entitySearchText = value;
    if (this.entitySearchTimeout) clearTimeout(this.entitySearchTimeout);
    this.entitySearchTimeout = setTimeout(() => this.searchEntities(value), 300);
  }

  searchEntities(query: string) {
    this.entitySearchLoading.set(true);
    this.showEntityDropdown.set(true);
    const params: any = {};
    if (query) params.search = query;
    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/routing/entities/list`, { params }).subscribe({
      next: (res) => {
        this.entitySearchResults.set(res?.data || []);
        this.entitySearchLoading.set(false);
      },
      error: () => {
        this.entitySearchResults.set([]);
        this.entitySearchLoading.set(false);
      }
    });
  }

  selectEntity(entity: { id: number; name: string; department: string; entityType: string; state?: string }) {
    this.entityName = entity.name;
    this.entityType = entity.entityType || 'BANK';
    this.entityState = (entity as any).state || '';
    this.entitySearchText = entity.name;
    this.showEntityDropdown.set(false);
  }

  onEntityFocus(inputEl: HTMLInputElement) {
    const rect = inputEl.getBoundingClientRect();
    this.entityDropdownTop = rect.bottom + 2;
    this.entityDropdownLeft = rect.left;
    this.entityDropdownWidth = rect.width;
    this.showEntityDropdown.set(true);
    this.searchEntities(this.entitySearchText || '');
  }

  onEntityBlur() {
    setTimeout(() => this.showEntityDropdown.set(false), 200);
  }

  loadPastComplaints() {
    if (!this.complainantEmail && !this.complainantPhone) return;
    this.loadingPastComplaints.set(true);

    const params: any = { excludeId: this.draftId };
    if (this.complainantEmail) params.email = this.complainantEmail;
    if (this.complainantPhone) params.phone = this.complainantPhone;

    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/past-complaints/by-complainant`, { params })
      .subscribe({
        next: (res) => {
          this.pastComplaints.set(res?.data || []);
          this.loadingPastComplaints.set(false);
        },
        error: () => this.loadingPastComplaints.set(false)
      });
  }

  loadSimilarCases() {
    if (!this.subject) return;
    this.loadingSimilarCases.set(true);

    this.http.post<any>(`${environment.apiBaseUrl}/api/v1/past-complaints/similar`, {
      subject: this.subject,
      description: this.description,
      category: this.category,
      excludeId: this.draftId
    }).subscribe({
      next: (res) => {
        this.similarCases.set(res?.data || []);
        this.loadingSimilarCases.set(false);
      },
      error: () => this.loadingSimilarCases.set(false)
    });
  }

  openPastComplaintDetail(complaintId: string) {
    this.showPastComplaintDetail.set(true);
    this.loadingPastDetail.set(true);
    this.pastComplaintDetail.set(null);

    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/past-complaints/detail/${complaintId}`)
      .subscribe({
        next: (res) => {
          this.pastComplaintDetail.set(res?.data || null);
          this.loadingPastDetail.set(false);
        },
        error: () => {
          this.loadingPastDetail.set(false);
          this.showPastComplaintDetail.set(false);
        }
      });
  }

  closePastComplaintDetail() {
    this.showPastComplaintDetail.set(false);
    this.pastComplaintDetail.set(null);
  }

  applySuggestion(index: number) {
    const suggs = this.suggestions();
    const s = suggs[index];
    if (!s || s.applied) return;

    switch (s.field) {
      case 'Entity': this.entityName = s.value; break;
      case 'Category': this.category = s.value; break;
      case 'Subject': this.subject = s.value; break;
      case 'Amount': this.amountInvolved = Number(s.value.replace(/[^\d.]/g, '')) || null; break;
      case 'State': this.complainantState = s.value; break;
      case 'District': this.complainantDistrict = s.value; break;
    }

    const updated = suggs.map((sg, i) => i === index ? { ...sg, applied: true } : sg);
    this.suggestions.set(updated);
  }

  applyAllSuggestions() {
    const suggs = this.suggestions();
    suggs.forEach((_, i) => {
      if (!suggs[i].applied) this.applySuggestion(i);
    });
  }

  togglePdfExpand() {
    this.pdfExpanded.set(!this.pdfExpanded());
  }

  openAttachmentsPanel() {
    const atts = this.attachments();
    console.log('[Attachments] Opening panel, count:', atts.length, atts.map(a => ({ id: a.id, name: a.name, url: a.url })));
    if (atts.length === 0) { this.showAttachmentsPanel.set(true); return; }
    atts.forEach(att => {
      if (!this.openedDocTabs().find(t => t.id === att.id)) {
        this.openedDocTabs.update(tabs => [...tabs, att]);
      }
      this.loadBlobUrl(att);
    });
    this.activeDocTabId.set(atts[0].id);
    this.showAttachmentsPanel.set(true);
  }

  closeAttachmentsPanel() {
    this.showAttachmentsPanel.set(false);
    this.viewingAttachment.set(null);
    // Reset tab viewer back to pinned email/document tab
    this.openedDocTabs.set([]);
    this.activeDocTabId.set(null);
  }

  viewAttachment(att: Attachment) {
    this.viewingAttachment.set(att);
    this.pdfCurrentPage.set(1);
  }

  viewAttachmentInNewTab(att: Attachment) {
    if (!att.url) return;
    const cached = this.blobUrlCache.get(att.id);
    if (cached) {
      window.open(cached, '_blank');
    } else {
      this.http.get(att.url, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = URL.createObjectURL(blob);
          window.open(url, '_blank');
        },
        error: () => {
          window.open(att.url, '_blank');
        }
      });
    }
  }

  downloadAttachment(att: Attachment) {
    if (!att.url) return;
    const cached = this.blobUrlCache.get(att.id);
    if (cached) {
      const a = document.createElement('a');
      a.href = cached;
      a.download = att.name;
      a.click();
    } else {
      this.http.get(att.url, { responseType: 'blob' }).subscribe({
        next: (blob) => {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = att.name;
          a.click();
          setTimeout(() => URL.revokeObjectURL(url), 1000);
        },
        error: () => {
          window.open(att.url, '_blank');
        }
      });
    }
  }

  closeViewingAttachment() {
    this.viewingAttachment.set(null);
  }

  pdfNextPage() {
    if (this.pdfCurrentPage() < this.pdfTotalPages()) {
      this.pdfCurrentPage.set(this.pdfCurrentPage() + 1);
    }
  }

  pdfPrevPage() {
    if (this.pdfCurrentPage() > 1) {
      this.pdfCurrentPage.set(this.pdfCurrentPage() - 1);
    }
  }

  toggleHistoryPanel() {
    if (this.showHistoryPanel()) {
      this.showHistoryPanel.set(false);
    } else {
      this.showHistoryPanel.set(true);
      this.showSimilarPanel.set(false);
      this.showAttachmentsPanel.set(false);
      this.loadHistory();
    }
  }

  toggleSimilarPanel() {
    if (this.showSimilarPanel()) {
      this.showSimilarPanel.set(false);
    } else {
      this.showSimilarPanel.set(true);
      this.showHistoryPanel.set(false);
      this.showAttachmentsPanel.set(false);
      this.loadSimilarCases();
    }
  }

  loadHistory() {
    this.loadingHistory.set(true);
    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/complaints/${this.draftId}/timeline`)
      .subscribe({
        next: (res) => {
          this.historyEntries.set(res?.data || []);
          this.loadingHistory.set(false);
        },
        error: () => {
          this.historyEntries.set([]);
          this.loadingHistory.set(false);
        }
      });
  }

  loadDraft() {
    this.loading.set(true);
    const isPhysicalLetter = this.draftId.startsWith('DRF-2026');

    if (isPhysicalLetter) {
      const saved = sessionStorage.getItem('physicalLetterDraft');
      const draft = saved ? JSON.parse(saved) : null;

      this.complainantName = draft?.complainantName || '';
      this.complainantPhone = draft?.complainantPhone || '';
      this.complainantEmail = draft?.complainantEmail || '';
      this.complainantAddress = draft?.complainantAddress || '';
      this.complainantState = draft?.complainantState || '';
      this.complainantDistrict = draft?.complainantDistrict || '';
      this.complainantPincode = draft?.complainantPincode || '';
      if (this.complainantPincode && !this.complainantState) {
        this.onPincodeInput(this.complainantPincode);
      }
      this.contactPreference = 'POST';

      this.modeOfReceipt = 'PHYSICAL_LETTER';
      this.category = draft?.category || '';
      this.entityName = draft?.entityName || '';
      this.entitySearchText = this.entityName;
      this.entityType = draft?.entityType || 'BANK';
      this.subject = draft?.subject || '';
      this.description = draft?.description || '';
      this.amountInvolved = draft?.amountInvolved || null;
      this.transactionDate = draft?.transactionDate || '';
      this.letterDate = draft?.letterDate || '';
      this.receivedDate = draft?.receivedDate || new Date().toISOString().split('T')[0];
      this.emailType = '';
      this.systemSuggestion = 'PENDING';
      this.vernacular = draft?.vernacular || false;
      this.vernacularLanguage = draft?.vernacularLanguage || '';

      this.attachments.set([
        { id: 'ATT-001', name: draft?.fileName || 'scanned_letter.pdf', size: draft?.fileSize || '2.4 MB', type: 'application/pdf', uploadedAt: new Date().toISOString(), uploadedBy: 'DEO' },
      ]);

      // Build suggestions from OCR-extracted data
      const suggs: { field: string; value: string; applied: boolean }[] = [];
      if (draft?.entityName) suggs.push({ field: 'Entity', value: draft.entityName, applied: false });
      if (draft?.category) suggs.push({ field: 'Category', value: draft.category, applied: false });
      if (draft?.amountInvolved) suggs.push({ field: 'Amount', value: `₹${draft.amountInvolved}`, applied: false });
      if (draft?.subject) suggs.push({ field: 'Subject', value: draft.subject, applied: false });
      this.suggestions.set(suggs);

      // Load PDF preview from sessionStorage blob if available
      const pdfBlob = sessionStorage.getItem('physicalLetterPdfUrl');
      if (pdfBlob) {
        this.pdfPreviewUrl.set(this.sanitizer.bypassSecurityTrustResourceUrl(pdfBlob));
      }

      this.emailCorrespondence.set([]);
      this.loading.set(false);
      this.updateEmailHighlight();
      if (this.complainantState) this.loadDistrictsForState(this.complainantState);
      this.loadPastComplaints();
      this.loadSimilarCases();
    } else {
      this.http.get<any>(`${environment.apiBaseUrl}/api/v1/email-syndication/drafts/${this.draftId}`)
        .subscribe({
          next: (res) => {
            const draft = res?.data || {};
            this.complainantName = draft.complainantName || '';
            this.complainantPhone = draft.complainantPhone || '';
            this.complainantEmail = draft.senderEmail || '';
            this.complainantAddress = draft.complainantAddress || '';
            this.complainantState = draft.complainantState || '';
            this.complainantDistrict = draft.complainantDistrict || '';
            this.complainantPincode = draft.complainantPincode || '';
            if (this.complainantPincode && !this.complainantState) {
              this.onPincodeInput(this.complainantPincode);
            }
            this.contactPreference = 'EMAIL';

            this.modeOfReceipt = (draft.modeOfReceipt as any) || 'EMAIL';
            this.cpgramsReference = draft.cpgramsNumber || '';
            this.complaintReferenceNumber = draft.complaintReferenceNumber || draft.acknowledgementNumber || '';
            this.category = draft.category || '';
            this.entityName = draft.entityName || '';
            this.entitySearchText = this.entityName;
            this.entityType = draft.entityType || 'BANK';
            this.subject = draft.subject || draft.complaintSummary || '';
            this.description = draft.body || '';
            this.amountInvolved = draft.amountInvolved || null;
            this.transactionDate = draft.transactionDate || '';
            this.receivedDate = draft.receivedAt ? draft.receivedAt.split('T')[0] : '';
            this.emailType = 'TO';
            this.draftStatus = draft.status || 'ASSIGNED';
            this.selectedReviewer = draft.assignedTo || '';
            this.deoAssessmentDecision = draft.deoDecision || '';
            this.deoAssessmentRemarks = draft.deoRemarks || '';
            this.systemSuggestion = draft.systemSuggestion || 'PENDING';
            this.vernacular = draft.isVernacular || false;
            this.vernacularLanguage = draft.languageName || '';

            const attachments = (draft.attachments || []).map((a: any, i: number) => {
              const attId = a.id || `ATT-${i + 1}`;
              const numericId = String(attId).replace('ATT-', '');
              return {
                id: attId,
                name: a.fileName || `attachment_${i + 1}`,
                size: a.fileSize ? this.formatFileSize(a.fileSize) : 'Unknown',
                type: a.fileType || 'application/octet-stream',
                uploadedAt: a.createdAt || new Date().toISOString(),
                uploadedBy: 'SYSTEM',
                url: `${environment.apiBaseUrl}/api/files/email-draft/${numericId}`
              };
            });
            this.attachments.set(attachments);

            // Apply OCR-extracted fields if available from ingest
            if (draft.ocrExtractedFields) {
              this.applyOcrFields(draft.ocrExtractedFields);
              this.ocrApplied.set(true);
            } else if (draft.ocrProcessed && draft.ocrConfidence > 0) {
              this.ocrApplied.set(true);
            }

            // Build suggestions from draft data
            const suggs: { field: string; value: string; applied: boolean }[] = [];
            if (draft.entityName) suggs.push({ field: 'Entity', value: draft.entityName, applied: false });
            if (draft.category) suggs.push({ field: 'Category', value: draft.category, applied: false });
            if (draft.amountInvolved) suggs.push({ field: 'Amount', value: `₹${draft.amountInvolved}`, applied: false });
            if (draft.ocrExtractedFields?.subject) suggs.push({ field: 'Subject', value: draft.ocrExtractedFields.subject, applied: false });
            this.suggestions.set(suggs);

            if (draft.senderEmail) {
              this.emailCorrespondence.set([{
                id: 'EC-001',
                direction: 'RECEIVED',
                subject: draft.subject || '',
                to: 'crpc@rbi.org.in',
                sentAt: draft.receivedAt || '',
                body: draft.body || 'Original complaint email received.',
              }]);
            } else {
              this.emailCorrespondence.set([]);
            }

            this.loading.set(false);
            this.updateEmailHighlight();
            if (this.complainantState) this.loadDistrictsForState(this.complainantState);
            this.loadPastComplaints();
            this.loadSimilarCases();
          },
          error: () => {
            this.loading.set(false);
          }
        });
    }
  }

  private formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return (bytes / 1024 / 1024).toFixed(1) + ' MB';
  }

  // ─── Attachment Management ───
  onFileUpload(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;

    const file = input.files[0];
    const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/tiff', 'message/rfc822'];
    if (!allowed.includes(file.type) && !file.name.endsWith('.eml')) {
      this.uploadError = 'Only PDF, JPEG, PNG, TIFF, or EML files are accepted.';
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      this.uploadError = 'File size must not exceed 2 MB.';
      return;
    }

    this.uploadError = '';
    const objectUrl = URL.createObjectURL(file);
    const newAtt: Attachment = {
      id: 'ATT-' + Date.now(),
      name: file.name,
      size: (file.size / 1024).toFixed(0) + ' KB',
      type: file.type,
      uploadedAt: new Date().toISOString(),
      uploadedBy: 'DEO',
      url: objectUrl
    };
    this.attachments.set([...this.attachments(), newAtt]);
    input.value = '';
  }

  activePreviewIndex = signal(0);

  activePreviewAttachment = computed(() => {
    const atts = this.attachments();
    const idx = this.activePreviewIndex();
    return atts.length > 0 ? atts[Math.min(idx, atts.length - 1)] : null;
  });

  // ─── Attachment Tabs ───
  openedDocTabs = signal<Attachment[]>([]);
  activeDocTabId = signal<string | null>(null);

  openAttachmentTab(att: Attachment) {
    if (!this.openedDocTabs().find(t => t.id === att.id)) {
      this.openedDocTabs.update(tabs => [...tabs, att]);
    }
    this.activeDocTabId.set(att.id);
    this.loadBlobUrl(att);
  }

  private loadBlobUrl(att: Attachment) {
    if (!att.url || this.blobUrlCache.has(att.id)) return;
    this.http.get(att.url, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        const objectUrl = URL.createObjectURL(blob);
        this.blobUrlCache.set(att.id, objectUrl);
        this.attachmentBlobUrls.update(map => ({
          ...map,
          [att.id]: this.sanitizer.bypassSecurityTrustResourceUrl(objectUrl)
        }));
      },
      error: (err) => {
        console.error('Failed to load attachment blob:', att.url, err);
        if (att.url) {
          this.attachmentBlobUrls.update(map => ({
            ...map,
            [att.id]: this.sanitizer.bypassSecurityTrustResourceUrl(att.url!)
          }));
        }
      }
    });
  }

  ngOnDestroy() {
    this.blobUrlCache.forEach(url => URL.revokeObjectURL(url));
    this.blobUrlCache.clear();
  }

  closeAttachmentTab(id: string, event: Event) {
    event.stopPropagation();
    const remaining = this.openedDocTabs().filter(t => t.id !== id);
    this.openedDocTabs.set(remaining);
    if (this.activeDocTabId() === id) {
      this.activeDocTabId.set(remaining.length > 0 ? remaining[remaining.length - 1].id : null);
    }
  }

  activeDocTabAttachment = computed(() => {
    const id = this.activeDocTabId();
    return id ? this.openedDocTabs().find(t => t.id === id) ?? null : null;
  });

  getSafeUrl(url: string): SafeResourceUrl {
    return this.sanitizer.bypassSecurityTrustResourceUrl(url);
  }

  prevDocument() {
    const idx = this.activePreviewIndex();
    if (idx > 0) this.activePreviewIndex.set(idx - 1);
  }

  nextDocument() {
    const idx = this.activePreviewIndex();
    if (idx < this.attachments().length - 1) this.activePreviewIndex.set(idx + 1);
  }

  removeAttachment(id: string) {
    this.attachments.set(this.attachments().filter(a => a.id !== id));
  }

  // ─── OCR Scanning ───
  ocrScanning = signal(false);
  ocrApplied = signal(false);
  ocrError = signal('');
  ocrFieldsExtracted = signal<Record<string, string>>({});

  scanAttachmentOcr(att: Attachment) {
    this.ocrScanning.set(true);
    this.ocrError.set('');

    // For attachments already on the server, call OCR endpoint with the attachment reference
    this.http.post<any>(`${environment.apiBaseUrl}/api/v1/ocr/extract-from-draft`, {
      draftId: this.draftId,
      attachmentId: att.id,
      fileName: att.name
    }).subscribe({
      next: (res) => {
        const data = res?.data || {};
        if (Object.keys(data).length === 0) {
          this.ocrError.set('OCR extraction returned no data. Try uploading a clearer scan.');
          this.ocrScanning.set(false);
          return;
        }
        this.applyOcrFields(data);
        this.ocrFieldsExtracted.set(data);
        this.ocrApplied.set(true);
        this.ocrScanning.set(false);
      },
      error: (err) => {
        this.ocrError.set(err.error?.message || 'OCR extraction failed. Please fill fields manually.');
        this.ocrScanning.set(false);
      }
    });
  }

  scanUploadedFileOcr(event: Event) {
    const input = event.target as HTMLInputElement;
    if (!input.files?.length) return;

    const file = input.files[0];
    const allowed = ['application/pdf', 'image/jpeg', 'image/png', 'image/tiff'];
    if (!allowed.includes(file.type)) {
      this.ocrError.set('Only PDF, JPEG, PNG, or TIFF files can be scanned.');
      return;
    }

    this.ocrScanning.set(true);
    this.ocrError.set('');

    const formData = new FormData();
    formData.append('file', file);

    this.http.post<any>(`${environment.apiBaseUrl}/api/v1/ocr/extract`, formData)
      .subscribe({
        next: (res) => {
          const data = res?.data || {};
          if (Object.keys(data).length === 0) {
            this.ocrError.set('AI extraction returned no data. API quota may be exhausted.');
            this.ocrScanning.set(false);
            return;
          }
          this.applyOcrFields(data);
          this.ocrFieldsExtracted.set(data);
          this.ocrApplied.set(true);
          this.ocrScanning.set(false);

          // Also add to attachments list
          const objectUrl = URL.createObjectURL(file);
          const newAtt: Attachment = {
            id: 'ATT-' + Date.now(),
            name: file.name,
            size: (file.size / 1024).toFixed(0) + ' KB',
            type: file.type,
            uploadedAt: new Date().toISOString(),
            uploadedBy: 'DEO',
            url: objectUrl
          };
          this.attachments.set([...this.attachments(), newAtt]);
        },
        error: (err) => {
          this.ocrError.set(err.error?.message || 'OCR failed. Please fill fields manually.');
          this.ocrScanning.set(false);
        }
      });

    input.value = '';
  }

  private applyOcrFields(data: Record<string, string>) {
    if (data['complainantName'] && !this.complainantName) this.complainantName = data['complainantName'];
    if (data['complainantPhone'] && !this.complainantPhone) this.complainantPhone = data['complainantPhone'];
    if (data['complainantEmail'] && !this.complainantEmail) this.complainantEmail = data['complainantEmail'];
    if (data['complainantAddress'] && !this.complainantAddress) this.complainantAddress = data['complainantAddress'];
    if (data['complainantState'] && !this.complainantState) this.complainantState = data['complainantState'];
    if (data['complainantDistrict'] && !this.complainantDistrict) this.complainantDistrict = data['complainantDistrict'];
    if (data['complainantPincode'] && !this.complainantPincode) {
      this.complainantPincode = data['complainantPincode'];
      this.onPincodeInput(data['complainantPincode']);
    }
    if (data['subject'] && !this.subject) this.subject = data['subject'];
    if (data['description'] && !this.description) this.description = data['description'];
    if (data['entityName'] && !this.entityName) this.entityName = data['entityName'];
    if (data['entityType'] && !this.entityType) this.entityType = data['entityType'];
    if (data['category'] && !this.category) this.category = data['category'];
    if (data['amountInvolved'] && !this.amountInvolved) this.amountInvolved = Number(data['amountInvolved']) || null;
    if (data['transactionDate'] && !this.transactionDate) this.transactionDate = data['transactionDate'];
    if (data['letterDate'] && !this.letterDate) this.letterDate = data['letterDate'];
  }

  // ─── Email: Request Additional Information ───
  openEmailComposer() {
    this.emailTo = this.complainantEmail;
    this.emailSubject = `RE: ${this.subject}`;
    this.emailBody = '';
    this.showEmailComposer.set(true);
  }

  // ═══ UST656: Email Restriction - RBI Domain Only ═══
  emailDomainError = '';

  sendEmail() {
    if (!this.emailTo || !this.emailBody) return;

    // UST656: Validate recipient against RBI domain
    const recipients = this.emailTo.split(/[,;]/).map(e => e.trim()).filter(e => e);
    const invalidEmails = recipients.filter(email =>
      !email.toLowerCase().endsWith('@rbi.org.in') && !email.toLowerCase().endsWith('@rbi.gov.in')
    );
    if (invalidEmails.length > 0) {
      this.emailDomainError = 'Only official RBI email addresses can be used for outbound complaint emails';
      // Log the rejected attempt
      this.http.post(`${environment.apiBaseUrl}/api/v1/workflow/validate-email-recipients`, {
        recipients: invalidEmails,
        actor: this.loggedInUser?.id || 'unknown'
      }).subscribe();
      return;
    }
    this.emailDomainError = '';

    this.sendingEmail.set(true);

    if (this.attachFormPdf) {
      this.generateAndAttachFormPdf();
    }

    setTimeout(() => {
      const attachNote = this.attachFormPdf ? '\n\n[Attached: Additional_Information_Form.pdf (editable)]' : '';
      const newEmail: EmailCorrespondence = {
        id: 'EC-' + Date.now(),
        direction: 'SENT',
        subject: this.emailSubject,
        to: this.emailTo,
        sentAt: new Date().toISOString(),
        body: this.emailBody + attachNote,
      };
      this.emailCorrespondence.set([...this.emailCorrespondence(), newEmail]);
      this.sendingEmail.set(false);
      this.showEmailComposer.set(false);
      this.attachFormPdf = false;
    }, 1000);
  }

  cancelEmail() {
    this.showEmailComposer.set(false);
    this.attachFormPdf = false;
  }

  async downloadFormPdf() {
    const { jsPDF } = await import('jspdf');
    const doc = this.buildFormPdf(jsPDF);
    doc.save('Additional_Information_Form.pdf');
  }

  private async generateAndAttachFormPdf() {
    const { jsPDF } = await import('jspdf');
    this.buildFormPdf(jsPDF);
  }

  private getFieldPrefillValue(key: string): string {
    const map: Record<string, string> = {
      name: this.complainantName || '',
      phone: this.complainantPhone || '',
      email: this.complainantEmail || '',
      address: this.complainantAddress || '',
      state: this.complainantState || '',
      district: this.complainantDistrict || '',
      pincode: this.complainantPincode || '',
      accountNumber: '',
      transactionId: '',
      transactionDate: this.transactionDate || '',
      amount: this.amountInvolved ? String(this.amountInvolved) : '',
      branchName: '',
      description: this.description || '',
      supportingDocs: '',
    };
    return map[key] || '';
  }

  private buildFormPdf(jsPDF: any): any {
    const doc = new jsPDF();
    const selectedFields = this.formPdfFields.filter(f => f.include);
    const pageWidth = doc.internal.pageSize.getWidth();
    const fieldWidth = pageWidth - 28;

    // Header
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text('Reserve Bank of India - Integrated Ombudsman Scheme', pageWidth / 2, 20, { align: 'center' });

    doc.setFontSize(11);
    doc.setFont('helvetica', 'normal');
    doc.text('ADDITIONAL INFORMATION REQUEST FORM', pageWidth / 2, 28, { align: 'center' });

    doc.setFontSize(9);
    doc.text(`Reference: ${this.draftId}`, 14, 38);
    doc.text(`Date: ${new Date().toLocaleDateString('en-IN')}`, 14, 44);
    doc.text(`To: ${this.complainantName || 'Complainant'}`, 14, 50);

    doc.setFontSize(9);
    doc.setFont('helvetica', 'italic');
    doc.text('Please fill in / correct the details below and return this form to crpc@rbi.org.in', 14, 60);
    doc.text('Fields are editable - click on any field to type or modify the pre-filled value.', 14, 66);
    doc.setFont('helvetica', 'normal');

    // Editable AcroForm fields
    let y = 76;

    for (const field of selectedFields) {
      if (y > 260) {
        doc.addPage();
        y = 20;
      }

      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text(`${field.label}:`, 14, y);
      y += 2;

      const isMultiline = field.key === 'description' || field.key === 'address';
      const fieldHeight = isMultiline ? 25 : 10;
      const prefill = this.getFieldPrefillValue(field.key);

      const textField = new doc.AcroFormTextField();
      textField.fieldName = field.key;
      textField.x = 14;
      textField.y = y;
      textField.width = fieldWidth;
      textField.height = fieldHeight;
      textField.fontSize = 10;
      textField.value = prefill;
      textField.defaultValue = prefill;
      textField.multiline = isMultiline;
      textField.readOnly = false;
      doc.addField(textField);

      y += fieldHeight + 8;
    }

    // Footer
    y += 5;
    if (y > 270) {
      doc.addPage();
      y = 20;
    }
    doc.setFontSize(8);
    doc.setFont('helvetica', 'italic');
    doc.text('Signature / Date: _______________________________', 14, y);
    y += 8;
    doc.text('Note: Failure to provide the requested information within 15 days may result in closure of the complaint.', 14, y);

    return doc;
  }

  // ─── Auto-Closure Screening (Sequential) ───
  answerScreening(answer: 'YES' | 'NO') {
    const idx = this.currentScreeningIndex();
    const updated = this.screeningQuestions().map((q, i) =>
      i === idx ? { ...q, answer } : q
    );
    this.screeningQuestions.set(updated);

    if (idx < updated.length - 1) {
      this.currentScreeningIndex.set(idx + 1);
    }
  }

  resetScreening() {
    this.screeningQuestions.set(this.screeningQuestions().map(q => ({ ...q, answer: null })));
    this.currentScreeningIndex.set(0);
  }

  // ─── Comment Templates ───
  applyTemplate(templateId: string) {
    const tmpl = this.commentTemplates.find(t => t.id === templateId);
    if (tmpl) {
      this.deoRemarks = tmpl.text;
      this.savedTemplateId = templateId;
    }
  }

  // ─── Reviewer Routing ───
  useRoundRobin() {
    this.selectedReviewer = this.suggestedReviewer();
  }

  onAssignmentModeChange(mode: string) {
    if (mode === 'RoundRobin') {
      this.useRoundRobin();
    } else {
      this.selectedReviewer = '';
    }
  }

  getReviewerName(id: string): string {
    const rev = this.reviewers().find(r => r.id === id);
    return rev?.displayName || id || '';
  }

  // ─── Save Draft (without sending) ───
  saveDraft() {
    this.savingDraft.set(true);

    this.http.put<any>(`${environment.apiBaseUrl}/api/v1/email-syndication/drafts/${this.draftId}`, {
      complainantName: this.complainantName,
      complainantPhone: this.complainantPhone,
      complainantAddress: this.complainantAddress,
      complainantState: this.complainantState,
      complainantDistrict: this.complainantDistrict,
      complainantPincode: this.complainantPincode,
      subject: this.subject,
      body: this.description,
      category: this.category,
      entityName: this.entityName,
      entityType: this.entityType,
      cpgramsNumber: this.cpgramsReference,
      complaintReferenceNumber: this.complaintReferenceNumber,
    }).subscribe({
      next: () => {
        this.savingDraft.set(false);
        this.draftSaved.set(true);
        setTimeout(() => this.draftSaved.set(false), 3000);
      },
      error: () => {
        this.savingDraft.set(false);
      }
    });
  }

  // ─── Confirmation Dialog Methods ───
  openConfirmDialog() {
    this.confirmAssignmentMode = 'Automatic';
    const active = this.reviewers().filter(r => r.isActive && !r.isOnLeave);
    const lowestLoad = [...active].sort((a, b) => a.currentLoad - b.currentLoad)[0];
    this.selectedReviewerName = lowestLoad?.displayName || active[0]?.displayName || '';
    this.showConfirmDialog.set(true);
  }

  onConfirmAssignmentModeChange(mode: string) {
    if (mode === 'Automatic') {
      const active = this.reviewers().filter(r => r.isActive && !r.isOnLeave);
      const lowestLoad = [...active].sort((a, b) => a.currentLoad - b.currentLoad)[0];
      this.selectedReviewerName = lowestLoad?.displayName || active[0]?.displayName || '';
    } else {
      this.selectedReviewerName = '';
    }
  }

  confirmReviewerOnLeave(): boolean {
    if (!this.selectedReviewerName.trim()) return false;
    const onLeaveNames = this.reviewers().filter(r => r.isOnLeave).map(r => r.displayName.toLowerCase());
    return onLeaveNames.includes(this.selectedReviewerName.toLowerCase());
  }

  // ─── Validation for Send for Approval ───
  canSendForApproval(): boolean {
    return this.selectedReviewerName.trim().length > 0;
  }

  sendForApproval() {
    if (!this.canSendForApproval()) return;
    this.submitting.set(true);

    let assignedTo = this.selectedReviewerName;
    const matchedReviewer = this.reviewers().find(r => r.displayName === this.selectedReviewerName);
    if (matchedReviewer) {
      assignedTo = matchedReviewer.id;
    }

    const payload = {
      draftId: this.draftId,
      status: 'SENT_TO_REVIEWER',
      assignedTo,
      processedBy: this.loggedInUser?.id || 'DEO',
      complainantName: this.complainantName,
      complainantPhone: this.complainantPhone,
      complainantAddress: this.complainantAddress,
      complainantState: this.complainantState,
      complainantDistrict: this.complainantDistrict,
      complainantPincode: this.complainantPincode,
      senderEmail: this.complainantEmail,
      subject: this.subject,
      body: this.description,
      category: this.category,
      entityName: this.entityName,
      entityType: this.entityType,
      modeOfReceipt: this.modeOfReceipt,
      deoDecision: this.deoDecision,
      deoRemarks: this.deoRemarks,
      nonMaintainableReason: this.nonMaintainableReason,
      complaintReferenceNumber: this.complaintReferenceNumber,
      receivedAt: this.receivedDate ? this.receivedDate + 'T00:00:00' : new Date().toISOString(),
    };

    const isPhysicalLetter = this.draftId.startsWith('DRF-');

    if (isPhysicalLetter) {
      this.http.post<any>(`${environment.apiBaseUrl}/api/v1/email-syndication/drafts`, payload)
        .subscribe({
          next: () => {
            this.submitting.set(false);
            this.submitted.set(true);
            this.showConfirmDialog.set(false);
          },
          error: () => {
            this.submitting.set(false);
          }
        });
    } else {
      this.http.put<any>(`${environment.apiBaseUrl}/api/v1/email-syndication/drafts/${this.draftId}`, payload)
        .subscribe({
          next: () => {
            this.submitting.set(false);
            this.submitted.set(true);
            this.showConfirmDialog.set(false);
          },
          error: () => {
            this.submitting.set(false);
          }
        });
    }
  }

  confirmAndSend() {
    this.sendForApproval();
  }

  enterEditMode() {
    this.editMode.set(true);
    this.activeStep.set('creation');
    this.sectionOpen.complaint = true;
  }

  onDeoDecisionChange(decision: string) {
    this.deoDecision = decision as any;
    if (decision === 'MAINTAINABLE') {
      this.maintainabilityQuestions.forEach(q => q.answer = 'YES');
    }
  }

  onEligibilityAnswer(id: string, answer: string) {
    const q = this.maintainabilityQuestions.find(mq => mq.id === id);
    if (q) q.answer = answer as any;
  }

  goToAssignment() {
    this.activeStep.set('assignment');
  }

  goToCreation() {
    this.activeStep.set('creation');
  }

  goBack() {
    if (this.editMode() && this.activeStep() === 'assignment') {
      this.activeStep.set('creation');
      return;
    }
    if (this.editMode()) {
      this.editMode.set(false);
      return;
    }
    this.router.navigate(['/crpc/home']);
  }

  logout() {
    sessionStorage.removeItem('crpc_user');
    this.auth.logout();
  }

  startAutoClosureScreening() {
    this.showAutoClosureEngine.set(true);
  }

  onAutoClosureCompleted(result: { responses: any[]; outcome: string; clauseReference: string; subJudice: boolean; generateComplaintNumber: boolean }) {
    this.autoClosureCompleted.set(true);
    this.autoClosureOutcome.set(result.outcome);
    this.autoClosureSubJudice.set(result.subJudice);
    this.autoClosureClauseRef.set(result.clauseReference);
    this.autoClosureResponses.set(result.responses);
    this.showAutoClosureEngine.set(false);

    // Update decision based on outcome
    if (result.outcome === 'CRPC_REJECTION' || result.outcome === 'NOT_A_COMPLAINT') {
      this.deoDecision = 'NON_MAINTAINABLE';
      this.nonMaintainableReason = result.clauseReference;
    } else {
      this.deoDecision = 'MAINTAINABLE';
    }
  }

  onAutoClosureCancelled() {
    this.showAutoClosureEngine.set(false);
  }

  amountInWords(num: number | null): string {
    if (!num || num === 0) return '';
    const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
      'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
    const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

    const convert = (n: number): string => {
      if (n === 0) return '';
      if (n < 20) return ones[n];
      if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 ? '-' + ones[n % 10] : '');
      if (n < 1000) return ones[Math.floor(n / 100)] + ' hundred' + (n % 100 ? ' ' + convert(n % 100) : '');
      if (n < 100000) return convert(Math.floor(n / 1000)) + ' thousand' + (n % 1000 ? ' ' + convert(n % 1000) : '');
      if (n < 10000000) return convert(Math.floor(n / 100000)) + ' lakh' + (n % 100000 ? ' ' + convert(n % 100000) : '');
      return convert(Math.floor(n / 10000000)) + ' crore' + (n % 10000000 ? ' ' + convert(n % 10000000) : '');
    };

    return convert(Math.round(num)).replace(/^\w/, c => c.toUpperCase()) + ' rupees';
  }
}
