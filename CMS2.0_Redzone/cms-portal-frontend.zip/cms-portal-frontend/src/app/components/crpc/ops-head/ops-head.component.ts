import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { KeycloakAuthService } from '../../../services/keycloak-auth.service';
import { environment } from '../../../../environments/environment';
import { SpeechButtonComponent } from '../../../shared/speech-button/speech-button.component';

interface TransferComplaint {
  complaintId: string;
  complaintNumber: string;
  from: string;
  pending: number;
  fromOffice: string;
  targetOffice: string;
  status: string;
  entityName: string;
  proposedCategory: string;
  creationDate: string;
  language: string;
  territory: string;
  subject: string;
  complainantName: string;
  complainantEmail: string;
  complainantPhone: string;
  description: string;
  timeline: { action: string; fromStatus: string; toStatus: string; timestamp: string; remarks: string }[];
}

interface OfficeThreshold {
  officeId: string;
  officeName: string;
  department: string;
  maxThreshold: number;
  currentCount: number;
  overflowSequenceOrder: number;
  active: boolean;
}

@Component({
  selector: 'app-ops-head',
  standalone: true,
  imports: [CommonModule, FormsModule, SpeechButtonComponent],
  templateUrl: './ops-head.component.html',
  styleUrl: './ops-head.component.scss'
})
export class OpsHeadComponent implements OnInit {
  private router = inject(Router);
  private http = inject(HttpClient);
  auth = inject(KeycloakAuthService);

  loading = signal(true);
  complaints = signal<TransferComplaint[]>([]);
  selectedComplaint = signal<TransferComplaint | null>(null);
  sidebarItem = signal('transfers');

  // Filters & sorting
  searchText = signal('');
  sortColumn = '';
  sortDirection: 'asc' | 'desc' = 'asc';
  currentPage = signal(1);
  pageSize = 10;

  // Forward panel
  forwardLanguage = '';
  forwardTerritory = '';
  reassignTerritory = '';

  // Confirmation dialog
  showConfirmDialog = signal(false);
  confirmAction = signal<'approve' | 'reject'>('approve');
  confirmComments = '';
  processing = signal(false);
  actionResult = signal('');
  actionSuccess = signal(false);

  // Office Thresholds
  officeThresholds = signal<OfficeThreshold[]>([]);
  loadingThresholds = signal(false);
  editingThresholdId = signal<string | null>(null);
  editThresholdValue = 0;

  // Bulk Reassignment
  selectedForBulk = signal<Set<string>>(new Set());
  bulkAssignTo = '';
  bulkReason = '';
  showBulkDialog = signal(false);
  bulkProcessing = signal(false);

  // Transfer History
  transferHistory = signal<any[]>([]);
  loadingHistory = signal(false);

  languages = ['English', 'Hindi', 'Marathi', 'Tamil', 'Telugu', 'Kannada', 'Bengali', 'Gujarati', 'Malayalam', 'Punjabi', 'Odia', 'Urdu'];
  territories = ['Mumbai', 'Delhi', 'Chennai', 'Kolkata', 'Bangalore', 'Hyderabad', 'Ahmedabad', 'Pune', 'Jaipur', 'Lucknow', 'Chandigarh', 'Bhopal', 'Thiruvananthapuram', 'Bhubaneswar', 'Guwahati', 'Patna'];

  stats = computed(() => {
    const all = this.complaints();
    return {
      total: all.length,
      totalTransfers: all.filter(c => c.status.includes('Sent')).length,
      intraRbio: all.filter(c => c.fromOffice.includes('RBIO') && c.targetOffice.includes('RBIO')).length,
      withinCrpc: all.filter(c => c.fromOffice.includes('CRPC') && c.targetOffice.includes('CRPC')).length,
      rbioToCrpc: all.filter(c => c.fromOffice.includes('RBIO') && c.targetOffice.includes('CRPC')).length,
      crpcToRbio: all.filter(c => c.fromOffice.includes('CRPC') && c.targetOffice.includes('RBIO')).length,
      crpcToRbioDept: all.filter(c => c.targetOffice.includes('RBI Dept')).length,
    };
  });

  filteredComplaints = computed(() => {
    let result = this.complaints();
    const search = this.searchText().toLowerCase();
    if (search) {
      result = result.filter(c =>
        c.complaintId.toLowerCase().includes(search) ||
        c.complaintNumber.toLowerCase().includes(search) ||
        c.entityName.toLowerCase().includes(search) ||
        c.fromOffice.toLowerCase().includes(search) ||
        c.targetOffice.toLowerCase().includes(search)
      );
    }
    if (this.sortColumn) {
      result = [...result].sort((a, b) => {
        const av = (a as any)[this.sortColumn] || '';
        const bv = (b as any)[this.sortColumn] || '';
        const cmp = String(av).localeCompare(String(bv), undefined, { numeric: true });
        return this.sortDirection === 'asc' ? cmp : -cmp;
      });
    }
    return result;
  });

  totalPages = computed(() => Math.max(1, Math.ceil(this.filteredComplaints().length / this.pageSize)));

  paginatedComplaints = computed(() => {
    const start = (this.currentPage() - 1) * this.pageSize;
    return this.filteredComplaints().slice(start, start + this.pageSize);
  });

  paginationStart = computed(() => this.filteredComplaints().length === 0 ? 0 : (this.currentPage() - 1) * this.pageSize + 1);
  paginationEnd = computed(() => Math.min(this.currentPage() * this.pageSize, this.filteredComplaints().length));

  pageNumbers = computed(() => {
    const total = this.totalPages();
    const current = this.currentPage();
    const pages: number[] = [];
    for (let i = Math.max(1, current - 2); i <= Math.min(total, current + 2); i++) pages.push(i);
    return pages;
  });

  async ngOnInit() {
    const authenticated = await this.auth.init();
    if (!authenticated) {
      this.router.navigate(['/staff/login']);
      return;
    }
    this.loadTransferComplaints();
  }

  private loadTransferComplaints() {
    this.loading.set(true);
    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/crpc/head/transfers/pending`).subscribe({
      next: (res) => {
        const data = Array.isArray(res) ? res : (res?.data || []);
        this.complaints.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.complaints.set(this.getMockData());
        this.loading.set(false);
      }
    });
  }

  private getMockData(): TransferComplaint[] {
    const statuses = ['Sent to Other', 'Sent to DO', 'Pending Approval', 'Sent Back'];
    const offices = ['CRPC Mumbai', 'CRPC Delhi', 'RBIO Chennai', 'RBIO Kolkata', 'CRPC Bangalore', 'RBI Dept - Banking Supervision'];
    const entities = ['HDFC Bank', 'ICICI Bank', 'SBI', 'Axis Bank', 'PNB', 'Bank of Baroda', 'Kotak Mahindra', 'IndusInd Bank'];
    const data: TransferComplaint[] = [];
    for (let i = 1; i <= 25; i++) {
      data.push({
        complaintId: `CMP-${6500 + i}`,
        complaintNumber: `CRPC/2024-25/${String(i).padStart(5, '0')}`,
        from: `user${i}@email.com`,
        pending: Math.floor(Math.random() * 15) + 1,
        fromOffice: offices[Math.floor(Math.random() * 3)],
        targetOffice: offices[Math.floor(Math.random() * offices.length)],
        status: statuses[Math.floor(Math.random() * statuses.length)],
        entityName: entities[Math.floor(Math.random() * entities.length)],
        proposedCategory: ['Banking', 'Credit Card', 'Insurance', 'ATM', 'Digital Payment'][Math.floor(Math.random() * 5)],
        creationDate: new Date(Date.now() - Math.random() * 30 * 86400000).toISOString().split('T')[0],
        language: ['English', 'Hindi', 'Marathi', 'Tamil'][Math.floor(Math.random() * 4)],
        territory: ['Mumbai', 'Delhi', 'Chennai', 'Kolkata', 'Bangalore'][Math.floor(Math.random() * 5)],
        subject: `Complaint regarding ${entities[Math.floor(Math.random() * entities.length)]} services`,
        complainantName: `Complainant ${i}`,
        complainantEmail: `user${i}@email.com`,
        complainantPhone: `98765${String(43210 + i).padStart(5, '0')}`,
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Customer is facing issues with banking services.',
        timeline: [
          { action: 'Created', fromStatus: '', toStatus: 'New', timestamp: new Date(Date.now() - 20 * 86400000).toISOString(), remarks: 'Complaint registered' },
          { action: 'Assigned', fromStatus: 'New', toStatus: 'Assigned', timestamp: new Date(Date.now() - 18 * 86400000).toISOString(), remarks: 'Auto-assigned via round robin' },
          { action: 'Transfer Requested', fromStatus: 'Assigned', toStatus: 'Sent to Other', timestamp: new Date(Date.now() - 5 * 86400000).toISOString(), remarks: 'Transferred to target office' },
        ]
      });
    }
    return data;
  }

  sortBy(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }
  }

  openComplaint(complaint: TransferComplaint) {
    this.selectedComplaint.set(complaint);
    this.forwardLanguage = complaint.language || '';
    this.forwardTerritory = complaint.territory || '';
    this.reassignTerritory = '';
    this.actionResult.set('');
  }

  closeDetail() {
    this.selectedComplaint.set(null);
  }

  openConfirmDialog(action: 'approve' | 'reject') {
    this.confirmAction.set(action);
    this.confirmComments = '';
    this.showConfirmDialog.set(true);
  }

  cancelConfirm() {
    this.showConfirmDialog.set(false);
    this.confirmComments = '';
  }

  submitConfirm() {
    const complaint = this.selectedComplaint();
    if (!complaint) return;

    this.processing.set(true);
    const action = this.confirmAction();
    const username = this.auth.currentUser()?.username || '';

    // THE TRANSFER ID, not the complaint id. The endpoint is @PathVariable Long id on
    // INTER_OFFICE_TRANSFERS, so posting a complaintId addressed a different row entirely — or none at all,
    // which surfaced as "Transfer not found". Refused rather than guessed when absent.
    const transferId = (complaint as any).transferId ?? (complaint as any).id;
    if (transferId === undefined || transferId === null || transferId === '') {
      this.actionSuccess.set(false);
      this.actionResult.set('This queue row carries no transfer id, so it cannot be resolved. Reload the queue.');
      this.processing.set(false);
      this.showConfirmDialog.set(false);
      return;
    }

    // UST526/567: the rejection comment is mandatory. Checked here as an affordance; the server refuses a
    // blank one too, which it previously did not — a required @RequestParam accepted `?comment=`.
    if (action === 'reject' && !this.confirmComments.trim()) {
      this.actionSuccess.set(false);
      this.actionResult.set('A comment is required to reject a transfer.');
      this.processing.set(false);
      return;
    }

    const endpoint = action === 'approve'
      ? `${environment.apiBaseUrl}/api/v1/crpc/head/transfers/${transferId}/approve`
      : `${environment.apiBaseUrl}/api/v1/crpc/head/transfers/${transferId}/reject`;

    // The server now reads these from the query string OR the body. Both spellings are sent because the
    // body-only shape previously met a required @RequestParam and every call from this screen 400'd.
    const body = action === 'approve'
      ? { approvedBy: username, actor: username, comment: this.confirmComments }
      : { approvedBy: username, actor: username, rejectedBy: username,
          comment: this.confirmComments, rejectionComment: this.confirmComments };

    this.http.post<any>(endpoint, body).subscribe({
      next: () => {
        this.actionSuccess.set(true);
        this.actionResult.set(`Transfer ${action === 'approve' ? 'approved' : 'rejected'} successfully.`);
        this.processing.set(false);
        this.showConfirmDialog.set(false);
        this.loadTransferComplaints();
        setTimeout(() => this.selectedComplaint.set(null), 1500);
      },
      error: (err) => {
        this.actionSuccess.set(false);
        this.actionResult.set(`Failed: ${err.error?.message || err.message || 'Unknown error'}`);
        this.processing.set(false);
        this.showConfirmDialog.set(false);
      }
    });
  }

  getExpectedStatusChange(): string {
    const current = this.selectedComplaint()?.status || '';
    if (this.confirmAction() === 'approve') {
      return `${current} → Sent to DO`;
    }
    return `${current} → Sent Back to Deputy Ombudsman`;
  }

  navigateTo(item: string) {
    this.sidebarItem.set(item);
    if (item === 'home') this.router.navigate(['/crpc/home']);
    if (item === 'reviewer') this.router.navigate(['/crpc/reviewer']);
    if (item === 'thresholds') this.loadOfficeThresholds();
    if (item === 'history') this.loadTransferHistory();
  }

  // Office Thresholds methods
  loadOfficeThresholds() {
    this.loadingThresholds.set(true);
    this.http.get<any>(`${environment.apiBaseUrl}/api/v1/crpc/head/office-thresholds`).subscribe({
      next: (res) => {
        const data = Array.isArray(res) ? res : (res?.data || []);
        this.officeThresholds.set(data);
        this.loadingThresholds.set(false);
      },
      error: () => {
        // FAILS CLOSED. This previously substituted three invented offices with invented counts
        // ('CRPC-CHD' 78/100 and so on) — none of which exist in OFFICE_THRESHOLD_CONFIG, whose keys are
        // numeric OFFICE_CODEs. A Head deciding whether an office can absorb a transfer would have been
        // reading fabricated capacity, and editing a threshold against a mock id would 404 or, worse,
        // silently target nothing. An empty list with a visible error is the honest state.
        this.officeThresholds.set([]);
        this.loadingThresholds.set(false);
        this.actionSuccess.set(false);
        this.actionResult.set('Office capacity could not be loaded. Please retry.');
      }
    });
  }

  startEditThreshold(officeId: string, currentMax: number) {
    this.editingThresholdId.set(officeId);
    this.editThresholdValue = currentMax;
  }

  saveThreshold(officeId: string) {
    this.http.put(`${environment.apiBaseUrl}/api/v1/crpc/head/office-thresholds/${officeId}`, null, {
      params: { threshold: this.editThresholdValue.toString() }
    }).subscribe({
      next: () => {
        this.editingThresholdId.set(null);
        this.loadOfficeThresholds();
      },
      error: () => this.editingThresholdId.set(null)
    });
  }

  cancelEditThreshold() {
    this.editingThresholdId.set(null);
  }

  resetCounters(department: string) {
    this.http.post(`${environment.apiBaseUrl}/api/v1/crpc/head/office-thresholds/reset`, null, {
      params: { department }
    }).subscribe({ next: () => this.loadOfficeThresholds() });
  }

  // Bulk Reassignment methods
  toggleBulkSelect(id: string) {
    const current = this.selectedForBulk();
    const next = new Set(current);
    if (next.has(id)) next.delete(id); else next.add(id);
    this.selectedForBulk.set(next);
  }

  selectAllForBulk() {
    const ids = this.paginatedComplaints().map(c => c.complaintId);
    this.selectedForBulk.set(new Set(ids));
  }

  clearBulkSelection() {
    this.selectedForBulk.set(new Set());
  }

  openBulkReassign() {
    this.bulkAssignTo = '';
    this.bulkReason = '';
    this.showBulkDialog.set(true);
  }

  submitBulkReassign() {
    const ids = Array.from(this.selectedForBulk());
    if (ids.length === 0 || !this.bulkAssignTo) return;
    this.bulkProcessing.set(true);

    this.http.post(`${environment.apiBaseUrl}/api/v1/crpc/head/bulk-reassign`, {
      complaintIds: ids,
      assignTo: this.bulkAssignTo,
      reason: this.bulkReason
    }).subscribe({
      next: () => {
        this.bulkProcessing.set(false);
        this.showBulkDialog.set(false);
        this.selectedForBulk.set(new Set());
        this.loadTransferComplaints();
      },
      error: () => this.bulkProcessing.set(false)
    });
  }

  cancelBulkReassign() {
    this.showBulkDialog.set(false);
  }

  /**
   * The transfer history for the SELECTED complaint (UST562, 558, 568, 565).
   *
   * The server route is /transfers/history/{complaintNumber}. This called /transfers/history with no
   * complaint number, so every request 404'd into an error handler that only cleared the spinner — the
   * History panel was permanently empty and looked like a complaint with no transfers.
   */
  loadTransferHistory() {
    const complaint = this.selectedComplaint();
    const complaintNumber = complaint?.complaintNumber ?? (complaint as any)?.complaintId;
    if (!complaintNumber) {
      // Nothing selected: show an empty list rather than firing a request that cannot succeed.
      this.transferHistory.set([]);
      this.loadingHistory.set(false);
      return;
    }

    this.loadingHistory.set(true);
    this.http.get<any>(
      `${environment.apiBaseUrl}/api/v1/crpc/head/transfers/history/`
      + encodeURIComponent(complaintNumber)
    ).subscribe({
      next: (res) => {
        const data = Array.isArray(res) ? res : (res?.data || []);
        this.transferHistory.set(data);
        this.loadingHistory.set(false);
      },
      error: () => {
        // Surfaced rather than silently swallowed: an empty history and a failed request looked identical
        // before, which is why this defect survived.
        this.transferHistory.set([]);
        this.loadingHistory.set(false);
        this.actionSuccess.set(false);
        this.actionResult.set('The transfer history could not be loaded. Please retry.');
      }
    });
  }

  logout() {
    sessionStorage.removeItem('crpc_user');
    this.auth.logout();
  }
}
