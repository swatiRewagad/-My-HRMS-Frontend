export { ComplaintFacadeService } from '../services';
